# OlaMovies Stremio Addon — The Complete Kali Linux Command Reference

Every command you need, from a bare Kali box to a running addon with extracted
download URLs. Work through sections 1–6 once; section 7 resolves links;
**section 8 is URL extraction** (movies, series episodes, anime, TV shows,
OMDrive direct links); sections 10–12 cover Docker / server deployment /
automation.

All project commands assume you are inside the project root:

```bash
cd ~/olamovies-stremio
```

---

## 0. TL;DR cheat sheet

```bash
# --- one-time setup ---
sudo apt update && sudo apt install -y python3 python3-venv git curl jq
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

# --- build/refresh catalog + run ---
python -m crawler domain                                  # current OlaMovies domain
python -m crawler catalog                                 # ~7,800 items into SQLite
uvicorn app.main:app --host 0.0.0.0 --port 8787           # serve the addon
# → Stremio: Addons → Install from URL → http://127.0.0.1:8787/manifest.json

# --- extract download URLs (run from residential IP) ---
python -m crawler streams --limit 50                      # batch-resolve links
python -m crawler url "attack on titan" --season 1 --episode 5   # one item
python -m crawler drive <omdrive-url-or-crypt>            # OMDrive → direct link
curl -s "http://127.0.0.1:8787/stream/series/tt2560140:1:5.json" | jq -r '.streams[].url'
```

---

## 1. Prerequisites on Kali

Kali ships with Python 3, but make sure the tooling is complete:

```bash
sudo apt update
sudo apt install -y python3 python3-venv python3-pip git curl jq unzip
python3 --version          # needs 3.10+
```

Optional but recommended:

```bash
# a Chromium for the stealth Cloudflare fallback (Scrapling StealthySession)
sudo apt install -y chromium

# only if you will use Docker deployment
sudo apt install -y docker.io docker-compose-v2
sudo systemctl enable --now docker
sudo usermod -aG docker $USER && newgrp docker

# only if you plan to download Google-Drive links from the CLI
pip install gdown
```

---

## 2. Install the addon

If you received the zip deliverable:

```bash
mkdir -p ~/olamovies-stremio
unzip olamovies-stremio-addon.zip -d ~/olamovies-stremio
cd ~/olamovies-stremio
```

Create the virtual environment and install dependencies:

```bash
python3 -m venv .venv
source .venv/bin/activate          # do this in every new terminal
pip install -r requirements.txt
```

Verify everything works (88 tests, offline, no network):

```bash
python -m pytest tests/ -q          # expect: 88 passed
```

The repo already contains a pre-built catalog database
(`data/olamovies.db`, ~7,300 items) — the addon is browsable immediately.
You only re-crawl if you want fresh content (section 4).

> Every `python -m …` command below assumes the venv is active
> (`source .venv/bin/activate`). Alternatively call the venv python directly:
> `~/olamovies-stremio/.venv/bin/python -m crawler stats`.

---

## 3. First-run sanity checks

```bash
# Which OlaMovies domain is live right now? (resolves via the permanent
# https://olamovies.dad — survives every future domain rotation)
python -m crawler domain
# → https://v6.olamovies.mov

# What's in the database?
python -m crawler stats
# → {"items": 7319, "movies": 5776, "series": 1543, "streams": 0, ...}

# Debug helper: fetch any URL through the addon's fetcher and dump
# everything parseable from it (writes probe_dump.html + probe_dump.flight.txt)
python -m crawler probe https://v6.olamovies.mov/movies/inception-2010
```

---

## 4. Build / refresh the catalog

```bash
# full crawl of the public OM Space index (~164 pages × 48 items, resumable,
# works from ANY IP — this board is not behind Cloudflare)
python -m crawler catalog

# cap the run (e.g. first 20 pages)
python -m crawler catalog --pages 20

# crawl the movies / tv-series / tv-shows boards separately
python -m crawler catalog --per-category

# slower/politer crawl (default 0.5s between requests)
python -m crawler catalog --delay 1.5

# pull the latest release titles from the public Telegram channel preview
# (t.me/s/olamovies_officialv8 — no Cloudflare, works from any IP)
python -m crawler telegram --pages 10
python -m crawler telegram --pages 3 --channel olamovies_officialv8
```

All crawls are **resumable** — `Ctrl-C` anytime, re-run the same command to
continue. When a board is exhausted the cursor resets, so the next run picks
up newly added items.

---

## 5. Run the addon server

```bash
# foreground (simplest)
uvicorn app.main:app --host 0.0.0.0 --port 8787

# same thing, env-var driven
python -m app.main                     # honors PORT / HOST

# custom port (if 8787 is taken)
uvicorn app.main:app --host 0.0.0.0 --port 8788
PORT=8788 python -m app.main

# keep running after you close the terminal
nohup uvicorn app.main:app --host 0.0.0.0 --port 8787 > addon.log 2>&1 &
tail -f addon.log                      # watch the log
pkill -f "uvicorn app.main"            # stop it

# check it's alive
curl -s http://127.0.0.1:8787/health | jq .
```

To reach the addon from other devices on your LAN (phone, another PC), find
your Kali box's IP and let the port through the firewall:

```bash
ip -4 addr show | grep inet            # e.g. 192.168.1.50
sudo ufw allow 8787/tcp                # if ufw is active
```

---

## 6. Install it in Stremio (the manifest.json URL)

The addon's descriptor — the URL Stremio asks for — is **`/manifest.json`**:

| Scenario | Install URL |
| --- | --- |
| Stremio on the same Kali machine | `http://127.0.0.1:8787/manifest.json` |
| Stremio on your phone / other PC (same LAN) | `http://<kali-ip>:8787/manifest.json` (e.g. `http://192.168.1.50:8787/manifest.json`) |
| Deployed on a server (HTTPS required) | `https://olanovies.example.com/manifest.json` |

In Stremio: **Add-ons → Install from URL → paste the manifest URL.**
(The root path `/` 307-redirects to `/manifest.json`, so pasting the plain
base URL works in most Stremio versions too.)

You immediately get three catalogs — **Movies**, **TV Series**, **TV
Shows** — searchable in Stremio. Until stream links are resolved (next
section) every item shows an "Open on OlaMovies" link.

---

## 7. Resolve download links (streams crawler)

> ⚠️ **Run this from a residential connection** (home internet). The
> OlaMovies site sits behind a Cloudflare WAF that hard-blocks datacenter and
> VPN IPs. The catalog crawl (section 4) is unaffected.

```bash
# resolve the 50 most recent pending items
python -m crawler streams

# resolve 300 items, only movies
python -m crawler streams --limit 300 --movie

# only series
python -m crawler streams --limit 300 --series

# gentler pacing
python -m crawler streams --limit 100 --delay 2
```

The fetcher works in tiers: fast plain-HTTP reusing a saved `cf_clearance`
cookie; if blocked, a stealth Chromium (Scrapling `StealthySession`) solves
the challenge once — you may briefly see a browser window — and its cookies
are saved to `data/session.json` for subsequent fast-path runs.

**Login-gated links.** Downloads require a free OlaMovies account. Export
your logged-in cookie string (browser DevTools → Network → any request →
`Cookie` request header) and:

```bash
export OLA_ACCOUNT_COOKIE="sessionid=...; csrftoken=..."
python -m crawler streams --limit 50        # now resolves gated links too
```

Without it, gated items are marked `gated` and Stremio shows the friendly
"Open on OlaMovies" fallback instead of streams.

---

## 8. Extract the URL of any movie / series / anime / TV show

### 8.1 The `crawler url` command (recommended)

```
python -m crawler url <query> [--season N] [--episode N] [--refresh] [--json] [--limit N]
```

| Option | Meaning |
| --- | --- |
| `<query>` | title fragment (`"attack on titan"`) or item id (`tt2560140`, `ola:…`) |
| `--season N` / `--episode N` | filter series links to that episode (episode requires a season) |
| `--refresh` | re-fetch the live page even if already resolved |
| `--json` | machine-readable JSON on stdout (logs go to stderr — safe to pipe into `jq`) |
| `--limit N` | max title matches listed (default 20) |

Exit codes: `0` links shown · `1` none found (blocked/gated/empty/no episode
match) · `2` unknown id/query.

The flow: **search by name → resolve**. A unique title match (or the best
match when `--season` is given) resolves immediately; an ambiguous title
lists matches for you to re-run with an id. If the item is still `pending`,
the command live-resolves it on the spot (same Cloudflare rules as section
7 — run from a residential IP), stores the links, and prints them.
Already-resolved items print instantly from the database.

---

### 8.2 Movie URL

A **unique** title match resolves immediately — search and resolve in one
command:

```bash
$ python -m crawler url "interstellar"
[url] resolving tt0816692 (Interstellar) from https://v6.olamovies.mov/movies/interstellar-2014 ...
  KIND    QUALITY  SIZE     LABEL                             URL
  gdrive  1080p    3.4 GB   1080p · 3.4 GB · drive.google.com   https://drive.google.com/file/d/1aB…/view
  gdrive  2160p    21 GB    2160p · 21 GB · drive.google.com    https://drive.google.com/folders/1xZ…
→ 2 link(s)

# or address the id directly (skips the search)
python -m crawler url tt0816692
```

An **ambiguous** title lists the matches and asks you to re-run with an id:

```bash
$ python -m crawler url "deadpool"
3 item(s) match 'deadpool':
   1. tt6263850  Deadpool and Wolverine (2024)  [movie]  pending
   2. tt5463162  Deadpool 2 (2018)             [movie]  pending
   3. tt1431045  Deadpool (2016)               [movie]  pending

re-run with an IMDb id to resolve one item, e.g.:
  python -m crawler url tt1431045
```

---

### 8.3 TV series — every link / a whole-season pack

```bash
# no season/episode → ALL links stored for the series
$ python -m crawler url tt8421350              # Manifest (2018) S01-S04
  KIND    QUALITY  SIZE     LABEL                                        URL
  gdrive  1080p    289 GB   1080p · 289 GB · drive.google.com             https://drive.google.com/folders/manifest-s01-s04
  …
```

---

### 8.4 TV series — one episode's URL

```bash
$ python -m crawler url tt8421350 --season 2 --episode 3
[url] Manifest (2018) · series · tt8421350 · S02E03
  KIND    QUALITY  SIZE    LABEL                                       URL
  direct  1080p    1.8 GB  1080p · 1.8 GB · S02E03 · cdn.example.com   https://cdn.example.com/manifest/s02e03-1080p.mkv
  gdrive  720p     800 MB  720p · 800 MB · S02E03 · drive.google.com   https://drive.google.com/file/d/1aB…/view
→ 2 link(s)
```

(Season-pack links whose season is `NULL` surface for every episode query —
that's by design, so you always see both the per-episode file and the pack.)

---

### 8.5 Anime movie URL

Anime movies live in the `movies` catalog — find them by title
(`"naruto"`, `"mugen train"`, `"one piece film"` …); a unique match resolves
directly:

```bash
$ python -m crawler url "mugen train"
[url] resolving tt11032374 (Demon Slayer the Movie - Mugen Train) from https://v6.olamovies.mov/movies/demon-slayer-the-movie-mugen-train-2020 ...
  KIND    QUALITY  SIZE    LABEL                             URL
  gdrive  1080p    5.1 GB  1080p · 5.1 GB · drive.google.com   https://drive.google.com/file/d/…/view
→ 1 link(s)

# "naruto" matches 13 items → it lists them; pick one and resolve:
python -m crawler url "naruto"              # → numbered list
python -m crawler url tt0476680             # Naruto the Movie: Ninja Clash in the Land of Snow
```

---

### 8.6 Anime series episode URL

```bash
# with a season given, the best title match resolves directly
$ python -m crawler url "attack on titan" --season 1 --episode 5
2 matches for 'attack on titan' — using best match tt2560140 (Attack on Titan)
[url] Attack on Titan (2013) · series · tt2560140 · S01E05
  KIND    QUALITY  SIZE    LABEL                                       URL
  gdrive  1080p    1.4 GB  1080p · 1.4 GB · S01E05 · drive.google.com  https://drive.google.com/file/d/1aB…/view
  direct  720p     800 MB  720p · 800 MB · S01E05 · cdn.example.com    https://cdn.example.com/aot/s01e05-720p.mkv
→ 2 link(s)

# or address the id directly
python -m crawler url tt0388629 --season 1 --episode 5     # One Piece (1999)
python -m crawler url tt9335498 --season 3 --episode 2     # Demon Slayer series
```

---

### 8.7 TV show episode URL (Kapil Sharma, Bigg Boss, …)

TV *shows* (reality / variety / talk) are a separate catalog but resolve
exactly the same way:

```bash
$ python -m crawler url "kapil sharma" --season 1 --episode 5
2 matches for 'kapil sharma' — using best match tt5747326 (The Kapil Sharma Show)
[url] The Kapil Sharma Show (2016) · series · tt5747326 · S01E05
  KIND    QUALITY  SIZE    LABEL                                       URL
  gdrive  1080p    2.2 GB  1080p · 2.2 GB · S01E05 · drive.google.com  https://drive.google.com/file/d/…/view
→ 1 link(s)

python -m crawler url tt2911448 --season 20 --episode 12   # Bigg Boss S20
```

---

### 8.8 JSON output (for scripts)

```bash
python -m crawler url tt2560140 --season 1 --episode 5 --json | jq .
python -m crawler url tt11032374 --json | jq -r '.streams[].url'      # bare URLs
```

```json
{
  "imdb_id": "tt2560140",
  "title": "[Season 1-4] Attack on Titan (2013) S01-S04",
  "year": 2013,
  "media_type": "series",
  "status": "crawled",
  "season": 1,
  "episode": 5,
  "streams": [
    {"url": "https://drive.google.com/file/d/…/view", "kind": "gdrive",
     "quality": "1080p", "size": "1.4 GB", "label": "1080p · 1.4 GB · S01E05 · drive.google.com"}
  ]
}
```

---

### 8.9 Downloading an extracted URL

```bash
# direct media file (kind=direct)
wget -O aot-s01e05.mkv "https://cdn.example.com/aot/s01e05-720p.mkv"
curl -L -o aot-s01e05.mkv "https://cdn.example.com/aot/s01e05-720p.mkv"

# Google Drive (kind=gdrive) — open in a browser, or use gdown
gdown "https://drive.google.com/file/d/FILE_ID/view" -O aot-s01e05.mkv
gdown --folder "https://drive.google.com/folders/FOLDER_ID"      # whole folder
```

---

### 8.10 OMDrive direct links (`kind=omd-drive`)

OlaMovies' downloads live on its **own file host** ("OMDrive V3" at
`drive.olamovies.download`), not Google Drive. The crawler follows the chain
item page → `/f/<id>` page → `drive.olamovies.download/file/<crypt>`
automatically during `crawler streams` and stores those links as `omd-drive`
streams. The last hop — solving the per-file Cloudflare Turnstile and hitting
`POST /api/cloud/download-links` — needs an OMDrive login (any Google
account; downloads are paid from its credits) and yields a **direct link
valid ~3 days**:

```bash
# resolve one file link all the way to the direct URL (v1)
python -m crawler drive 0ltzj66qbtbheg74r06m
python -m crawler drive "https://drive.olamovies.download/file/0ltzj66qbtbheg74r06m"
python -m crawler drive <crypt> --json          # machine-readable result
python -m crawler drive <crypt> --refresh       # ignore the cached v1
python -m crawler drive <crypt> --no-browser    # fast HTTP path only

# items resolved through `crawler url` show a RESOLVED DIRECT LINKS section
# for their omd-drive streams automatically (fast path only).
```

How to authenticate (pick one):

```bash
# 1) export your logged-in session cookie (recommended):
#    log in once at drive.olamovies.download in your browser, then
#    DevTools → Network → any request to the site → copy the Cookie header
export OLA_DRIVE_COOKIE="__Secure-next-auth.session-token=eyJ…; other=v"
python -m crawler drive 0ltzj66qbtbheg74r06m     # → prints: v1: https://…workers.dev/serve?t=e2…

# 2) log in once inside the stealth browser (no cookie exporting):
OLA_STEALTH_HEADLESS=false python -m crawler drive <url>   # browser window opens — log in there
# the persistent profile (data/browser-profile) remembers the session
```

Downloading a resolved v1 link is then plain HTTP:

```bash
wget -O movie.mkv "https://omd-rb.omd-uf5-e678.workers.dev/serve?t=e2…"
curl -L -o movie.mkv "https://omd-rb.omd-uf5-e678.workers.dev/serve?t=e2…"
```

The Stremio addon does the same resolution on demand (`OLA_RESOLVE_DRIVE=1`,
default): playable "… · OMDrive direct" streams when a v1 is cached/resolved,
otherwise an "Open on OMDrive" fallback entry — with a background warm-up
thread so the next request plays directly.

**⚠️ Network binding.** OMDrive links are bound to the network that resolved
them ("works on this network only") — fetching a v1 from a different IP gives
`403 Invalid or expired link`. Same machine/network as the addon → fine.
Stremio elsewhere (e.g. server deployment) → enable the streaming proxy:

```bash
export OLA_DRIVE_PROXY=1
# stream URLs now point at http://<addon-host>:8787/drive/<crypt>, which
# resolves AND fetches on the addon's side (Range/seek pass-through)
curl -s "http://127.0.0.1:8787/drive/<crypt>" -r 0-1023 -o probe.bin   # test
```

---

## 9. Extract URLs over the addon's HTTP API (curl)

With the server running (section 5). Find any item's IMDb id via catalog
search, then hit the stream endpoints — identical data to section 8:

```bash
# --- find the id ---
curl -s "http://127.0.0.1:8787/catalog/movie/movies.json?search=interstellar" \
  | jq -r '.metas[] | "\(.id)  \(.name)"'
curl -s "http://127.0.0.1:8787/catalog/series/tv-series.json?search=attack on titan" \
  | jq -r '.metas[] | "\(.id)  \(.name)"'
curl -s "http://127.0.0.1:8787/catalog/series/tv-shows.json?search=kapil" \
  | jq -r '.metas[] | "\(.id)  \(.name)"'

# --- MOVIE (also ANIME MOVIE) ---
curl -s http://127.0.0.1:8787/stream/movie/tt0816692.json | jq .
curl -s http://127.0.0.1:8787/stream/movie/tt11032374.json | jq -r '.streams[].url'

# --- TV SERIES, one episode (colon form — what Stremio itself calls) ---
curl -s "http://127.0.0.1:8787/stream/series/tt2560140:1:5.json" | jq -r '.streams[].url'

# --- same, query-parameter form ---
curl -s "http://127.0.0.1:8787/stream/series/tt2560140.json?season=1&episode=5" | jq -r '.streams[].url'

# --- TV SHOW episode ---
curl -s "http://127.0.0.1:8787/stream/series/tt5747326:1:5.json" | jq -r '.streams[].url'

# --- whole series (no season → all links) ---
curl -s "http://127.0.0.1:8787/stream/series/tt8421350.json" | jq -r '.streams[] | "\(.quality // "?")\t\(.url)"'

# --- browsable labels ---
curl -s "http://127.0.0.1:8787/stream/series/tt0388629:1:5.json" \
  | jq -r '.streams[] | "\(.title)\n  \(.url)"'
```

Other useful endpoints:

```bash
curl -s http://127.0.0.1:8787/manifest.json | jq .            # addon descriptor
curl -s http://127.0.0.1:8787/health | jq .                   # live DB stats
curl -s "http://127.0.0.1:8787/catalog/movie/movies.json?skip=0" | jq '.metas | length'
curl -s "http://127.0.0.1:8787/catalog/series/tv-series.json" | jq '.metas | length'
curl -s "http://127.0.0.1:8787/catalog/series/tv-shows.json"  | jq '.metas | length'
curl -s http://127.0.0.1:8787/meta/series/tt0388629.json | jq .
```

If streams haven't been resolved yet, the endpoints return the
`"Open on OlaMovies"` fallback entry whose `externalUrl` is the item's page
on the current OlaMovies domain — handy as a jump-off link.

`omd-drive` streams (OMDrive file links) are resolved on demand by the addon:
when a direct link is available the entry is **playable** (`url` = the v1
link, title ends in "· OMDrive direct"); otherwise you get an
`"Open on OMDrive"` fallback pointing at the file page:

```bash
# omd-drive stream, resolved to a direct link (after OLA_DRIVE_COOKIE is set
# or the background warm-up succeeded):
curl -s http://127.0.0.1:8787/stream/movie/tt27165187.json \
  | jq -r '.streams[] | select(.title | contains("OMDrive direct")) | .url'
# → https://omd-rb.omd-uf5-e678.workers.dev/serve?t=e2…   (valid ~3 days)

# still unresolved → the fallback carries the OMDrive file page URL:
curl -s http://127.0.0.1:8787/stream/movie/tt27165187.json \
  | jq -r '.streams[] | select(.externalUrl != null) | .externalUrl'
```

---

## 10. Docker

```bash
docker compose up -d --build          # build + start on :8787
docker compose logs -f addon          # follow logs
docker compose ps                     # status
curl -s http://127.0.0.1:8787/health | jq .

# catalog crawl inside the container (plain HTTP — fine from any IP)
docker compose exec addon python -m crawler catalog --pages 20
# ...or without the service running:
docker compose run --rm addon python -m crawler catalog

docker compose down                   # stop
```

The container serves whatever DB is in `./data` (bind-mounted). Stream crawls
must run from a residential IP — i.e. from your machine with the same
`./data` dir, not inside the container (it ships no stealth browser by
design). If the container (uid 1000) can't write the DB:
`sudo chown -R 1000:1000 ./data`.

Install in Stremio with `http://<host>:8787/manifest.json`.

---

## 11. Deploy on a server (HTTPS + systemd)

Stremio requires **HTTPS** for non-localhost addon URLs. Keep the addon on
`127.0.0.1:8787` and put a TLS-terminating proxy in front.

**systemd service** (`/etc/systemd/system/olamovies.service`):

```ini
[Unit]
Description=OlaMovies Stremio addon
After=network-online.target

[Service]
User=YOURUSER
WorkingDirectory=/home/YOURUSER/olamovies-stremio
ExecStart=/home/YOURUSER/olamovies-stremio/.venv/bin/uvicorn app.main:app --host 127.0.0.1 --port 8787
Restart=on-failure
# optional: OLA_ACCOUNT_COOKIE=… , PORT=… , OLA_ADDON_NAME=…

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now olamovies
systemctl status olamovies
journalctl -u olamovies -f
```

**Caddy** (automatic Let's Encrypt — create the DNS A record first), in
`/etc/caddy/Caddyfile`:

```caddyfile
olanovies.example.com {
    reverse_proxy 127.0.0.1:8787
}
```

```bash
sudo systemctl reload caddy
```

**nginx + certbot** alternative:

```nginx
server {
    server_name olanovies.example.com;
    location / {
        proxy_pass http://127.0.0.1:8787;
        proxy_set_header Host $host;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }
    listen 443 ssl;
    # cert lines added by certbot
}
```

```bash
sudo apt install -y nginx certbot python3-certbot-nginx
sudo ln -s /etc/nginx/sites-available/olanovies /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl reload nginx
sudo certbot --nginx -d olanovies.example.com
sudo ufw allow 'Nginx Full'
```

The install URL becomes **`https://olanovies.example.com/manifest.json`**.

Reminder: crawl the *catalog* on the server whenever you like; run the
*streams* crawler on your home machine and sync the resulting
`data/olamovies.db` up to the server (scp/rsync), since the site blocks
datacenter IPs.

```bash
# sync a home-crawled DB up to the server
rsync -avz data/olamovies.db user@server:~/olamovies-stremio/data/
```

---

## 12. Automation (cron)

```bash
crontab -e
```

```cron
# refresh the catalog every day at 04:00
0 4 * * * cd $HOME/olamovies-stremio && .venv/bin/python -m crawler catalog >> cron-catalog.log 2>&1

# pick up new Telegram releases every 6 hours
0 */6 * * * cd $HOME/olamovies-stremio && .venv/bin/python -m crawler telegram --pages 3 >> cron-telegram.log 2>&1

# resolve 100 pending streams every night at 02:00 (residential IP only)
0 2 * * * cd $HOME/olamovies-stremio && .venv/bin/python -m crawler streams --limit 100 >> cron-streams.log 2>&1
```

---

## 13. Configuration (environment variables / `.env`)

Copy `.env.example` to `.env` and edit; every variable is optional.

| Variable | Default | Purpose |
| --- | --- | --- |
| `PORT` | `8787` | Addon port (`python -m app.main`) |
| `HOST` | `0.0.0.0` | Bind address (`python -m app.main`) |
| `OLA_ADDON_ID` | `olamovies.community.addon` | Stremio addon id |
| `OLA_ADDON_NAME` | `OlaMovies` | Addon name in Stremio |
| `OLA_ADDON_VERSION` | `1.0.0` | Addon version |
| `OLA_ADDON_DESCRIPTION` | *(text)* | Manifest description |
| `OLA_ADDON_LOGO` | OlaMovies poster URL | Addon logo |
| `OLA_DB` | `./data/olamovies.db` | SQLite database path |
| `OLA_DATA_DIR` | `./data` | Root for DB/sessions/caches |
| `OLA_ENTRY_DOMAIN` | `https://olamovies.dad` | Permanent entry domain (redirect → current domain) |
| `OLA_FALLBACK_DOMAINS` | `https://v6.olamovies.mov,https://v5.olamovies.mov` | Fallbacks if the redirect endpoint fails |
| `OLA_SPACE_BASE` | `https://space.olamovies.dad` | Catalog board base URL |
| `OLA_DOMAIN_TTL` | `600` | Seconds to cache the resolved domain |
| `OLA_CRAWL_DELAY` | `0.5` | Politeness delay between requests |
| `OLA_CRAWL_TIMEOUT` | `30` | Per-request timeout (s) |
| `OLA_CRAWL_RETRIES` | `3` | Retries for transient failures |
| `OLA_USER_AGENT` | Chrome 131 UA | UA for plain-HTTP fetches |
| `OLA_ACCOUNT_COOKIE` | *(empty)* | Logged-in cookie string — unlocks gated links |
| `OLA_DRIVE_BASE` | `https://drive.olamovies.download` | OMDrive file-host base URL |
| `OLA_DRIVE_COOKIE` | *(empty)* | Logged-in cookie string for drive.olamovies.download — unlocks OMDrive direct links (§8.10) |
| `OLA_DRIVE_CACHE_TTL` | `21600` | Seconds a resolved OMDrive direct link stays cached (links valid ~3 days) |
| `OLA_RESOLVE_DRIVE` | `1` | Addon resolves omd-drive streams on demand (background warm-up thread) |
| `OLA_DRIVE_PROXY` | `0` | Serve OMDrive links via the addon's `/drive/<crypt>` streaming proxy — enable when Stremio runs on a different machine/network (links are network-bound) |
| `OLA_FOLLOW_F_LINKS` | `1` | Crawler follows /f/<id> pages to OMDrive file links |
| `OLA_STEALTH_HEADLESS` | `auto` | `auto` / `true` / `false` (headful = most reliable for Turnstile) |
| `OLA_STEALTH_PROFILE` | `<data>/browser-profile` | Persistent stealth-browser profile |
| `OLA_STEALTH_CHROME_PATH` | *(empty)* | Explicit Chrome/Chromium binary path |
| `OLA_TELEGRAM_CHANNEL` | `olamovies_officialv8` | Telegram channel for backfill |

---

## 14. Troubleshooting on Kali

| Symptom | Fix |
| --- | --- |
| `bash: python: command not found` | Use `python3`, or `alias python=python3`; always run inside the venv (`source .venv/bin/activate`). |
| Port 8787 in use | `ss -tlnp \| grep 8787` → `pkill -f uvicorn` (a stale manual run is the usual culprit), or serve on `--port 8788`. |
| Stremio can't install from LAN IP | Firewall: `sudo ufw allow 8787/tcp`; confirm the server bound `0.0.0.0` not `127.0.0.1`. |
| `crawler streams` all `error` / 403 | Cloudflare WAF blocking your IP (datacenter/VPN). Run from a residential connection; let the stealth fallback solve once; `python -m crawler probe <item-url>` to see exactly what returns. |
| Items show "Open on OlaMovies" instead of links | Streams not resolved yet (`python -m crawler stats`) or item is `gated` → set `OLA_ACCOUNT_COOKIE`. |
| Items show "Open on OMDrive … set OLA_DRIVE_COOKIE" | OMDrive link not resolved to a direct URL yet → export `OLA_DRIVE_COOKIE` (§8.10) or log in once via `python -m crawler drive <url>`; the addon's background warm-up then makes it playable. |
| Direct link plays locally but `403` on another device | OMDrive links are network-bound — set `OLA_DRIVE_PROXY=1` on the addon so other machines stream through it (§8.10). |
| `crawler drive` → `verification_required` | Turnstile not solved — run without `--no-browser` (stealth browser), or open the file page once in your own browser. |
| `crawler drive` → `out_of_credits` | OMDrive account out of download credits — top up or export another account's cookie. |
| Domain expired / dead links | `python -m crawler domain` to check; the crawler re-resolves via olamovies.dad automatically (cached `OLA_DOMAIN_TTL` seconds). Re-run `crawler catalog` after a rotation to refresh `site_url`s. |
| Empty catalog in Stremio | DB missing — `python -m crawler stats`, rebuild with `crawler catalog`; confirm addon + crawler use the same `OLA_DB`. |
| Stealth browser never launches | `sudo apt install -y chromium`, then `OLA_STEALTH_CHROME_PATH=/usr/bin/chromium`; or `OLA_STEALTH_HEADLESS=false`. |
| Docker DB permission errors | `sudo chown -R 1000:1000 ./data`. |
| Verify an install non-interactively | `curl -s http://127.0.0.1:8787/manifest.json \| jq -r '.id, .resources[]'` |

---

## 15. Maintenance

```bash
# keep the catalog fresh + pick up new releases
python -m crawler catalog && python -m crawler telegram --pages 5

# re-resolve everything (statuses reset only via re-crawl of streams)
python -m crawler streams --limit 500

# database location / size
python -m crawler stats | jq '.db_path, .db_size_bytes'
du -h data/olamovies.db

# back up the database (safe while the addon is running)
sqlite3 data/olamovies.db ".backup data/olamovies-backup.db"

# full reset (catalog + streams + cursors)
rm data/olamovies.db && python -m crawler catalog

# after pulling a new version of the addon
source .venv/bin/activate && pip install -r requirements.txt && python -m pytest tests/ -q
```
