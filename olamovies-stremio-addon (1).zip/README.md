# OlaMovies Stremio Addon

```text
Python 3.10+  ·  FastAPI  ·  Scrapling  ·  SQLite  ·  Self-hosted
```

A Stremio addon for **OlaMovies** that lets you browse the site's full catalog —
movies, TV series and TV shows — directly inside Stremio, and get every download
link for each item. Powered by [Scrapling](https://github.com/D4Vinci/Scrapling),
it ships with a crawler that reads OlaMovies' public index into a local SQLite
database and a FastAPI server that speaks the Stremio addon protocol on top of
it. Self-hosted: run it locally on your PC or on your own server.

The repo includes a **pre-built catalog database** (`data/olamovies.db`, ~7,300
items), so the addon is browsable the moment you start it — run the stream
crawler afterwards to resolve download links.

OlaMovies rotates its domain: the permanent entry point is
`https://olamovies.dad` (currently redirecting to `https://v6.olamovies.mov`).
The crawler resolves the current domain automatically on every run.

---

## How it works

The project is three small pieces sharing one SQLite file (`data/olamovies.db`):

1. **Catalog crawler** — reads the public **OM Space** board
   (`space.olamovies.dad/completed`), a structured, Cloudflare-free index of
   *everything* ever published on OlaMovies: ~164 pages × 48 items ≈ 7,800
   entries, each with the IMDb id, title, poster and the item's URL on the
   current OlaMovies domain. It upserts them into SQLite. This works from any
   machine — no browser, no Cloudflare.

2. **Stream crawler** — walks the item pages on the *current* OlaMovies domain
   (auto-resolved via `https://olamovies.dad/current.php?redirect=1`) using a
   Cloudflare-aware fetcher: a fast plain-HTTP path reusing a saved
   `cf_clearance` cookie, with an automatic stealth-browser fallback
   (Scrapling `StealthySession`, `solve_cloudflare`) that solves the challenge
   once and then saves its cookies so subsequent requests stay on the fast
   path. Extracted download links (Google Drive folders/files, direct media,
   hoster pages, OMDrive files) are stored per item — and per episode for series.

3. **The addon (FastAPI)** — serves Stremio's `/manifest.json`, catalog, meta
   and stream endpoints straight from SQLite. Item ids are **IMDb-native**
   (`tt…`), so Stremio keeps using Cinemeta for posters, descriptions and
   episode lists — the addon only adds the OlaMovies catalog and streams on
   top. Hosted links are exposed as external/open-in-browser entries, direct
   media files as playable streams.

```
OM Space board ──(catalog crawl, any IP)──┐
                                          ├──> SQLite ──> FastAPI addon ──> Stremio
OlaMovies items ──(stream crawl, CF-aware)┘                 (manifest/catalog/meta/stream)
```

---

## Command reference

A complete, copy-paste-ready command reference for Kali Linux (and any other
Linux) — setup, crawling, serving, Stremio installation, Docker, server
deployment, automation, and URL-extraction examples for movies, series
episodes, anime and TV shows — lives in
**[KALI-COMMANDS.md](KALI-COMMANDS.md)**.

---

## Quick start (local)

```bash
git clone <this-repo> olamovies-stremio
cd olamovies-stremio

python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt

python -m crawler catalog          # build/refresh the catalog DB (~164 pages; resumable)

uvicorn app.main:app --host 0.0.0.0 --port 8787
```

Then in **Stremio** (desktop or mobile, same machine):

> **Add-ons → Install from URL → `http://127.0.0.1:8787/manifest.json`**

⚠️ Note that the URL you paste must be the **`manifest.json` URL** shown above —
that is the addon's descriptor Stremio asks for. The root path `/` redirects to
`/manifest.json`, so pasting the plain base URL `http://127.0.0.1:8787/` works
in most Stremio versions too.

At this point the catalog (Movies / TV Series / TV Shows) is browsable and every
item without resolved streams shows an **"Open on OlaMovies"** link. To get real
download links inside Stremio, run the streams crawler from this same
(residential) machine — see [Cloudflare & gated downloads](#cloudflare--gated-downloads):

```bash
python -m crawler streams --limit 50
```

`python -m app.main` is an alternative to uvicorn that honors the `PORT` / `HOST`
environment variables.

---

## Docker

```bash
docker compose up -d --build
```

Then install in Stremio with `http://<host>:8787/manifest.json` (use the host's
IP; `127.0.0.1` only works when Stremio runs on the same machine/network
namespace).

**Run the crawler first** — the container serves whatever database is in
`./data` (mounted as a volume). Either:

- crawl **on the host** (simplest, and required for streams anyway — see below),
  pointing the crawler at the same `./data` directory it uses locally; or
- crawl **inside the container** (fine for the *catalog*, which is plain HTTP):

  ```bash
  docker compose exec addon python -m crawler catalog --pages 20
  # or, without the service running: docker compose run --rm addon python -m crawler catalog
  ```

> The image intentionally does **not** include the stealth browser — see the
> note in the `Dockerfile`. Run stream crawls from your machine (residential
> IP) with the same mounted `./data` dir.

Optional configuration lives in `.env` (copy from `.env.example`); see
[Configuration](#configuration).

---

## Deploying on a server

Stremio only accepts **HTTPS** addon URLs for non-localhost hosts, so put the
addon behind a TLS-terminating reverse proxy. The addon itself stays plain HTTP
on `127.0.0.1:8787`.

**Caddy** (automatic Let's Encrypt certificates — create a DNS `A` record for
your host first):

```Caddyfile
olanovies.example.com {
    reverse_proxy 127.0.0.1:8787
}
```

**nginx** alternative (with certbot: `certbot --nginx -d olanovies.example.com`):

```nginx
server {
    server_name olanovies.example.com;

    location / {
        proxy_pass http://127.0.0.1:8787;
        proxy_set_header Host $host;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }

    listen 443 ssl;
    # ssl_certificate / ssl_certificate_key lines are added by certbot
}
```

The install URL then becomes `https://olanovies.example.com/manifest.json`.

Reminder: the *catalog* crawler works fine on a server; the *streams* crawler
must run from a residential connection (below) — you can sync its results to
the server by copying `data/olamovies.db` or running the server against a
mounted copy of it.

---

## Crawler guide

All commands run from the project root: `python -m crawler <command>`.

| Command | What it does |
| --- | --- |
| `python -m crawler catalog [--pages N] [--per-category]` | Build/refresh the catalog from the OM Space `/completed` board (~164 pages, ~7,800 items). `--pages N` caps the run; `--per-category` crawls the `movies`, `tv-series` and `tv-shows` boards separately. |
| `python -m crawler streams [--limit N] [--movie\|--series]` | Resolve download links for pending items from the OlaMovies item pages. `--limit` (default 50) caps the run; `--movie` / `--series` restrict the media type. Accepts `--delay SECONDS`. **Run from a residential IP.** |
| `python -m crawler telegram [--pages N]` | Telegram backfill (if available) — re-indexes release titles from the public OlaMovies Telegram channel preview (t.me). |
| `python -m crawler url <query> [--season N] [--episode N]` | Resolve links for ONE item (title search or IMDb id) — see [KALI-COMMANDS.md](KALI-COMMANDS.md) §8 for the full syntax and examples. |
| `python -m crawler drive <url\|crypt> [--json] [--refresh] [--no-browser]` | Resolve an OMDrive file link (`drive.olamovies.download/file/<crypt>`) all the way to its direct download URL (valid ~3 days). Browser path allowed by default; `--no-browser` stays on the fast HTTP path. |
| `python -m crawler domain` | Resolve and print the current OlaMovies domain (via `olamovies.dad`). |
| `python -m crawler probe <url>` | Debug helper: fetch any URL through the fetcher and dump what can be parsed from it (`probe_dump.html`, `probe_dump.flight.txt`). |
| `python -m crawler stats` | Print database statistics (items, streams, pending/gated counts). |

**Resumability.** Every crawl stores its pagination cursor in the database, so
it is safe to `Ctrl-C` at any time — re-running the same command continues from
where it stopped. When a board is exhausted the cursor resets, so the next run
picks up freshly added items. Streams are only attempted for items whose status
is still `pending`, so nothing is fetched twice.

**Politeness.** The crawler waits `OLA_CRAWL_DELAY` seconds (default `0.5`)
between requests; lower or raise it via the environment variable. Fetches use a
browser User-Agent (`OLA_USER_AGENT`) and retry transient failures up to
`OLA_CRAWL_RETRIES` times.

---

## Cloudflare & gated downloads

**Read this before running the streams crawler.** The OlaMovies site is behind
Cloudflare with a WAF that **hard-blocks datacenter IPs** (blanket 403 "Sorry,
you have been blocked", regardless of cookies or browser tricks). That means:

> Run `python -m crawler streams` **from a residential connection** — your home
> PC. It will not work from most cloud servers and VPN exits. The *catalog*
> crawler is unaffected (the OM Space board is not behind the wall).

On a residential IP the fetcher gets you through automatically, in tiers:

1. **Fast path** — plain HTTP (curl_cffi with Chrome TLS impersonation) reusing
   a previously saved `cf_clearance` cookie + its matching User-Agent.
2. **Stealth fallback** — if blocked, a stealth Chromium session launches
   (Scrapling `StealthySession`, `solve_cloudflare=True`), solves the managed
   challenge/Turnstile, and its cookies are saved to `data/session.json` so
   subsequent requests go back to the fast path.

The first run may briefly **open a browser window** — that is the stealth
fallback passing the Turnstile check (it tries headless first and only goes
headful if needed). Its profile persists in `data/browser-profile/`, so this
typically happens once per cookie lifetime.

**Login-gated downloads.** OlaMovies gates downloads behind a *free* account
("sign in to play & download"). To let the crawler resolve the actual links:

1. Log in to OlaMovies in your normal browser.
2. Copy your cookie string for the site (e.g. from DevTools → Network → any
   request → `Cookie` request header).
3. Export it for the crawler:

   ```bash
   export OLA_ACCOUNT_COOKIE="k=v; k2=v2"
   # or put it in .env / your shell profile
   ```

Without `OLA_ACCOUNT_COOKIE`, login-walled items are simply marked `gated` in
the database and the addon shows a friendly **"Open on OlaMovies"** link for
them instead of streams.

---

## OMDrive download links

OlaMovies' downloads do **not** go to Google Drive — they go to OlaMovies' own
file host, **OMDrive V3** at `drive.olamovies.download`. The full chain:

```
item page (v6.olamovies.mov/<category>/<slug>)
  → /f/<id> download pages        (links embedded in the item page's flight data)
  → drive.olamovies.download/file/<crypt>      (the OMDrive file page — anonymous OK)
  → Cloudflare Turnstile + NextAuth login       (per-file verification)
  → POST /api/cloud/download-links → v1 direct link   (valid ~3 days / 259200 s)
```

The crawler handles the first hops automatically: during a stream crawl it
follows every `/f/<id>` page and stores the OMDrive file links as `omd-drive`
streams (dropping the noisy intermediate `/f/` links). Drive file URLs found
directly on item pages are stored the same way. Disable with
`OLA_FOLLOW_F_LINKS=0`.

**Resolving to the direct link** needs an OMDrive login (any Google account;
downloads are paid from that account's credits). Two ways to authenticate:

1. **`OLA_DRIVE_COOKIE`** (recommended) — export the cookie string of your
   logged-in session for `drive.olamovies.download`:

   1. Log in at `drive.olamovies.download` in your normal browser (once).
   2. DevTools → Network → click any request to the site → request headers →
      copy the full `Cookie:` value (`__Secure-next-auth.session-token=…; …`).
   3. Export it for the crawler/addon:

      ```bash
      export OLA_DRIVE_COOKIE="__Secure-next-auth.session-token=eyJ…; other=v"
      python -m crawler drive 0ltzj66qbtbheg74r06m   # test it — prints the v1 link
      ```

2. **Stealth browser login** — run `python -m crawler drive <url>` without
   `OLA_DRIVE_COOKIE`; the stealth browser opens the file page (set
   `OLA_STEALTH_HEADLESS=false` to see it), where you can log in once. The
   persistent profile remembers the session and also solves the Turnstile
   automatically on future runs.

**In Stremio** the addon resolves `omd-drive` streams on demand: a request
first tries the fast HTTP path (`resolve_cached`, browser never launched) —
if a cached/resolved `v1` exists you get a **playable** stream
("… · OMDrive direct"); otherwise an **"Open on OMDrive"** fallback entry with
instructions. When `OLA_RESOLVE_DRIVE=1` (default) the addon also spawns one
daemon background thread per unresolved crypt to warm the cache with the
browser allowed — the next request (cache TTL `OLA_DRIVE_CACHE_TTL`, default
6 h; links themselves stay valid ~3 days) then serves the direct link.

**Network binding — important for server deployments.** OMDrive labels its
links *"works on this network only / same device"*: a resolved `v1` URL is
bound to the network that resolved it and returns
`403 Invalid or expired link` when fetched from elsewhere. When Stremio runs
on the **same machine/network** as the addon (the local setup), the direct
link just works. When Stremio runs **elsewhere** (server deployment, remote
Stremio), enable the addon's streaming proxy:

```bash
export OLA_DRIVE_PROXY=1     # stream URLs become http://<addon>/drive/<crypt>
```

The `/drive/<crypt>` endpoint resolves **and** fetches the file on the
addon's side (so the network binding stays consistent) and passes Range
requests through — seeking works in players. File metadata (exact name, size,
duration) comes from OMDrive's anonymous `/api/mediainfo/get` API, so labels
and sizes are correct even before login.

Quick checks:

```bash
python -m crawler drive <url-or-crypt>            # full chain, browser allowed
python -m crawler drive <crypt> --no-browser     # fast HTTP path only
python -m crawler drive <crypt> --json           # machine-readable result
python -m crawler url "some title"               # omd-drive rows get a
                                                  # "RESOLVED DIRECT LINKS" section
```

---

## Configuration

Everything is configured through environment variables (or a `.env` file —
copy `.env.example`). Defaults shown.

### Addon / server

| Variable | Default | Purpose |
| --- | --- | --- |
| `PORT` | `8787` | Port the addon listens on (used by `python -m app.main`; pass `--port` to uvicorn otherwise). |
| `HOST` | `0.0.0.0` | Bind address for `python -m app.main`. |
| `OLA_ADDON_ID` | `olamovies.community.addon` | Stremio addon id. Change it if you run a personalized copy. |
| `OLA_ADDON_NAME` | `OlaMovies` | Addon name shown in Stremio. |
| `OLA_ADDON_DESCRIPTION` | *(see below)* | Addon description in the manifest. |
| `OLA_ADDON_VERSION` | `1.0.0` | Addon version in the manifest. |
| `OLA_ADDON_LOGO` | OlaMovies poster URL | Addon logo URL shown in Stremio. |
| `OLA_DB` | `<OLA_DATA_DIR>/olamovies.db` | Path to the SQLite database (relative paths resolve against the working directory). |
| `OLA_DATA_DIR` | `./data` | Root for the DB, session/profile files and caches. |

Default description: *"OlaMovies catalog and direct download links (movies, TV
series, TV shows). Catalog is served from a local database built by the
included Scrapling crawler."*

### Domains

| Variable | Default | Purpose |
| --- | --- | --- |
| `OLA_ENTRY_DOMAIN` | `https://olamovies.dad` | Permanent entry domain; `/current.php?redirect=1` is polled to find the current working domain. |
| `OLA_FALLBACK_DOMAINS` | `https://v6.olamovies.mov,https://v5.olamovies.mov` | Comma-separated fallbacks tried in order if the redirect endpoint fails. |
| `OLA_SPACE_BASE` | `https://space.olamovies.dad` | Base URL of the OM Space board used by the catalog crawler. |
| `OLA_DOMAIN_TTL` | `600` | Seconds to cache the resolved domain (`data/domain.json`). |

### Crawling

| Variable | Default | Purpose |
| --- | --- | --- |
| `OLA_CRAWL_DELAY` | `0.5` | Politeness delay in seconds between requests. |
| `OLA_CRAWL_TIMEOUT` | `30` | Per-request timeout in seconds (browser fetches get longer timeouts internally). |
| `OLA_CRAWL_RETRIES` | `3` | Retries for transient fetch failures (with backoff). |
| `OLA_USER_AGENT` | Chrome 131 UA string | User-Agent used for plain-HTTP fetches. |
| `OLA_ACCOUNT_COOKIE` | *(empty)* | Cookie string from your logged-in browser (`"k1=v1; k2=v2"`), enables resolving login-gated download links. |

### OMDrive (drive.olamovies.download)

| Variable | Default | Purpose |
| --- | --- | --- |
| `OLA_DRIVE_BASE` | `https://drive.olamovies.download` | Base URL of the OMDrive file host. |
| `OLA_DRIVE_COOKIE` | *(empty)* | NextAuth session cookie string for `drive.olamovies.download` from your logged-in browser — enables resolving direct links over plain HTTP (see [OMDrive download links](#omdrive-download-links)). |
| `OLA_DRIVE_CACHE_TTL` | `21600` | Seconds a resolved direct link stays cached (links stay valid ~3 days on OMDrive). |
| `OLA_RESOLVE_DRIVE` | `1` | Let the addon resolve omd-drive streams on demand (fast HTTP first, then one background warm-up thread). |
| `OLA_DRIVE_PROXY` | `0` | Serve OMDrive links through the addon's `/drive/<crypt>` streaming proxy — enable when Stremio runs on a different machine/network than the addon (links are network-bound). |
| `OLA_FOLLOW_F_LINKS` | `1` | Follow `/f/<id>` download pages during item crawls to find OMDrive file links. |

### Stealth browser

| Variable | Default | Purpose |
| --- | --- | --- |
| `OLA_STEALTH_HEADLESS` | `auto` | `auto` (headless first, headful retry), `true`, or `false` (always headful — most reliable for Turnstile). |
| `OLA_STEALTH_PROFILE` | `<OLA_DATA_DIR>/browser-profile` | Persistent browser profile directory (keeps the solved-challenge state). |
| `OLA_STEALTH_CHROME_PATH` | *(empty)* | Explicit path to a Chrome/Chromium binary, if the bundled one is missing or you want a specific build. |

---

## How the scraper works (technical)

OlaMovies (and its sister sites) are **Next.js App-Router** apps: every
server-rendered page embeds its full data payload as a sequence of
`<script>self.__next_f.push([1,"…escaped json…"])</script>` chunks (RSC "flight
data"). The parser in [`crawler/flight.py`](crawler/flight.py) extracts those
chunks, un-escapes them (JS string escapes, left-to-right, `\uXXXX` included)
and joins them into one stream that contains the page's structured data — item
records, link objects, pagination metadata. Records are then mined out with
brace-balanced JSON scanning (walk `{`…`}` respecting strings/escapes, parse
candidates that carry the required keys) rather than DOM scraping, which is far
more robust against React hydration and markup churn. The stream crawler
combines this with DOM anchor harvesting as a fallback and classifies every
link as `direct` / `gdrive` / `folder` / `page`.

[Scrapling](https://github.com/D4Vinci/Scrapling) provides the transport
layers: `Fetcher` (curl_cffi, Chrome TLS impersonation) for the fast HTTP path
and `StealthySession` (patchright/Chromium with Cloudflare solving) for the
fallback — plus the HTML parsing used for DOM fallbacks and the `probe`
command.

---

## Troubleshooting

| Symptom | Fix |
| --- | --- |
| **Catalog is empty in Stremio** | The DB hasn't been built (or wasn't found). Run `python -m crawler catalog`, and confirm the addon reads the same `OLA_DB`/`OLA_DATA_DIR` the crawler wrote to. `python -m crawler stats` shows what's in the DB; `curl localhost:8787/health` shows what the addon serves. |
| **Streams empty / everything "Open on OlaMovies"** | Run `python -m crawler streams`. If pages come back blocked (403, "Just a moment"), you are on a datacenter/VPN IP — run it from a residential connection and let the stealth fallback pass the challenge once. If items are marked `gated`, set `OLA_ACCOUNT_COOKIE` (see above). |
| **Streams say "Open on OMDrive … set OLA_DRIVE_COOKIE"** | The OMDrive file link couldn't be resolved to a direct URL yet. Export `OLA_DRIVE_COOKIE` from your logged-in browser (see [OMDrive download links](#omdrive-download-links)), or log in once via `python -m crawler drive <url>` with the stealth browser. After the background warm-up (or the next request), the stream turns into a playable direct link. |
| **`crawler drive` says `verification_required`** | The file's Cloudflare Turnstile isn't solved — run without `--no-browser` so the stealth browser solves it (log in once headful via `OLA_STEALTH_HEADLESS=false` if needed), or open the file page once in your own browser. |
| **`crawler drive` says `out_of_credits`** | Downloads are paid from the OMDrive account's credits — top up or export `OLA_DRIVE_COOKIE` from an account with credits. |
| **Resolved OMDrive link expired** | v1 links stay valid ~3 days; the addon re-resolves after `OLA_DRIVE_CACHE_TTL` (default 6 h) or on addon restart. Re-run `python -m crawler drive <url> --refresh` to force it. |
| **"Sorry, you have been blocked" / 403** | Cloudflare WAF blocking your IP. Residential IP + stealth fallback + (for gated links) `OLA_ACCOUNT_COOKIE`. `python -m crawler probe <item-url>` shows exactly what a fetch returns. |
| **Domain expired / links dead** | OlaMovies rotates domains; the crawler auto-resolves the current one via `olamovies.dad` (cached for `OLA_DOMAIN_TTL` seconds). Check with `python -m crawler domain`; update `OLA_FALLBACK_DOMAINS` if the redirect endpoint ever fails. |
| **Port 8787 already in use** | Run uvicorn on another port (`--port 8788`) or set `PORT` with `python -m app.main`, and install Stremio with the matching URL. |
| **Stale data / missing new releases** | Re-run `python -m crawler catalog` — upserts everything and refreshes posters/sizes; the cursor reset after a completed run picks up newly added items. |
| **Docker: DB read-only / permission errors** | The container runs as non-root (uid 1000). Make the mounted dir writable: `sudo chown -R 1000:1000 ./data`. |

---

## Disclaimer

This project is for **personal and educational use**. It only indexes publicly
available pages and does not host, rehost, or proxy any content: all download
links point to the original OlaMovies pages and file hosts, and all catalog
metadata (posters, ratings) is referenced from public sources. The project is
not affiliated with, endorsed by, or connected to OlaMovies in any way. Please
respect the site, its rules and its infrastructure (the crawler is deliberately
polite and resumable — keep `OLA_CRAWL_DELAY` reasonable). You alone are
responsible for what you download and for complying with the laws that apply
to you.
