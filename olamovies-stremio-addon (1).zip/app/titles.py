"""Parse OlaMovies release-style titles.

Site titles look like:
    "Bon Appetit Your Majesty (2025) Season 1 S01"
    "[Season 1-2] MobLand (2025) S01-S02"
    "The Gray Man (2022) 720p + 1080p + 2160p 4K NF WEB-DL x265 10bit HEVC ..."
    "KPop Demon Hunters (2025)"

We need: clean name, year, and a human-friendly release description.
"""
import re
from typing import Optional

_YEAR_RE = re.compile(r"\((\d{4})\)")
_SEASON_PREFIX_RE = re.compile(r"^\s*\[?\s*Season[\s\d\-–~to]*\]?\s*", re.I)
_SEASON_INFIX_RE = re.compile(
    r"\s*(?:\[\s*Season[\s\d\-–~to]*\s*\]|Season\s*\d+(?:\s*[-–~to]+\s*\d+)?|S\d{1,2}\s*[-–~]\s*S\d{1,2}|S\d{1,2}(?!\w))\s*$",
    re.I,
)


def parse_title(raw: str) -> dict:
    """Return {name, year, release_desc} from a raw site title."""
    if not raw:
        return {"name": "", "year": None, "release_desc": ""}

    title = raw.strip()

    # Year: first (YYYY) group
    year: Optional[int] = None
    m = _YEAR_RE.search(title)
    if m:
        year = int(m.group(1))

    # Name: text before the year group (or whole title if no year)
    if m:
        name = title[: m.start()].strip()
        rest = title[m.end():].strip()
    else:
        name = title
        rest = ""

    # Strip leading "[Season 1-2]" style prefixes from the name
    name = _SEASON_PREFIX_RE.sub("", name).strip(" -–—:[]()")

    # Build release description: year + everything after (seasons/quality)
    parts = []
    if rest:
        # drop trailing season markers from description for cleanliness
        desc = rest.strip(" -–—:[](),")
        parts.append(desc)
    release_desc = " ".join(parts).strip()
    if year and release_desc:
        release_desc = f"{year} · {release_desc}"
    elif year:
        release_desc = str(year)

    return {"name": name or title, "year": year, "release_desc": release_desc}


# Quality/size helpers used when building stream labels -----------------------

QUALITY_RE = re.compile(
    r"(2160p|1080p|720p|480p|4K|8K|UHD|REMUX|BluRay|WEB-?DL|WEB-?Rip|HDR10\+?|DV|SDR|60FPS|IMAX|3D)",
    re.I,
)
SIZE_RE = re.compile(r"(\d+(?:\.\d+)?)\s*(GB|MB|TB)\b", re.I)


def extract_qualities(text: str) -> list:
    """Extract ordered unique quality tokens from a release string."""
    seen, out = set(), []
    for m in QUALITY_RE.finditer(text or ""):
        tok = m.group(1).upper().replace("-", "")
        if tok not in seen:
            seen.add(tok)
            out.append(m.group(1))
    return out


def extract_size(text: str) -> Optional[str]:
    m = SIZE_RE.search(text or "")
    if not m:
        return None
    return f"{m.group(1)} {m.group(2).upper()}"


def guess_season_episode(text: str) -> tuple:
    """Best-effort (season, episode) from a filename like 'S01E05' / 'Season 2 Ep 3'."""
    m = re.search(r"[Ss](\d{1,2})[\s._-]*[Ee](\d{1,3})", text or "")
    if m:
        return int(m.group(1)), int(m.group(2))
    m = re.search(r"Season\s*(\d{1,2}).*?Episode\s*(\d{1,3})", text or "", re.I)
    if m:
        return int(m.group(1)), int(m.group(2))
    return None, None


if __name__ == "__main__":
    samples = [
        "Bon Appetit Your Majesty (2025) Season 1 S01",
        "[Season 1-2] MobLand (2025) S01-S02",
        "The Gray Man (2022) 720p + 1080p + 2160p 4K NF WEB-DL x265 10bit HEVC Multi Audio [Hindi + English] DDP 5.1 Atmos MSubs",
        "KPop Demon Hunters (2025)",
        "Spider-Man: Brand New Day (2026) IMAX 720p + 1080p + 2160p 4K MA-BCORE WEB-DL x265 10bit HEVC Multi Audio",
        "Louis C.K.: Ridiculous (2026)",
        "No Year Movie",
    ]
    for s in samples:
        r = parse_title(s)
        print(f"{s!r}\n  -> name={r['name']!r} year={r['year']} desc={r['release_desc']!r}")
