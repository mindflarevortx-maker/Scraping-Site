"""SQLite persistence layer for the OlaMovies addon + crawler.

Single database file holds:
  items   — one row per movie/series (catalog data, IMDb-keyed)
  streams — resolved download/stream links per item (and per episode for series)
  state   — crawler bookkeeping (pagination cursors, domain cache, ...)
"""
import json
import sqlite3
import threading
import time
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Optional

from app import config

_SCHEMA = """
CREATE TABLE IF NOT EXISTS items (
    imdb_id         TEXT PRIMARY KEY,
    media_type      TEXT NOT NULL,              -- 'movie' | 'series'
    site_category   TEXT,                       -- 'movies' | 'tv-series' | 'tv-shows'
    title           TEXT NOT NULL,              -- raw title as the site shows it
    name            TEXT,                       -- parsed clean name
    year            INTEGER,
    poster_url      TEXT,
    site_url        TEXT,
    slug            TEXT,
    size_label      TEXT,
    imdb_rating     TEXT,
    release_desc    TEXT,                       -- quality/audio summary
    stream_status   TEXT DEFAULT 'pending',     -- pending|crawled|gated|error|empty
    stream_detail   TEXT,                       -- JSON summary of what was found
    last_crawled_at TEXT,
    first_seen_at   TEXT,
    updated_at      TEXT
);
CREATE INDEX IF NOT EXISTS idx_items_type    ON items(media_type, site_category);
CREATE INDEX IF NOT EXISTS idx_items_updated ON items(updated_at);

CREATE TABLE IF NOT EXISTS streams (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    imdb_id     TEXT NOT NULL,
    season      INTEGER,                       -- NULL for movies
    episode     INTEGER,                       -- NULL for movies
    label       TEXT,                          -- human label shown in Stremio
    quality     TEXT,
    size        TEXT,
    host        TEXT,
    url         TEXT NOT NULL,
    kind        TEXT NOT NULL,                 -- direct|gdrive|page|folder
    created_at  TEXT
);
CREATE INDEX IF NOT EXISTS idx_streams_item ON streams(imdb_id, season, episode);

CREATE TABLE IF NOT EXISTS state (
    key   TEXT PRIMARY KEY,
    value TEXT
);
"""

_local = threading.local()


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def conn() -> sqlite3.Connection:
    """Thread-local connection (FastAPI runs with threads)."""
    c = getattr(_local, "conn", None)
    if c is None:
        config.DB_PATH.parent.mkdir(parents=True, exist_ok=True)
        c = sqlite3.connect(str(config.DB_PATH), timeout=30)
        c.row_factory = sqlite3.Row
        c.executescript(_SCHEMA)
        _local.conn = c
    return c


@contextmanager
def tx():
    c = conn()
    try:
        yield c
        c.commit()
    except Exception:
        c.rollback()
        raise


# ------------------------------------------------------------------ items --

CATEGORY_TO_TYPE = {"movies": "movie", "tv-series": "series", "tv-shows": "series"}


def upsert_item(cur, *, imdb_id: str, media_type: str, site_category: Optional[str],
                title: str, name: Optional[str] = None, year: Optional[int] = None,
                poster_url: Optional[str] = None, site_url: Optional[str] = None,
                slug: Optional[str] = None, size_label: Optional[str] = None,
                imdb_rating: Optional[str] = None, release_desc: Optional[str] = None) -> bool:
    """Insert or refresh an item. Returns True when a new row was created."""
    now = _now()
    exists = cur.execute("SELECT 1 FROM items WHERE imdb_id=?", (imdb_id,)).fetchone() is not None
    if exists:
        cur.execute(
            """UPDATE items SET media_type=COALESCE(?, media_type),
                               site_category=COALESCE(?, site_category),
                               title=?, name=COALESCE(?, name), year=COALESCE(?, year),
                               poster_url=COALESCE(?, poster_url),
                               site_url=COALESCE(?, site_url), slug=COALESCE(?, slug),
                               size_label=COALESCE(?, size_label),
                               imdb_rating=COALESCE(?, imdb_rating),
                               release_desc=COALESCE(?, release_desc),
                               updated_at=?
             WHERE imdb_id=?""",
            (media_type, site_category, title, name, year, poster_url, site_url,
             slug, size_label, imdb_rating, release_desc, now, imdb_id),
        )
        return False
    cur.execute(
        """INSERT INTO items (imdb_id, media_type, site_category, title, name, year,
                              poster_url, site_url, slug, size_label, imdb_rating,
                              release_desc, stream_status, first_seen_at, updated_at)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?, 'pending', ?, ?)""",
        (imdb_id, media_type, site_category, title, name, year, poster_url,
         site_url, slug, size_label, imdb_rating, release_desc, now, now),
    )
    return True


def get_item(imdb_id: str) -> Optional[sqlite3.Row]:
    return conn().execute("SELECT * FROM items WHERE imdb_id=?", (imdb_id,)).fetchone()


def catalog_items(media_type: str, site_category: Optional[str] = None,
                  search: Optional[str] = None, skip: int = 0, limit: int = 100):
    q = ["SELECT * FROM items WHERE media_type=?"]
    args: list[Any] = [media_type]
    if site_category:
        q.append("AND site_category=?")
        args.append(site_category)
    if search:
        q.append("AND (name LIKE ? OR title LIKE ?)")
        like = f"%{search}%"
        args += [like, like]
    q.append("ORDER BY COALESCE(updated_at, first_seen_at) DESC LIMIT ? OFFSET ?")
    args += [limit, skip]
    return conn().execute(" ".join(q), args).fetchall()


def count_items(media_type: Optional[str] = None, site_category: Optional[str] = None) -> int:
    q = ["SELECT COUNT(*) c FROM items WHERE 1=1"]
    args: list[Any] = []
    if media_type:
        q.append("AND media_type=?")
        args.append(media_type)
    if site_category:
        q.append("AND site_category=?")
        args.append(site_category)
    return conn().execute(" ".join(q), args).fetchone()["c"]


def pending_stream_items(limit: int = 50, media_type: Optional[str] = None):
    q = ["SELECT * FROM items WHERE stream_status IN ('pending','error')"]
    args: list[Any] = []
    if media_type:
        q.append("AND media_type=?")
        args.append(media_type)
    q.append("ORDER BY COALESCE(updated_at, first_seen_at) DESC LIMIT ?")
    args.append(limit)
    return conn().execute(" ".join(q), args).fetchall()


def set_stream_result(imdb_id: str, status: str, detail: Any,
                      streams: Optional[Iterable[dict]] = None) -> None:
    now = _now()
    with tx() as c:
        c.execute(
            "UPDATE items SET stream_status=?, stream_detail=?, last_crawled_at=?, updated_at=? WHERE imdb_id=?",
            (status, json.dumps(detail, ensure_ascii=False)[:100000] if detail is not None else None,
             now, now, imdb_id),
        )
        if streams is not None:
            c.execute("DELETE FROM streams WHERE imdb_id=?", (imdb_id,))
            for s in streams:
                c.execute(
                    """INSERT INTO streams (imdb_id, season, episode, label, quality,
                                            size, host, url, kind, created_at)
                       VALUES (?,?,?,?,?,?,?,?,?,?)""",
                    (imdb_id, s.get("season"), s.get("episode"), s.get("label"),
                     s.get("quality"), s.get("size"), s.get("host"), s.get("url"),
                     s.get("kind", "page"), now),
                )


def streams_for(imdb_id: str, season: Optional[int] = None, episode: Optional[int] = None):
    q = "SELECT * FROM streams WHERE imdb_id=?"
    args: list[Any] = [imdb_id]
    if season is not None:
        q += " AND (season IS NULL OR season=?)"
        args.append(season)
    if episode is not None and season is not None:
        q += " AND (episode IS NULL OR episode=?)"
        args.append(episode)
    q += " ORDER BY id"
    return conn().execute(q, args).fetchall()


# ----------------------------------------------------------------- state --

def get_state(key: str, default: Optional[str] = None) -> Optional[str]:
    row = conn().execute("SELECT value FROM state WHERE key=?", (key,)).fetchone()
    return row["value"] if row else default


def set_state(key: str, value: str) -> None:
    with tx() as c:
        c.execute(
            "INSERT INTO state (key, value) VALUES (?,?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (key, value),
        )


def stats() -> dict:
    c = conn()
    out = {
        "items": c.execute("SELECT COUNT(*) c FROM items").fetchone()["c"],
        "movies": c.execute("SELECT COUNT(*) c FROM items WHERE media_type='movie'").fetchone()["c"],
        "series": c.execute("SELECT COUNT(*) c FROM items WHERE media_type='series'").fetchone()["c"],
        "streams": c.execute("SELECT COUNT(*) c FROM streams").fetchone()["c"],
        "crawled": c.execute("SELECT COUNT(*) c FROM items WHERE stream_status='crawled'").fetchone()["c"],
        "gated": c.execute("SELECT COUNT(*) c FROM items WHERE stream_status='gated'").fetchone()["c"],
        "pending": c.execute("SELECT COUNT(*) c FROM items WHERE stream_status='pending'").fetchone()["c"],
        "db_path": str(config.DB_PATH),
        "db_size_bytes": (Path(config.DB_PATH).stat().st_size if Path(config.DB_PATH).exists() else 0),
        "generated_at": _now(),
    }
    return out


if __name__ == "__main__":
    print(json.dumps(stats(), indent=2))
