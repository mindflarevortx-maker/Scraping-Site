"""Single-item URL resolution for the OlaMovies crawler CLI.

``python -m crawler url <query>`` finds ONE item in the local database (by
IMDb id / synthetic ``ola:`` id, or through a case-insensitive title search
over both ``name`` and ``title``) and prints its download/watch links.  When
the stored stream_status is 'pending'/'error' (or ``--refresh`` is given) the
live item page is fetched first via crawler.site.crawl_item — the same
Cloudflare-aware path the batch ``crawler streams`` command uses.

Examples:

    python -m crawler url "attack on titan"                # list matches
    python -m crawler url tt2560140 --season 1 --episode 5 # resolve one item
    python -m crawler url "the gray man" --refresh --json  # force re-fetch, JSON out

On a datacenter/VPN IP the site's WAF blocks the fetch; that surfaces here as
a clear 'error' status with guidance (and exit code 1) instead of a traceback.
"""
import json
import re
import sqlite3
import sys
from typing import Optional

from app import db

# Item-id shaped queries skip the LIKE search entirely.
_ID_RE = re.compile(r"^(tt\d+|ola:\S+)$")

# Statuses that make resolve() re-attempt the live page fetch.
_STALE_STATUSES = ("pending", "error")

CF_GUIDANCE = (
    "Blocked by Cloudflare (datacenter/VPN IP?) — run from a residential "
    "connection, or set OLA_ACCOUNT_COOKIE if the item is login-gated."
)


def _log(msg: str, json_output: bool = False) -> None:
    """Human progress line; kept off stdout when --json is active."""
    print(f"[url] {msg}", file=sys.stderr if json_output else sys.stdout, flush=True)


# ---------------------------------------------------------------- search ----

def search_items(query: str, limit: int = 20) -> list[sqlite3.Row]:
    """Find catalog items for a `url` query.

    * query looks like an item id (``tt\\d+`` or ``ola:...``) → exact lookup;
    * otherwise case-insensitive LIKE over BOTH name and title, across both
      media types, best candidates first (exact name match, then shortest
      name, then newest year).
    """
    q = (query or "").strip()
    if not q:
        return []
    if _ID_RE.match(q):
        row = db.get_item(q)
        return [row] if row else []

    like = f"%{q}%"
    return db.conn().execute(
        """
        SELECT * FROM items
        WHERE (LOWER(COALESCE(name, '')) LIKE LOWER(?)
               OR LOWER(title) LIKE LOWER(?))
        ORDER BY (LOWER(COALESCE(name, title)) = LOWER(?)) DESC,
                 LENGTH(COALESCE(name, title)) ASC,
                 COALESCE(year, 0) DESC,
                 COALESCE(updated_at, first_seen_at) DESC
        LIMIT ?
        """,
        (like, like, q, limit),
    ).fetchall()


# --------------------------------------------------------------- resolve ----

def _print_stream_table(streams: list) -> None:
    """kind / quality / size / label columns, then the URL — always in full."""
    keys = ("kind", "quality", "size", "label")
    headers = ("KIND", "QUALITY", "SIZE", "LABEL")

    def cell(s: dict, k: str) -> str:
        return "" if s[k] is None else str(s[k])

    widths = {
        k: max(len(h), max((len(cell(s, k)) for s in streams), default=0))
        for k, h in zip(keys, headers)
    }
    # keep the URL column reachable; long labels overflow the column but are
    # never truncated.
    widths["label"] = min(widths["label"], 48)

    print("  " + "  ".join(h.ljust(widths[k]) for k, h in zip(keys, headers)) + "  URL")
    for s in streams:
        left = "  " + "  ".join(cell(s, k).ljust(widths[k]) for k in keys)
        print(f"{left}  {s['url']}")


def _print_resolved_direct_links(streams: list) -> None:
    """Fast-path-resolve omd-drive streams and print the direct v1 links
    (or one guidance line when none resolve). HTTP only — no browser."""
    from crawler import drive as drive_mod  # lazy: only needed for omd-drive
    resolved = []
    for s in streams:
        if s.get("kind") != "omd-drive":
            continue
        try:
            res = drive_mod.resolve_cached(s["url"])
        except Exception:  # noqa: BLE001
            res = None
        if res and res.get("v1"):
            resolved.append((s, res))
    print()
    if resolved:
        print("RESOLVED DIRECT LINKS (OMDrive):")
        for s, res in resolved:
            print(f"  {s.get('label') or s['url']}")
            print(f"    {res['v1']}")
    else:
        print("no OMDrive direct links resolved yet — set OLA_DRIVE_COOKIE, or run: "
              "python -m crawler drive <url>")


def resolve(imdb_id: str, season: Optional[int] = None, episode: Optional[int] = None,
            refresh: bool = False, json_output: bool = False) -> int:
    """Print the download/watch links for one item.

    Returns a process exit code: 0 = links shown, 1 = no links (fetch error /
    gated / empty / no episode match), 2 = unknown id.
    """
    row = db.get_item(imdb_id)
    if row is None:
        _log(f"{imdb_id} not found — try: python -m crawler url '<title>'", json_output)
        return 2

    display = row["name"] or row["title"]
    status = row["stream_status"]

    if episode is not None and season is None:
        _log("note: --episode without --season has no effect (episode is only "
             "filtered within a season)", json_output)

    if refresh or status in _STALE_STATUSES:
        if row["site_url"]:
            from crawler import site  # lazy: keeps scrapling out of plain searches
            _log(f"resolving {imdb_id} ({display}) from {row['site_url']} ...", json_output)
            try:
                status, detail, links = site.crawl_item(
                    row["site_url"], imdb_id, row["media_type"])
            except Exception as e:  # noqa: BLE001
                status, detail, links = "error", {"reason": f"{type(e).__name__}: {e}"}, []
            db.set_stream_result(imdb_id, status, detail, links)
            reason = detail.get("reason") if isinstance(detail, dict) else None
            _log(f"status: {status}" + (f" ({reason})" if reason else ""), json_output)
            if status == "error":
                _log(CF_GUIDANCE, json_output)
            elif status == "gated":
                _log("login-gated — set OLA_ACCOUNT_COOKIE and re-run with --refresh",
                     json_output)
        else:
            _log(f"{imdb_id} has no site_url stored — cannot fetch the live page",
                 json_output)

    streams = db.streams_for(imdb_id, season, episode)

    if not streams and season is not None:
        total = len(db.streams_for(imdb_id))
        if total:
            ep = f" episode {episode}" if episode is not None else ""
            _log(f"note: {total} link(s) exist for this item, but none match "
                 f"season {season}{ep}", json_output)

    stream_dicts = [
        {
            "url": s["url"], "label": s["label"], "size": s["size"],
            "quality": s["quality"], "host": s["host"], "kind": s["kind"],
            "season": s["season"], "episode": s["episode"],
        }
        for s in streams
    ]

    if json_output:
        print(json.dumps({
            "imdb_id": imdb_id,
            "title": display,
            "year": row["year"],
            "media_type": row["media_type"],
            "status": status,
            "season": season,
            "episode": episode,
            "streams": stream_dicts,
        }, indent=2, ensure_ascii=False))
    else:
        where = ""
        if season is not None:
            where = f" · S{season:02d}"
            if episode is not None:
                where += f"E{episode:02d}"
        _log(f"{display} ({row['year'] or '?'}) · {row['media_type']} · {imdb_id}{where}")
        if streams:
            _print_stream_table(stream_dicts)
        else:
            _log("no links stored for this item")
        print(f"→ {len(streams)} link(s)")
        if any(s["kind"] == "omd-drive" for s in stream_dicts):
            _print_resolved_direct_links(stream_dicts)

    return 0 if streams else 1


# ------------------------------------------------------------------ cli ----

def cmd_url(query: str, season: Optional[int] = None, episode: Optional[int] = None,
            refresh: bool = False, json_output: bool = False, limit: int = 20) -> int:
    """CLI entry point for ``python -m crawler url``."""
    matches = search_items(query, limit=limit)
    if not matches:
        print(f"no items match {query!r} — try: python -m crawler url '<title>'")
        return 2

    best = matches[0]

    # A season/episode filter means the user already knows which item they
    # want — resolve the best match directly instead of listing candidates.
    if len(matches) == 1 or season is not None or episode is not None:
        if len(matches) > 1:
            note = (f"{len(matches)} matches for {query!r} — using best match "
                    f"{best['imdb_id']} ({best['name'] or best['title']})")
            print(note, file=sys.stderr if json_output else sys.stdout)
        return resolve(best["imdb_id"], season=season, episode=episode,
                       refresh=refresh, json_output=json_output)

    print(f"{len(matches)} item(s) match {query!r}:")
    for i, row in enumerate(matches, 1):
        print(f"  {i:>2}. {row['imdb_id']}  {row['name'] or row['title']}"
              f" ({row['year'] or '?'})  [{row['media_type']}]  {row['stream_status']}")
    print()
    print("re-run with an IMDb id to resolve one item, e.g.:")
    print(f"  python -m crawler url {best['imdb_id']}")
    print(f"  python -m crawler url {best['imdb_id']} --season 1 --episode 5")
    if len(matches) >= limit:
        print(f"(showing the first {limit} — use --limit N to see more)")
    return 0


if __name__ == "__main__":
    sys.exit(cmd_url(sys.argv[1] if len(sys.argv) > 1 else ""))
