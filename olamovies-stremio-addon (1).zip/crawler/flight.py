"""Next.js RSC 'flight data' extraction.

OlaMovies (and its sister sites) are Next.js App-Router apps. Every server-
rendered page embeds its full data payload as a sequence of:

    <script>self.__next_f.push([1,"...escaped json..."])</script>

chunks. Joining and un-escaping those chunks yields a stream that contains the
page's structured data (item records, links, pagination, ...). This module
extracts that stream and provides helpers to mine it — far more robust than
DOM scraping against a React app.
"""
import json
import re
from typing import Any, Iterable, Optional

_CHUNK_RE = re.compile(r'<script>self\.__next_f\.push\(\[1,"(.*?)"\]\)</script>', re.S)

_ESCAPES = {
    "\\\\": "\\",
    '\\"': '"',
    "\\n": "\n",
    "\\t": "\t",
    "\\r": "\r",
    "\\/": "/",
    "\\b": "\b",
    "\\f": "\f",
}


def _unescape(s: str) -> str:
    # Process escape sequences left-to-right (order matters for \\").
    out, i, n = [], 0, len(s)
    while i < n:
        ch = s[i]
        if ch == "\\" and i + 1 < n:
            nxt = s[i + 1]
            pair = ch + nxt
            if pair in _ESCAPES:
                out.append(_ESCAPES[pair])
                i += 2
                continue
            if nxt == "u" and i + 5 < n:
                try:
                    out.append(chr(int(s[i + 2:i + 6], 16)))
                    i += 6
                    continue
                except ValueError:
                    pass
        out.append(ch)
        i += 1
    return "".join(out)


def extract_flight(html: str) -> str:
    """Extract and join all __next_f payload chunks from an SSR'd page."""
    if not html:
        return ""
    return "".join(_unescape(m.group(1)) for m in _CHUNK_RE.finditer(html))


# --------------------------------------------------------------- mining ----

def find_json_objects(stream: str, required_keys: Iterable[str],
                      max_len: int = 4000) -> list:
    """Find JSON object literals containing all required keys.

    Scans brace-balanced regions starting at every '{' whose next char is '"'
    and parses candidates. Returns a list of dicts.
    """
    wanted = set(required_keys)
    found: list[dict] = []
    n = len(stream)
    for i, ch in enumerate(stream):
        if ch != "{" or i + 1 >= n or stream[i + 1] != '"':
            continue
        depth = 0
        in_str = False
        esc = False
        for j in range(i, min(i + max_len, n)):
            c = stream[j]
            if in_str:
                if esc:
                    esc = False
                elif c == "\\":
                    esc = True
                elif c == '"':
                    in_str = False
                continue
            if c == '"':
                in_str = True
            elif c == "{":
                depth += 1
            elif c == "}":
                depth -= 1
                if depth == 0:
                    candidate = stream[i:j + 1]
                    if all(f'"{k}"' in candidate for k in wanted):
                        try:
                            obj = json.loads(candidate)
                            if isinstance(obj, dict):
                                found.append(obj)
                        except (json.JSONDecodeError, ValueError):
                            pass
                    break
    return found


_IMDB_KEY_RE = re.compile(r'"key":"(tt\d+)","title":"([^"]*)"')


def space_board_records(flight: str) -> list:
    """Extract item records from a space.olamovies.dad board page's flight stream.

    Records look like: {"key":"tt37600136","title":"...","posterUrl":"https://...","url":"https://v6.olamovies.mov/tv-series/<slug>"}
    Returns [{imdb_id, title, poster_url, url, slug, site_category, media_type}]
    """
    records = []
    stream = flight
    # Normalize positions of "item":{"key":... patterns — records live inside {"item":{...}}
    for m in re.finditer(r'"item":\{"key":"(tt\d+)","title":"((?:[^"\\]|\\.)*)","posterUrl":"([^"]*)","url":"([^"]*)"', stream):
        imdb_id, title, poster, url = m.group(1), m.group(2), m.group(3), m.group(4)
        title = json.loads(f'"{title}"') if "\\" in title else title
        records.append(_record(imdb_id, title, poster, url))

    if not records:  # fallback: bare key records (ready board shape)
        for m in re.finditer(r'\{"_id":"[^"]*","title":"((?:[^"\\]|\\.)*)"', stream):
            pass  # ready-board records don't carry the v6 url in the same shape
    return records


def _record(imdb_id: str, title: str, poster: str, url: str) -> dict:
    slug = site_category = media_type = None
    if url:
        m = re.search(r"olamovies\.mov/(movies|tv-series|tv-shows)/([^/?#]+)", url)
        if m:
            site_category = m.group(1)
            slug = m.group(2)
            media_type = "movie" if site_category == "movies" else "series"
    return {
        "imdb_id": imdb_id,
        "title": title,
        "poster_url": poster or None,
        "url": url or None,
        "slug": slug,
        "site_category": site_category,
        "media_type": media_type,
    }


def space_board_meta(flight: str) -> dict:
    """Extract {'page': int, 'totalPages': int, 'counts': {...}} from a board page."""
    out = {"page": None, "totalPages": None}
    m = re.search(r'"page":(\d+),"totalPages":(\d+)', flight)
    if m:
        out["page"], out["totalPages"] = int(m.group(1)), int(m.group(2))
    return out


# \d[\d,]* — the board renders sizes with thousands separators ("1,013 GB");
# without the comma class the match would start mid-number and yield "013 GB".
_SIZE_SPAN_RE = re.compile(r'(\d[\d,]*(?:\.\d+)?\s*(?:GB|MB|TB))(?: · IMDb ([\d.]+))?')


def space_size_spans(flight: str) -> list:
    """Ordered (size, imdb_rating) spans — one per card, positionally aligned
    with the records returned by space_board_records()."""
    return [(m.group(1), m.group(2)) for m in _SIZE_SPAN_RE.finditer(flight)]


def extract_links(html_or_flight: str, base_url: str = "") -> list:
    """Generic link harvest from HTML or a flight stream.

    Returns [{url, text}] for http(s) links plus site-relative links.
    """
    src = html_or_flight or ""
    links, seen = [], set()
    for m in re.finditer(r'href="([^"]+)"[^>]*>([^<]{0,200})<', src):
        url, text = m.group(1).strip(), m.group(2).strip()
        if url.startswith("/"):
            url = (base_url.rstrip("/") + url) if base_url else url
        if url.startswith("http"):
            key = (url, text)
            if key not in seen:
                seen.add(key)
                links.append({"url": url, "text": text})
    # flight-shape: {"name":"...","slug":"...","href":"/f/xxx"}
    for m in re.finditer(r'\{"name":"((?:[^"\\]|\\.)*)","slug":"([^"]*)","href":"([^"]*)"', src):
        name = m.group(1)
        url = m.group(3)
        if url.startswith("/"):
            url = (base_url.rstrip("/") + url) if base_url else url
        if url not in seen:
            seen.add(url)
            links.append({"url": url, "text": name})
    return links


DRIVE_HOSTS = ("drive.google.com", "docs.google.com")

# OlaMovies' own file host ("OMDrive V3") file pages.
OMD_DRIVE_HOST = "drive.olamovies.download/file/"


def classify_link(url: str) -> str:
    """Bucket a link into: direct | gdrive | folder | page | omd-drive."""
    low = (url or "").lower()
    if OMD_DRIVE_HOST in low:
        return "omd-drive"
    if any(h in low for h in DRIVE_HOSTS):
        return "gdrive"
    if low.endswith((".mp4", ".mkv", ".webm", ".m3u8", ".avi", ".mov", ".ts")):
        return "direct"
    if low.endswith("/") and low.count("/") <= 4:
        return "folder"
    return "page"
