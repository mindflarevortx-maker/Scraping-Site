"""v6.olamovies.mov item-page crawler → stream extraction.

Runs on YOUR machine (residential connection) — see fetcher.py for why.

For every item in the DB whose stream_status is 'pending', fetch the item page,
extract the download structures from the Next.js flight data (plus DOM links
as fallback), classify them, and store stream rows.

The site gates downloads behind a free account ("sign in to play & download").
If a login wall is detected the item is marked 'gated' and the addon will fall
back to an "open on OlaMovies" entry. Set OLA_ACCOUNT_COOKIE (cookie string
exported from your logged-in browser) to resolve real links.
"""
import re
import time
from typing import Optional

from app import config, db, titles
from crawler import flight as fl
from crawler import drive as drv
from crawler import fetcher as fetch_mod

GATE_MARKERS = (
    "sign in to play", "sign in to download", "login to download",
    "log in to play", "sign in to continue", "free account",
)

DRIVE_LINK_RE = re.compile(r"https?://(?:drive|docs)\.google\.com/[^\s\"'<>\\]+")
MEDIA_URL_RE = re.compile(
    r"https?://[^\s\"'<>\\]+\.(?:mp4|mkv|webm|m3u8|avi|mov|ts)(?:\?[^\s\"'<>\\]*)?",
    re.I,
)

# /f/<id> download pages on the current/fallback OlaMovies domain.
_F_LINK_RE = re.compile(r"^https?://([^/?#]+)/f/([A-Za-z0-9_-]+)/?$")


def _log(msg: str) -> None:
    print(f"[site] {msg}", flush=True)


def _flight_download_links(stream: str) -> list:
    """Harvest candidate download links from an item page's flight stream."""
    out, seen = [], set()

    def add(url: str, label: str, extra: dict):
        if not url or url in seen:
            return
        seen.add(url)
        size = extra.get("size") or titles.extract_size(label or url)
        quality = extra.get("quality") or (titles.extract_qualities(label or url) or [None])[0]
        season, episode = titles.guess_season_episode(label or "")
        out.append({
            "url": url,
            "label": label or url,
            "size": size,
            "quality": quality,
            "host": re.sub(r"^https?://([^/]+).*", r"\1", url),
            "kind": fl.classify_link(url),
            "season": season,
            "episode": episode,
        })

    # Google Drive links anywhere in the payload
    for m in DRIVE_LINK_RE.finditer(stream):
        add(m.group(0), "", {})
    # direct media files
    for m in MEDIA_URL_RE.finditer(stream):
        add(m.group(0), "", {})

    # Structured link objects: {"name":"... 1080p ...","href":"/f/xxx"} etc.
    for m in re.finditer(r'\{"name":"((?:[^"\\]|\\.){3,200})","slug":"[^"]*","href":"([^"]+)"', stream):
        label, href = m.group(1), m.group(2)
        if href.startswith("/"):
            href = config.FALLBACK_DOMAINS[0].rstrip("/") + href if config.FALLBACK_DOMAINS else href
        add(href, label, {})

    # Generic objects that carry a url + name
    for obj in fl.find_json_objects(stream, ("name", "url")):
        url = obj.get("url") or ""
        if not isinstance(url, str) or not url.startswith("http"):
            continue
        name = obj.get("name") or ""
        size = obj.get("size") or obj.get("sizeLabel") or obj.get("size_label")
        if isinstance(size, (int, float)):
            size = f"{size} GB"
        quality = obj.get("quality") or obj.get("resolution")
        add(url, name, {"size": size, "quality": quality})

    return out


def _dom_download_links(html: str, base_url: str) -> list:
    """Fallback: pull interesting anchors out of the rendered DOM."""
    out = []
    for link in fl.extract_links(html, base_url):
        url, text = link["url"], link["text"]
        low = text.lower() + url.lower()
        interesting = (
            "drive.google.com" in url
            or "drive.olamovies.download" in url
            or any(q in low for q in ("720p", "1080p", "2160p", "4k", "download", "mkv", "mp4"))
        )
        if not interesting:
            continue
        season, episode = titles.guess_season_episode(text)
        out.append({
            "url": url,
            "label": text or url,
            "size": titles.extract_size(text),
            "quality": (titles.extract_qualities(text) or [None])[0],
            "host": re.sub(r"^https?://([^/]+).*", r"\1", url),
            "kind": fl.classify_link(url),
            "season": season,
            "episode": episode,
        })
    return out


# ------------------------------------------------------- OMDrive links ----

def _site_hosts(site_url: str) -> set:
    """Hosts that count as 'our' OlaMovies site (current + fallback domains)."""
    hosts = set()
    for domain in [site_url] + list(config.FALLBACK_DOMAINS):
        m = re.match(r"^https?://([^/?#]+)", domain or "")
        if m:
            hosts.add(m.group(1).lower())
    return hosts


def _is_f_page_link(url: str, site_hosts: set) -> bool:
    """True for /f/<id> download-page links on the OlaMovies site."""
    m = _F_LINK_RE.match(url or "")
    return bool(m) and m.group(1).lower() in site_hosts


def _drive_link(url: str, parent: Optional[dict] = None) -> dict:
    """A link dict for a drive.olamovies.download file URL; quality/size/
    season/episode/label are inherited from the parent /f/ link when known."""
    link = {
        "url": url,
        "label": "",
        "size": None,
        "quality": None,
        "host": "drive.olamovies.download",
        "kind": "omd-drive",
        "season": None,
        "episode": None,
    }
    if parent:
        link.update({
            "label": parent.get("label") or "",
            "size": parent.get("size"),
            "quality": parent.get("quality"),
            "season": parent.get("season"),
            "episode": parent.get("episode"),
        })
    return link


def _direct_drive_links(item_html: str, item_stream: str, base_url: str) -> list:
    """Drive file URLs found directly in the item payload (no /f/ hop)."""
    urls = drv.extract_drive_links((item_html or "") + "\n" + (item_stream or ""))
    if not urls:
        return []
    # anchor texts (when the URL appears in an <a href>) give better labels
    texts = {}
    for link in fl.extract_links(item_html or "", base_url):
        if link["url"] in urls and link["text"]:
            texts.setdefault(link["url"], link["text"])
    out = []
    for url in urls:
        text = texts.get(url) or ""
        out.append({
            "url": url,
            "label": text,
            "size": titles.extract_size(text) or None,
            "quality": (titles.extract_qualities(text) or [None])[0] if text else None,
            "host": "drive.olamovies.download",
            "kind": "omd-drive",
            "season": None,
            "episode": None,
        })
    return out


def _omd_drive_links(links: list, site_url: str, item_html: str,
                     item_stream: str) -> list:
    """Turn /f/<id> page links into OMDrive file links (kind 'omd-drive').

    For every /f/ page: fetch it and harvest drive.olamovies.download URLs
    from its HTML and flight stream. When drive links are found the /f/ page
    link itself is dropped (noise in Stremio); otherwise it is kept. A failed
    /f/ fetch never breaks the crawl. Drive file URLs found directly in the
    item payload are added too.
    """
    site_hosts = _site_hosts(site_url)
    out, f_links = [], []
    for l in links:
        if l.get("kind") == "page" and _is_f_page_link(l["url"], site_hosts):
            f_links.append(l)
        else:
            out.append(l)

    seen = {l["url"] for l in out}

    # drive URLs already extracted with their own labels (structured objects,
    # DOM anchors) + ones only visible as bare URLs in the payload
    for extra in _direct_drive_links(item_html, item_stream, site_url):
        if extra["url"] not in seen:
            seen.add(extra["url"])
            out.append(extra)

    for i, flink in enumerate(f_links):
        drive_urls = []
        try:
            resp = fetch_mod.get(flink["url"])
        except Exception as e:  # noqa: BLE001
            _log(f"/f/ fetch failed ({type(e).__name__}: {e}) — keeping the page link")
            resp = None
        if resp is not None:
            fhtml = resp.html_content or ""
            fstream = fl.extract_flight(fhtml)
            drive_urls = drv.extract_drive_links(fhtml + "\n" + fstream)
        if not drive_urls:
            if resp is not None:
                _log(f"no OMDrive links on {flink['url']} — keeping the page link")
            out.append(flink)
        else:
            _log(f"{flink['url']} → {len(drive_urls)} OMDrive link(s)")
            for url in drive_urls:
                if url not in seen:
                    seen.add(url)
                    out.append(_drive_link(url, flink))
        if i < len(f_links) - 1:
            time.sleep(config.CRAWL_DELAY)  # politeness between /f/ pages

    return out


def crawl_item(site_url: str, imdb_id: str, media_type: str) -> tuple:
    """Fetch one item page and return (status, detail, streams)."""
    resp = fetch_mod.get(site_url)
    if resp is None:
        return "error", {"reason": "fetch failed (Cloudflare?)"}, []

    html = resp.html_content or ""
    stream = fl.extract_flight(html)
    low = (stream or html).lower()

    links = _flight_download_links(stream) if stream else []
    if not links:
        links = _dom_download_links(html, site_url)

    # de-duplicate by url
    dedup, seen = [], set()
    for l in links:
        if l["url"] not in seen:
            seen.add(l["url"])
            dedup.append(l)
    links = dedup

    # OMDrive: follow /f/<id> download pages to their file links (and pick up
    # drive URLs found directly in the item payload)
    if config.FOLLOW_F_LINKS:
        links = _omd_drive_links(links, site_url, html, stream)

    gated = any(m in low for m in GATE_MARKERS)

    if links:
        status = "crawled"
        detail = {"links": len(links), "gated_hint": gated}
    elif gated:
        status = "gated"
        detail = {"reason": "login wall detected; set OLA_ACCOUNT_COOKIE to resolve links"}
    else:
        status = "empty"
        detail = {"reason": "no download links found in page payload"}

    # Stremio stream labels
    for l in links:
        bits = []
        if l.get("quality"):
            bits.append(str(l["quality"]))
        if l.get("size"):
            bits.append(str(l["size"]))
        if media_type == "series" and l.get("season"):
            ep = f"E{l['episode']:02d}" if l.get("episode") else ""
            bits.append(f"S{l['season']:02d}{ep}")
        bits.append(l.get("host") or "")
        l["label"] = " · ".join(b for b in bits if b) or l["url"]
    return status, detail, links


def crawl_streams(limit: int = 50, delay: float = None, media_type: Optional[str] = None) -> dict:
    """Main entry: resolve streams for pending items."""
    delay = config.CRAWL_DELAY if delay is None else delay
    rows = db.pending_stream_items(limit=limit, media_type=media_type)
    _log(f"crawling streams for {len(rows)} items (delay={delay}s)")
    counts = {"crawled": 0, "gated": 0, "empty": 0, "error": 0, "streams": 0}
    for row in rows:
        site_url = row["site_url"]
        if not site_url:
            db.set_stream_result(row["imdb_id"], "error", {"reason": "no site_url"}, [])
            counts["error"] += 1
            continue
        try:
            status, detail, streams = crawl_item(site_url, row["imdb_id"], row["media_type"])
        except Exception as e:  # noqa: BLE001
            status, detail, streams = "error", {"reason": f"{type(e).__name__}: {e}"}, []
        db.set_stream_result(row["imdb_id"], status, detail, streams)
        counts[status] = counts.get(status, 0) + 1
        counts["streams"] += len(streams)
        _log(f"{row['imdb_id']} {row['name'] or row['title']!r}: {status} ({len(streams)} links)")
        time.sleep(delay)
    _log(f"done: {counts}")
    return counts
