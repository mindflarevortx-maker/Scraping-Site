"""Catalog crawler for space.olamovies.dad (the OM Space board).

The /completed board is a structured, Cloudflare-free index of every item on
the OlaMovies site: title, IMDb id, poster, and the v6.olamovies.mov item URL,
48 items per page, ?page=N pagination, ?category= filter.

This works from ANY machine (server included) — no browser required.
"""
import time
from typing import Optional

from app import config, db, titles
from crawler import flight as fl

BOARDS = ("completed",)          # completed = everything ever finished
CATEGORIES = ("movies", "tv-series", "tv-shows")


def _log(msg: str) -> None:
    print(f"[space] {msg}", flush=True)


def _fetch(url: str):
    """Plain HTTP fetch via Scrapling's Fetcher (curl_cffi, chrome TLS)."""
    from scrapling.fetchers import Fetcher

    last_exc = None
    for attempt in range(config.CRAWL_RETRIES):
        try:
            return Fetcher.get(
                url,
                timeout=config.CRAWL_TIMEOUT,
                retries=0,
                stealthy_headers=True,
                impersonate="chrome",
            )
        except Exception as e:  # noqa: BLE001
            last_exc = e
            time.sleep(1.5 * (attempt + 1))
    raise RuntimeError(f"failed to fetch {url}: {last_exc}")


def crawl_board(board: str = "completed", category: Optional[str] = None,
                max_pages: Optional[int] = None, delay: float = None) -> dict:
    """Crawl one board (optionally one category) into the DB. Resumable."""
    delay = config.CRAWL_DELAY if delay is None else delay
    state_key = f"space:{board}:{category or 'all'}:next_page"
    page = int(db.get_state(state_key, "1"))
    total_pages: Optional[int] = None
    new_items = updated_items = 0
    pages_done = 0

    while True:
        url = f"{config.SPACE_BASE}/{board}"
        if category:
            url += f"?category={category}&page={page}"
        else:
            url += f"?page={page}"

        resp = _fetch(url)
        if resp.status != 200:
            _log(f"page {page}: HTTP {resp.status} — stopping (will resume here)")
            break
        stream = fl.extract_flight(resp.html_content)
        if not stream:
            _log(f"page {page}: no flight data — stopping")
            break

        records = fl.space_board_records(stream)
        meta = fl.space_board_meta(stream)
        spans = fl.space_size_spans(stream)
        if total_pages is None and meta["totalPages"]:
            total_pages = meta["totalPages"]
            _log(f"board={board} category={category or 'all'}: page {page}/{total_pages}")

        if not records:
            _log(f"page {page}: 0 records — board exhausted")
            db.set_state(state_key, "1")  # reset for next full run
            break

        with db.tx() as cur:
            for idx, rec in enumerate(records):
                if not rec["imdb_id"] or not rec["title"]:
                    continue
                size = rating = None
                if idx < len(spans):
                    size, rating = spans[idx]
                parsed = titles.parse_title(rec["title"])
                created = db.upsert_item(
                    cur,
                    imdb_id=rec["imdb_id"],
                    media_type=rec["media_type"] or "movie",
                    site_category=rec["site_category"],
                    title=rec["title"],
                    name=parsed["name"],
                    year=parsed["year"],
                    poster_url=rec["poster_url"],
                    site_url=rec["url"],
                    slug=rec["slug"],
                    size_label=size,
                    imdb_rating=rating,
                    release_desc=parsed["release_desc"],
                )
                new_items += int(created)
                updated_items += int(not created)
        pages_done += 1

        if total_pages and page >= total_pages:
            _log(f"page {page}/{total_pages}: reached the end")
            db.set_state(state_key, "1")
            break
        if max_pages and pages_done >= max_pages:
            _log(f"stop: max_pages={max_pages} reached (resume later from page {page + 1})")
            db.set_state(state_key, str(page + 1))
            break

        db.set_state(state_key, str(page + 1))
        page += 1
        time.sleep(delay)

    return {"board": board, "category": category, "pages_done": pages_done,
            "new_items": new_items, "updated_items": updated_items,
            "total_pages": total_pages}


def crawl_catalog(max_pages: Optional[int] = None, per_category: bool = False) -> dict:
    """Crawl the full catalog. By default crawls the mixed /completed board;
    with per_category=True it crawls each category separately (handy when you
    only want e.g. tv-series)."""
    results = []
    if per_category:
        for cat in CATEGORIES:
            results.append(crawl_board("completed", category=cat, max_pages=max_pages))
    else:
        results.append(crawl_board("completed", category=None, max_pages=max_pages))
    return {"results": results, "stats": db.stats()}
