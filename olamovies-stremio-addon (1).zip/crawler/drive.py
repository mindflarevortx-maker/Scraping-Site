"""OMDrive (drive.olamovies.download) resolver — file pages → direct download links.

Chain: GET /file/<crypt> → fileName from <title> (" - OMDrive V3" suffix stripped)
       GET /api/turnstile?crypt= → already verified?
       (browser path) StealthySession on the file page auto-solves Turnstile + POSTs /api/turnstile
       POST /api/cloud/download-links {fileId, fileName} → {success, v1}   [v1 valid ~3 days]
Auth: NextAuth session cookie for drive.olamovies.download (OLA_DRIVE_COOKIE env, or the
      stealth browser profile where the user logged in once).

The fast HTTP path (curl_cffi) works anonymously up to the auth check, so the
whole chain is probeable without an account; only the final POST needs the
session cookie (or the stealth browser, which also solves the Turnstile).

CLI: python -m crawler drive <url-or-crypt> [--json] [--refresh] [--no-browser]
"""
import html as html_mod
import json
import re
import sys
import threading
import time
from typing import Optional

from app import config
from crawler import fetcher as fetch_mod
from crawler import flight as fl

# Drive file pages: https://drive.olamovies.download/file/<crypt>
DRIVE_FILE_RE = re.compile(r"https?://drive\.olamovies\.download/file/([A-Za-z0-9_-]+)")

_TITLE_SUFFIX = " - OMDrive V3"
_TITLE_RE = re.compile(r"<title>(.*?)</title>", re.S | re.I)
_OG_TITLE_RE = re.compile(r'property="og:title"\s+content="([^"]*)"', re.I)
# Next.js App-Router flight data carries the page's crypt as
# "urlParts":["","file","<crypt>"] (escaped in the raw HTML — decode first).
_URL_PARTS_RE = re.compile(r'"urlParts":\["","file","([A-Za-z0-9_-]+)"')

# v1 links stay valid for ~3 days on OMDrive (site JS: expiresAt = now+259200).
V1_LIFETIME = 259200

# Repeat fast-path attempts at most this often after a failure (keeps addon
# stream requests snappy when resolution is not possible yet).
_NEG_CACHE_TTL = 60

DRIVE_SESSION_FILE = config.DATA_DIR / "drive-session.json"

_ERROR_GUIDANCE = {
    "Not authenticated": (
        "OMDrive login required — set OLA_DRIVE_COOKIE to the cookie string of "
        "your logged-in browser session for drive.olamovies.download "
        "(DevTools → Network → any request → Cookie header), or log in once in "
        "the stealth browser (run `python -m crawler drive <url>`)"
    ),
    "verification_required": (
        "Cloudflare Turnstile must be solved in a browser — run "
        "`python -m crawler drive <url>` (stealth browser path), or open the "
        "file page once in your own browser and retry"
    ),
    "out_of_credits": (
        "download credits exhausted on that OMDrive account — top up or switch "
        "the account whose cookies you exported"
    ),
}

# module state -----------------------------------------------------------
_CACHE: dict = {}        # crypt → {v1, file_name, expires_at, resolved_at}
_NEG_CACHE: dict = {}    # crypt → ts of the last failed fast-path attempt
_LOCK = threading.Lock()
_JSON_MODE = False       # CLI --json: route _log lines to stderr


def _log(msg: str) -> None:
    print(f"[drive] {msg}", file=sys.stderr if _JSON_MODE else sys.stdout, flush=True)


# ------------------------------------------------------------ extraction --

def extract_drive_links(text_or_html: str) -> list:
    """All unique drive.olamovies.download/file/<crypt> URLs, order-preserving.

    Works on both rendered HTML and raw Next.js flight streams.
    """
    out, seen = [], set()
    for m in DRIVE_FILE_RE.finditer(text_or_html or ""):
        url = m.group(0)
        if url not in seen:
            seen.add(url)
            out.append(url)
    return out


def parse_file_page(html: str) -> dict:
    """{"crypt", "file_name"} from an OMDrive file page.

    The page is a Next.js App-Router shell whose flight data carries only ad
    scripts — the file name lives in <title> (" - OMDrive V3" suffix), with
    og:title as a fallback; the crypt comes from the flight stream's urlParts.
    """
    out = {"crypt": None, "file_name": None}
    if not html:
        return out

    title = ""
    m = _TITLE_RE.search(html)
    if m:
        title = html_mod.unescape(m.group(1)).strip()
    if not title:
        m = _OG_TITLE_RE.search(html)
        if m:
            title = html_mod.unescape(m.group(1)).strip()
    if title.endswith(_TITLE_SUFFIX):
        title = title[:-len(_TITLE_SUFFIX)].strip()
    out["file_name"] = title or None

    m = _URL_PARTS_RE.search(fl.extract_flight(html))
    if m:
        out["crypt"] = m.group(1)
    return out


def normalize_crypt(url_or_crypt: str) -> Optional[str]:
    """Bare crypt, or the crypt inside a drive file URL; None if unusable."""
    target = (url_or_crypt or "").strip()
    if not target:
        return None
    if target.startswith(("http://", "https://")):
        m = DRIVE_FILE_RE.match(target)
        return m.group(1) if m else None
    return target


# ---------------------------------------------------------------- cookies --

def _drive_cookies() -> str:
    """Raw OLA_DRIVE_COOKIE string ("k1=v1; k2=v2") — may be empty."""
    return config.DRIVE_COOKIE or ""


def _load_drive_session() -> dict:
    """Cookies the stealth browser saved for drive.olamovies.download."""
    if DRIVE_SESSION_FILE.exists():
        try:
            return json.loads(DRIVE_SESSION_FILE.read_text()).get("cookies") or {}
        except Exception:  # noqa: BLE001
            return {}
    return {}


def _save_drive_session(cookies: dict) -> None:
    try:
        DRIVE_SESSION_FILE.write_text(json.dumps({
            "cookies": cookies, "saved_at": time.time(),
        }, indent=2))
    except Exception as e:  # noqa: BLE001
        _log(f"could not save drive session: {e}")


def _api_cookies() -> dict:
    """Cookie jar for drive API calls: fetcher session cookies overlaid with
    the stealth-browser drive session, then the OLA_DRIVE_COOKIE string
    (explicit env cookie wins)."""
    jar = dict(fetch_mod.load_session().get("cookies") or {})
    jar.update(_load_drive_session())
    for pair in _drive_cookies().split(";"):
        if "=" in pair:
            k, v = pair.split("=", 1)
            jar[k.strip()] = v.strip()
    return jar


# --------------------------------------------------------------- api calls --

def turnstile_verified(crypt: str) -> bool:
    """GET /api/turnstile?crypt= → {"verified": bool}; False on any failure."""
    try:
        resp = fetch_mod.get(
            f"{config.DRIVE_BASE}/api/turnstile?crypt={crypt}",
            allow_stealth=False, cookies=_api_cookies(),
        )
        if resp is not None and resp.status == 200:
            return bool(resp.json().get("verified"))
    except Exception:  # noqa: BLE001
        pass
    return False


def fetch_mediainfo(crypt: str) -> dict:
    """POST /api/mediainfo/get {fileId} (works ANONYMOUSLY) →
    {"file_name", "size_bytes", "duration_s"} — {} on any failure.

    The response is a full MediaInfo report:
      {"success": true, "data": {"json": {"media": {"track": [
         {"@type": "General", "CompleteName": …, "FileSize": "3154122660",
          "Duration": 5984.723, …}, …]}}}}
    CompleteName is the exact fileName /api/cloud/download-links expects.
    """
    out: dict = {}
    try:
        resp = fetch_mod.post(
            f"{config.DRIVE_BASE}/api/mediainfo/get",
            json={"fileId": crypt}, cookies=_api_cookies(),
        )
    except Exception:  # noqa: BLE001
        return out
    if resp is None or getattr(resp, "status", 0) != 200:
        return out
    try:
        data = resp.json()
        tracks = (data.get("data", {}).get("json", {})
                  .get("media", {}).get("track", []))
    except Exception:  # noqa: BLE001
        return out
    if not isinstance(tracks, list):
        return out
    for t in tracks:
        if isinstance(t, dict) and t.get("@type") == "General":
            name = t.get("CompleteName") or t.get("FileName")
            if name:
                out["file_name"] = str(name)
            try:
                out["size_bytes"] = int(t.get("FileSize") or 0) or None
            except (TypeError, ValueError):
                pass
            dur = t.get("Duration")
            if isinstance(dur, (int, float)):
                out["duration_s"] = float(dur)
            break
    return out


def fetch_download_link(crypt: str, file_name: str) -> dict:
    """POST /api/cloud/download-links {fileId, fileName} → parsed JSON dict.

    Anonymous → {"success": false, "error": "Not authenticated"}; with a
    session but unsolved Turnstile → "verification_required"; success →
    {"success": true, "v1": "https://…workers.dev/serve?t=e2…"}.
    Returns {"success": False, "error": …} on transport/parse failures.
    """
    resp = fetch_mod.post(
        f"{config.DRIVE_BASE}/api/cloud/download-links",
        json={"fileId": crypt, "fileName": file_name},
        cookies=_api_cookies(),
        headers={"referer": f"{config.DRIVE_BASE}/file/{crypt}"},
    )
    if resp is None:
        return {"success": False, "error": "network error"}
    try:
        data = resp.json()
    except Exception:  # noqa: BLE001
        return {"success": False, "error": f"http {resp.status}"}
    if not isinstance(data, dict):
        return {"success": False, "error": f"unexpected response (http {resp.status})"}
    if not data.get("success") and not data.get("error"):
        data["error"] = f"http {resp.status}"
    return data


# ------------------------------------------------------------ browser path --

def _browser_solve(file_url: str, crypt: str, file_name: str) -> dict:
    """Stealth-browser path: open the file page, let it solve its Turnstile,
    then replay the download-links POST from inside the page (in-page fetch
    carries the NextAuth session cookies). Reuses the fetcher's stealth
    config (OLA_STEALTH_* envs, persistent profile — log in once headful and
    the profile remembers). Gracefully degrades when no browser is available.
    """
    try:
        from scrapling.fetchers import StealthySession
    except Exception as e:  # noqa: BLE001
        return {"success": False, "error": "stealth browser unavailable",
                "detail": f"scrapling StealthySession import failed: {e}"}

    result: dict = {}

    def _action(page) -> None:
        # page_action return values are discarded by scrapling and exceptions
        # are swallowed — everything must go through the `result` dict.
        try:
            deadline = time.time() + 60
            verified = False
            while time.time() < deadline:
                try:
                    verified = bool(page.evaluate(
                        "async () => {"
                        f"  const r = await fetch('/api/turnstile?crypt={crypt}',"
                        "       {cache: 'no-store'});"
                        "  const d = await r.json();"
                        "  return d.verified === true;"
                        "}"))
                except Exception:  # noqa: BLE001
                    verified = False
                if verified:
                    break
                page.wait_for_timeout(2000)
            if not verified:
                result["error"] = ("turnstile not solved within 60s — not logged "
                                   "in? Run once with OLA_STEALTH_HEADLESS=false "
                                   "to log in inside the browser window")
                return
            data = page.evaluate(
                "async () => {"
                "  const r = await fetch('/api/cloud/download-links', {"
                "    method: 'POST',"
                "    headers: {'Content-Type': 'application/json'},"
                f"    body: JSON.stringify({{fileId: {json.dumps(crypt)},"
                f" fileName: {json.dumps(file_name or '')}}})"
                "  });"
                "  return await r.json();"
                "}")
            if isinstance(data, dict):
                result["response"] = data
            else:
                result["error"] = f"unexpected in-page response: {data!r}"
        except Exception as e:  # noqa: BLE001
            result["error"] = f"{type(e).__name__}: {e}"

    kwargs = dict(
        solve_cloudflare=True,
        timeout=180000,
        user_data_dir=str(config.STEALTH_PROFILE),
    )
    if config.STEALTH_CHROME_PATH:
        kwargs["executable_path"] = config.STEALTH_CHROME_PATH

    # headless first (auto), then a headful retry — that's the window the user
    # can log in / watch the Turnstile solve in.
    modes = [h for h in dict.fromkeys((fetch_mod._headless_setting(), False))
             if h is not None]
    for headless in modes:
        result.clear()
        try:
            with StealthySession(headless=headless, **kwargs) as session:
                session.fetch(file_url, timeout=120000, solve_cloudflare=True,
                              network_idle=True, page_action=_action)
                # keep the (now authenticated/solved) cookies for the fast path
                try:
                    drive_cookies = {}
                    for c in session.context.cookies():
                        if "olamovies.download" in (c.get("domain") or ""):
                            drive_cookies[c["name"]] = c["value"]
                    if drive_cookies:
                        _save_drive_session(drive_cookies)
                except Exception:  # noqa: BLE001
                    pass
        except Exception as e:  # noqa: BLE001
            msg = str(e)
            if "executable" in msg.lower() or "browser" in msg.lower():
                _log(f"stealth browser unavailable: {msg.splitlines()[0][:160]}")
                return {
                    "success": False, "error": "stealth browser unavailable",
                    "detail": (
                        "no stealth browser installed — install Chromium and/or "
                        "set OLA_STEALTH_CHROME_PATH (or export OLA_DRIVE_COOKIE "
                        "from your logged-in browser instead)"
                    ),
                }
            _log(f"stealth browser failed (headless={headless}): "
                 f"{type(e).__name__}: {msg.splitlines()[0][:160]}")
            continue

        if "response" in result:
            return result["response"]
        err = result.get("error", "browser finished without a result")
        _log(f"browser action (headless={headless}): {err}")
        if headless and ("not solved" in err.lower() or "not logged in" in err.lower()):
            continue  # retry headful — the user can log in / see the solve
        return {"success": False, "error": "browser", "detail": err}
    return {"success": False, "error": "browser",
            "detail": "stealth browser could not resolve the link"}


# ----------------------------------------------------------------- resolve --

def _result(crypt, file_name, v1, expires_at, status, detail,
            file_size=None):
    return {
        "crypt": crypt,
        "file_name": file_name,
        "file_size": file_size,
        "v1": v1,
        "expires_at": expires_at,
        "status": status,
        "detail": detail,
    }


def _cache_put(crypt: str, v1: str, file_name: Optional[str],
               file_size: Optional[int] = None) -> float:
    expires = time.time() + min(config.DRIVE_CACHE_TTL, V1_LIFETIME)
    with _LOCK:
        _CACHE[crypt] = {
            "v1": v1, "file_name": file_name, "file_size": file_size,
            "expires_at": expires, "resolved_at": time.time(),
        }
        _NEG_CACHE.pop(crypt, None)
    return expires


def resolve(url_or_crypt: str, refresh: bool = False, use_browser: bool = True,
            check_turnstile: bool = True) -> dict:
    """Full chain for one OMDrive file → {"crypt", "file_name", "v1",
    "expires_at", "status", "detail"}.

    status: resolved | cached | auth_required | verification_required | error
    (v1 is only set for resolved/cached). Uses the in-process TTL cache
    (config.DRIVE_CACHE_TTL, capped at the 3-day link lifetime).
    ``check_turnstile=False`` skips the informational turnstile GET (the POST
    is authoritative) — used by resolve_cached to stay fast.
    """
    crypt = normalize_crypt(url_or_crypt)
    if not crypt:
        return _result(None, None, None, None, "error",
                       f"cannot parse {url_or_crypt!r} — expected a "
                       "drive.olamovies.download/file/<crypt> URL or a bare crypt")
    _log(f"resolving {crypt}")

    # 1. cache
    if not refresh:
        with _LOCK:
            hit = _CACHE.get(crypt)
        if hit and hit.get("v1") and hit["expires_at"] > time.time():
            _log(f"cache hit (v1 cached until "
                 f"{time.strftime('%Y-%m-%d %H:%M UTC', time.gmtime(hit['expires_at']))})")
            return _result(crypt, hit["file_name"], hit["v1"], hit["expires_at"],
                           "cached", "from the in-process cache")

    # 2. file name + metadata: anonymous mediainfo first (exact CompleteName
    #    + size + duration), the file page <title> as fallback
    file_url = f"{config.DRIVE_BASE}/file/{crypt}"
    file_name: Optional[str] = None
    file_size: Optional[int] = None
    info = fetch_mediainfo(crypt)
    if info.get("file_name"):
        file_name = info["file_name"]
        file_size = info.get("size_bytes")
        size_note = f" ({file_size / 1e9:.1f} GB)" if file_size else ""
        _log(f"file: {file_name[:100]}{'…' if len(file_name) > 100 else ''}{size_note}")
    if not file_name:
        try:
            resp = fetch_mod.get(file_url, allow_stealth=False, cookies=_api_cookies())
        except Exception as e:  # noqa: BLE001
            _log(f"file page fetch error: {e}")
            resp = None
        if resp is not None and resp.status == 200:
            pinfo = parse_file_page(resp.html_content or "")
            file_name = pinfo.get("file_name")
            if pinfo.get("crypt") and pinfo["crypt"] != crypt:
                _log(f"page reports crypt {pinfo['crypt']!r}, requested {crypt!r} "
                     "(sticking with the requested one)")
        if resp is None or resp.status != 200:
            detail = f"file page fetch failed (http {resp.status if resp else 'none'})"
            _log(detail)
            with _LOCK:
                _NEG_CACHE[crypt] = time.time()
            return _result(crypt, file_name, None, None, "error", detail)
        if not file_name:
            detail = "file page has no usable <title> — wrong crypt?"
            _log(detail)
            with _LOCK:
                _NEG_CACHE[crypt] = time.time()
            return _result(crypt, None, None, None, "error", detail)
        _log(f"file: {file_name[:100]}{'…' if len(file_name) > 100 else ''}")

    # 3. turnstile state (informational — the POST re-checks authoritatively)
    if check_turnstile:
        verified = turnstile_verified(crypt)
        _log(f"turnstile verified: {verified}")

    # 4. the download-links POST (auth is checked before turnstile)
    data = fetch_download_link(crypt, file_name)
    if data.get("success") and data.get("v1"):
        expires = _cache_put(crypt, data["v1"], file_name, file_size)
        _log(f"v1 resolved: {data['v1']}")
        return _result(crypt, file_name, data["v1"], expires, "resolved",
                       "direct link resolved", file_size)

    error = data.get("error") or "unknown error"
    _log(f"download-links: {error}")

    # 5. browser path — when the turnstile is the blocker, or when the user
    #    could log in inside the browser window (the auth guidance points at
    #    exactly this flow)
    if use_browser and error in ("verification_required", "Not authenticated"):
        _log("trying the stealth browser path")
        bres = _browser_solve(file_url, crypt, file_name)
        if bres.get("success") and bres.get("v1"):
            expires = _cache_put(crypt, bres["v1"], file_name, file_size)
            _log(f"v1 resolved via stealth browser: {bres['v1']}")
            return _result(crypt, file_name, bres["v1"], expires, "resolved",
                           "direct link resolved via the stealth browser", file_size)

    guidance = _ERROR_GUIDANCE.get(error, f"OMDrive error: {error}")
    status = ("auth_required" if error == "Not authenticated"
              else "verification_required" if error == "verification_required"
              else "error")
    with _LOCK:
        _NEG_CACHE[crypt] = time.time()
    return _result(crypt, file_name, None, None, status, guidance)


def resolve_cached(url_or_crypt: str) -> Optional[dict]:
    """Non-raising, cache-first variant for the addon.

    Never launches a browser; HTTP fast path only. Returns the resolve()
    dict when a v1 is available (cache hit or fast success), None otherwise.
    Failed fast attempts are remembered briefly (_NEG_CACHE_TTL) so repeated
    stream requests don't stall on unreachable resolutions.
    """
    try:
        crypt = normalize_crypt(url_or_crypt)
        if not crypt:
            return None
        with _LOCK:
            neg = _NEG_CACHE.get(crypt)
        if neg and time.time() - neg < _NEG_CACHE_TTL:
            return None
        res = resolve(url_or_crypt, use_browser=False, check_turnstile=False)
        return res if res.get("v1") else None
    except Exception as e:  # noqa: BLE001
        _log(f"resolve_cached failed: {e}")
        return None


# -------------------------------------------------------------------- cli --

def cmd_drive(target: str, json_output: bool = False, refresh: bool = False,
              use_browser: bool = True) -> int:
    """CLI entry point for ``python -m crawler drive``.

    resolve() logs the chain progress as it goes; here we print the final v1
    + expiry, or the friendly error + guidance. Exit 0 when a v1 was resolved,
    1 otherwise.
    """
    global _JSON_MODE
    _JSON_MODE = json_output
    try:
        res = resolve(target, refresh=refresh, use_browser=use_browser)
    finally:
        _JSON_MODE = False

    if json_output:
        print(json.dumps(res, indent=2, ensure_ascii=False))
        return 0 if res.get("v1") else 1

    if res.get("v1"):
        print(f"file: {res['file_name']}")
        print(f"v1:   {res['v1']}")
        if res.get("expires_at"):
            print("link cached until: "
                  + time.strftime("%Y-%m-%d %H:%M UTC", time.gmtime(res["expires_at"]))
                  + " (links stay valid ~3 days on OMDrive)")
        return 0

    print(f"status: {res['status']}")
    print(f"detail: {res['detail']}")
    return 1


if __name__ == "__main__":
    sys.exit(cmd_drive(sys.argv[1] if len(sys.argv) > 1 else ""))
