"""Telegram backfill: import release titles from the public t.me channel preview.

The real OlaMovies releases feed lives on Telegram (@olamovies_officialv8).
Its web preview at https://t.me/s/<channel> is served WITHOUT Cloudflare, so
it works from any IP (datacenter/server included) — no browser needed.

Each post is a release announcement whose text looks like:

    ## Lainey Wilson: Keepin' Country Cool (2026) 720p + 1080p + 2160p 4K NF
    WEB-DL x265 10bit HEVC English DDP 5.1 Atmos MSubs ##
    🔥 Added to Website!  /  "S06 Added!"  /  "BluRay REMUX Added!"

The release title always sits between the first pair of ## markers. Update
posts ("S06 Added!", "BluRay REMUX Added!") use the same ##...## pattern.

HTML structure (t.me/s pages, verified against tests/fixtures/telegram_v8.html):
  * one wrapper div per message:  <div class="tgme_widget_message_wrap ...">
  * message id in                 data-post="<channel>/<id>"
  * text in                       <div class="tgme_widget_message_text ..." ...>
  * media-only posts have no text div (class text_not_supported_wrap) — skip
  * older pages:                  ?before=<oldest message id on current page>
    (the "more" link carries data-before="<oldest id>", ~20 posts per page)

What this tool does with each extracted title:
  * parse it via app.titles.parse_title -> {name, year, release_desc}
  * if an item with the same lower(name) + year already exists (i.e. it was
    catalogued from the OM Space board): just bump its updated_at so it
    surfaces as recent in the addon catalogs
  * if not: INSERT with a synthetic id "ola:<slug>" (slugified name) so brand
    new Telegram releases appear in the catalog even before the Space board
    crawl picks them up (stream_status stays 'pending' for the site crawler)
"""
import html as _html
import os
import re
import time
from datetime import datetime, timezone
from typing import Optional

from app import config, db, titles

DEFAULT_CHANNEL = "olamovies_officialv8"

# <div class="tgme_widget_message_wrap js-widget_message_wrap"> ... one per post
_WRAP_SPLIT_RE = re.compile(r'<div class="tgme_widget_message_wrap')
# data-post="olamovies_officialv8/2552"
_POST_ID_RE = re.compile(r'data-post="([^"/]+?)/(\d+)"')
# <div class="tgme_widget_message_text js-message_text" dir="auto">...</div>
# (text divs never contain nested <div>s — inline markup only — so the
# non-greedy match to the first </div> is safe)
_TEXT_DIV_RE = re.compile(
    r'<div class="tgme_widget_message_text[^"]*"[^>]*>(.*?)</div>', re.S)
# release title between ## markers
_TITLE_RE = re.compile(r'##\s*(.+?)\s*##')
# series markers: "S01", "S01-S06", "Season 1", ...
_SERIES_RE = re.compile(r'\bS\d{1,2}\b|\bSeason\b', re.I)


def _log(msg: str) -> None:
    print(f"[telegram] {msg}", flush=True)


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _fetch(url: str):
    """Plain HTTP fetch via Scrapling's Fetcher (curl_cffi, chrome TLS)."""
    from scrapling.fetchers import Fetcher

    return Fetcher.get(
        url,
        timeout=config.CRAWL_TIMEOUT,
        retries=2,
        stealthy_headers=True,
        impersonate="chrome",
    )


def _html_to_text(block: str) -> str:
    """Convert a message-text div's inner HTML to plain text."""
    txt = re.sub(r"<br\s*/?>", "\n", block)      # line breaks
    txt = re.sub(r"<[^>]+>", "", txt)            # strip all tags
    return _html.unescape(txt).strip()


def _slugify(text: str) -> str:
    """lowercase, non-alphanumeric -> '-', collapse runs, trim edges."""
    return re.sub(r"[^a-z0-9]+", "-", (text or "").lower()).strip("-")


def parse_page(html: str, channel: str) -> list:
    """Extract [(message_id:int, release_title|None), ...] from one t.me/s page.

    Posts without a text div (media-only) or without ## markers yield None.
    """
    posts = []
    for seg in _WRAP_SPLIT_RE.split(html)[1:]:
        m = _POST_ID_RE.search(seg)
        if not m or m.group(1) != channel:
            continue
        pid = int(m.group(2))
        title = None
        t = _TEXT_DIV_RE.search(seg)
        if t:
            tm = _TITLE_RE.search(_html_to_text(t.group(1)))
            if tm:
                title = tm.group(1).strip()
        posts.append((pid, title))
    return posts


def _import_title(title: str) -> str:
    """Import one release title into the DB. Returns 'matched' or 'inserted'."""
    parsed = titles.parse_title(title)
    name = parsed["name"]
    if not name:
        return "matched"  # nothing usable — don't count as inserted
    year = parsed["year"]

    with db.tx() as cur:
        # Existing item (catalogued from OM Space, keyed by tt-id)?
        # Prefer real tt-ids over our synthetic "ola:" ids when both match.
        if year:
            row = cur.execute(
                "SELECT imdb_id FROM items WHERE lower(name)=lower(?) AND year=? "
                "ORDER BY (imdb_id LIKE 'ola:%') LIMIT 1", (name, year)).fetchone()
        else:
            row = cur.execute(
                "SELECT imdb_id FROM items WHERE lower(name)=lower(?) "
                "ORDER BY (imdb_id LIKE 'ola:%'), (year IS NOT NULL) DESC, "
                "updated_at DESC LIMIT 1", (name,)).fetchone()
        if row:
            # Just bump recency so it surfaces in the addon catalogs again.
            cur.execute("UPDATE items SET updated_at=? WHERE imdb_id=?",
                        (_now(), row["imdb_id"]))
            return "matched"

        # New item -> synthetic id "ola:<slug>"
        is_series = bool(_SERIES_RE.search(title))
        slug = _slugify(name)
        created = db.upsert_item(
            cur,
            imdb_id=f"ola:{slug}",
            media_type="series" if is_series else "movie",
            site_category="tv-series" if is_series else "movies",
            title=title,
            name=name,
            year=year,
            poster_url=None,
            site_url=None,
            slug=slug,
            release_desc=parsed["release_desc"],
        )
    return "inserted" if created else "matched"


def backfill(pages: int = 10, channel: Optional[str] = None,
             delay: Optional[float] = None) -> dict:
    """Walk the public t.me/s/ preview and import release titles.

    pages:   max t.me pages to fetch (~20 posts per page, newest first)
    channel: channel username; default OLA_TELEGRAM_CHANNEL env or
             olamovies_officialv8
    delay:   seconds between page fetches (default config.CRAWL_DELAY = 0.5)

    Returns {"pages", "posts", "titles", "matched", "inserted"}.
    """
    channel = channel or os.environ.get("OLA_TELEGRAM_CHANNEL") or DEFAULT_CHANNEL
    delay = config.CRAWL_DELAY if delay is None else delay
    pages = max(1, int(pages))

    summary = {"pages": 0, "posts": 0, "titles": 0, "matched": 0, "inserted": 0}
    seen: set = set()
    before: Optional[int] = None

    for _ in range(pages):
        url = f"https://t.me/s/{channel}"
        if before is not None:
            url += f"?before={before}"

        try:
            resp = _fetch(url)
        except Exception as e:  # noqa: BLE001
            _log(f"fetch failed: {url} ({e!r}) — stopping")
            break
        if resp is None or resp.status != 200:
            _log(f"HTTP {getattr(resp, 'status', '?')} for {url} — stopping")
            break
        summary["pages"] += 1

        posts = parse_page(resp.html_content, channel)
        fresh = [(pid, t) for pid, t in posts if pid not in seen]
        if not fresh:
            _log("no older posts — reached the start of the channel")
            break

        page_oldest = min(pid for pid, _ in fresh)
        for pid, title in fresh:
            seen.add(pid)
            summary["posts"] += 1
            if title:
                summary["titles"] += 1
                summary[_import_title(title)] += 1

        if before is not None and page_oldest >= before:
            # safety: pagination did not advance
            break
        before = page_oldest

        if summary["pages"] < pages:
            time.sleep(delay)

    _log(f"done: pages={summary['pages']} posts={summary['posts']} "
         f"titles={summary['titles']} matched={summary['matched']} "
         f"inserted={summary['inserted']}")
    return summary


if __name__ == "__main__":
    import json
    print(json.dumps(backfill(), indent=2))
