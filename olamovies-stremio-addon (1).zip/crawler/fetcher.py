"""Cloudflare-aware fetcher for v6.olamovies.mov (runs on YOUR machine).

Three tiers, used automatically:
  1. resolve the current domain via the permanent entry domain
     (https://olamovies.dad/current.php?redirect=1 → 302 → current domain);
  2. FAST path — plain HTTP via Scrapling Fetcher (curl_cffi with Chrome TLS
     impersonation) reusing a saved cf_clearance cookie + matching User-Agent;
  3. STEALTH path — Scrapling StealthySession (patchright/Chromium) with
     solve_cloudflare=True; after it passes, its cookies are saved and we
     upgrade back to the fast path.

The site is served through Cloudflare with a WAF that hard-blocks datacenter
IPs, so run this from a residential connection (your PC). On your machine the
managed challenge is typically solved automatically by the stealth browser.
"""
import json
import time
from pathlib import Path
from typing import Optional

from app import config


def _log(msg: str) -> None:
    print(f"[fetcher] {msg}", flush=True)


# --------------------------------------------------------- domain resolve --

def resolve_current_domain(force: bool = False) -> str:
    """Ask the permanent entry domain for the current working domain."""
    from scrapling.fetchers import Fetcher

    cache_file = config.DATA_DIR / "domain.json"
    if not force and cache_file.exists():
        try:
            age = time.time() - cache_file.stat().st_mtime
            if age < config.DOMAIN_TTL:
                return json.loads(cache_file.read_text())["domain"]
        except Exception:  # noqa: BLE001
            pass

    try:
        r = Fetcher.get(config.REDIRECT_URL, follow_redirects=False,
                        timeout=20, retries=2, stealthy_headers=False,
                        impersonate="chrome")
        loc = (r.headers or {}).get("location") or ""
        if r.status in (301, 302, 303, 307, 308) and loc.startswith("http"):
            domain = loc.rstrip("/")
            cache_file.write_text(json.dumps({"domain": domain, "resolved_at": time.time()}))
            _log(f"current domain -> {domain}")
            return domain
        _log(f"redirect endpoint returned {r.status} (location={loc!r})")
    except Exception as e:  # noqa: BLE001
        _log(f"redirect endpoint failed: {e}")

    for fallback in config.FALLBACK_DOMAINS:
        try:
            r = Fetcher.get(fallback.rstrip('/') + '/robots.txt', timeout=15,
                            retries=1, stealthy_headers=False, impersonate="chrome")
            if r.status == 200:
                _log(f"using fallback domain {fallback}")
                return fallback.rstrip("/")
        except Exception:  # noqa: BLE001
            continue
    raise RuntimeError("Could not resolve the current OlaMovies domain")


# ------------------------------------------------------------ session jar --

def load_session() -> dict:
    if config.SESSION_FILE.exists():
        try:
            return json.loads(config.SESSION_FILE.read_text())
        except Exception:  # noqa: BLE001
            return {}
    return {}


def save_session(cookies: dict, user_agent: str) -> None:
    config.SESSION_FILE.write_text(json.dumps({
        "cookies": cookies, "user_agent": user_agent, "saved_at": time.time(),
    }, indent=2))


# ------------------------------------------------------------- fetching ----

def _looks_blocked(resp) -> bool:
    if resp.status in (403, 503, 429):
        return True
    html = (resp.html_content or "")[:4000].lower()
    if "just a moment" in html or "attention required" in html:
        return True
    if "cf-mitigated" in (resp.headers or {}):
        return True
    return False


def _fast_get(url: str, session: dict, cookies: Optional[dict] = None):
    from scrapling.fetchers import Fetcher

    jar = session.get("cookies") or {}
    headers = {"referer": "https://www.google.com/"}
    ua = session.get("user_agent")
    if ua:
        headers["user-agent"] = ua
    if config.ACCOUNT_COOKIE:
        jar = dict(jar)
        for pair in config.ACCOUNT_COOKIE.split(";"):
            if "=" in pair:
                k, v = pair.split("=", 1)
                jar[k.strip()] = v.strip()
    if cookies is not None:
        # explicit cookies for this call REPLACE the site jar (the caller has
        # already merged whatever it needs — e.g. crawler.drive)
        jar = dict(cookies)
    return Fetcher.get(
        url, timeout=config.CRAWL_TIMEOUT, retries=1,
        stealthy_headers=False, impersonate="chrome",
        cookies=jar, headers=headers,
    )


def _fast_post(url: str, json_body: Optional[dict] = None,
               cookies: Optional[dict] = None, headers: Optional[dict] = None,
               timeout: Optional[int] = None, retries: int = 1):
    from scrapling.fetchers import Fetcher

    return Fetcher.post(
        url, json=json_body, timeout=timeout or config.CRAWL_TIMEOUT,
        retries=retries, stealthy_headers=False, impersonate="chrome",
        cookies=cookies or {}, headers=headers or {},
    )


def _stealth_get(url: str) -> tuple:
    """Open the stealth browser, solve the challenge, return (html, cookies, ua).

    Tries headless first; if still blocked, retries headful (a visible browser
    window — on a desktop you may see it flash and click the Turnstile box).
    """
    from scrapling.fetchers import StealthySession

    kwargs = dict(
        solve_cloudflare=True,
        timeout=180000,
        user_data_dir=str(config.STEALTH_PROFILE),
    )
    if config.STEALTH_CHROME_PATH:
        kwargs["executable_path"] = config.STEALTH_CHROME_PATH

    for headless in (_headless_setting(), False):
        if headless is None:
            continue
        try:
            with StealthySession(headless=headless, **kwargs) as session:
                page = session.fetch(url, timeout=120000, solve_cloudflare=True,
                                     network_idle=True)
                html = page.html_content or ""
                title = (page.css("title::text").get() or "")
                if page.status == 200 and "just a moment" not in title.lower():
                    cookies = {}
                    try:
                        for c in session.context.cookies():
                            cookies[c["name"]] = c["value"]
                    except Exception:  # noqa: BLE001
                        pass
                    ua = None
                    try:
                        ua = page.evaluate("() => navigator.userAgent")
                    except Exception:  # noqa: BLE001
                        pass
                    return html, cookies, ua
                _log(f"stealth headless={headless}: status={page.status} title={title!r}")
        except Exception as e:  # noqa: BLE001
            _log(f"stealth headless={headless} failed: {type(e).__name__}: {e}")
    return "", {}, None


def _headless_setting() -> Optional[bool]:
    v = (config.STEALTH_HEADLESS or "auto").lower()
    if v == "true":
        return True
    if v == "false":
        return False
    return True  # auto: try headless first


def get(url: str, allow_stealth: bool = True, cookies: Optional[dict] = None):
    """Fetch a URL on the OlaMovies site, escalating tiers as needed.

    Returns a Scrapling Response-like object or None when everything failed.
    ``cookies`` (optional) replaces the saved session jar for this call on the
    fast path — used by crawler.drive for drive.olamovies.download requests.
    """
    session = load_session()
    try:
        resp = _fast_get(url, session, cookies=cookies)
        if not _looks_blocked(resp):
            return resp
        _log(f"fast path blocked ({resp.status}) at {url}")
    except Exception as e:  # noqa: BLE001
        _log(f"fast path error: {e}")

    if not allow_stealth:
        return None

    html, cookies, ua = _stealth_get(url)
    if not html:
        return None
    if cookies:
        save_session(cookies, ua or config.USER_AGENT)
        _log(f"stealth passed — saved {len(cookies)} cookies for the fast path")

    class _Resp:  # minimal duck-typed response wrapping stealth output
        status = 200
        url = url
        html_content = html
        headers: dict = {}

        def css(self, sel):  # parse via Scrapling Selector for compatibility
            from scrapling.parser import Selector
            return Selector(content=self.html_content).css(sel)

    return _Resp()


def post(url: str, json: Optional[dict] = None, cookies: Optional[dict] = None,
         headers: Optional[dict] = None, timeout: Optional[int] = None,
         retries: int = 2):
    """POST a JSON body via the fast path (curl_cffi, Chrome impersonation).

    Returns a Scrapling Response-like object (status / body / json() / headers)
    or None on transport failure. There is deliberately NO stealth-browser
    fallback here — browser flows are handled at the crawler.drive level.
    """
    try:
        return _fast_post(url, json_body=json, cookies=cookies, headers=headers,
                          timeout=timeout, retries=retries)
    except Exception as e:  # noqa: BLE001
        _log(f"post error: {e}")
        return None


def get_item_page(site_url: str):
    """Fetch a v6 item page (or any site URL). Returns the Response or None."""
    return get(site_url)
