"""Unit tests for app/titles.py (release-title parsing + label helpers)."""
import pytest

from app.titles import (
    extract_qualities,
    extract_size,
    guess_season_episode,
    parse_title,
)

GRAY_MAN = (
    "The Gray Man (2022) 720p + 1080p + 2160p 4K NF WEB-DL x265 10bit HEVC "
    "Multi Audio [Hindi + English] DDP 5.1 Atmos MSubs"
)


# --------------------------------------------------------------- parse ----

@pytest.mark.parametrize(
    "raw, expected_name, expected_year",
    [
        ("Bon Appetit Your Majesty (2025) Season 1 S01",
         "Bon Appetit Your Majesty", 2025),
        ("[Season 1-2] MobLand (2025) S01-S02",
         "MobLand", 2025),
        (GRAY_MAN, "The Gray Man", 2022),
        ("KPop Demon Hunters (2025)",
         "KPop Demon Hunters", 2025),
        ("No Year Movie", "No Year Movie", None),
    ],
)
def test_parse_title(raw, expected_name, expected_year):
    result = parse_title(raw)
    assert result["name"] == expected_name
    assert result["year"] == expected_year


def test_parse_title_release_desc():
    # year alone → just the year; year + trailing junk → "year · junk"
    assert parse_title("KPop Demon Hunters (2025)")["release_desc"] == "2025"
    desc = parse_title("Bon Appetit Your Majesty (2025) Season 1 S01")["release_desc"]
    assert desc == "2025 · Season 1 S01"
    # no year → empty description, name falls back to the whole title
    r = parse_title("No Year Movie")
    assert r["release_desc"] == ""


def test_parse_title_empty_inputs():
    for raw in ("", None):
        assert parse_title(raw) == {"name": "", "year": None, "release_desc": ""}


# ------------------------------------------------------- quality / size ----

def test_extract_qualities():
    assert extract_qualities(GRAY_MAN) == ["720p", "1080p", "2160p", "4K", "WEB-DL"]
    assert extract_qualities(" plain release with no tokens ") == []
    assert extract_qualities("") == []
    assert extract_qualities(None) == []
    # uniqueness: repeated tokens are reported once, in first-seen order
    assert extract_qualities("1080p then 1080p then 720p") == ["1080p", "720p"]


def test_extract_size():
    assert extract_size("118 GB") == "118 GB"
    assert extract_size("Total: 1.5TB packed") == "1.5 TB"
    assert extract_size("tiny 700MB rip") == "700 MB"
    assert extract_size("no size here") is None
    assert extract_size("") is None
    assert extract_size(None) is None


# ---------------------------------------------------- season / episode -----

def test_guess_season_episode():
    assert guess_season_episode("S01E05") == (1, 5)
    assert guess_season_episode("Show.Name.S02E10.1080p.mkv") == (2, 10)
    assert guess_season_episode("Season 2 Episode 3") == (2, 3)
    assert guess_season_episode("plain movie file") == (None, None)
    assert guess_season_episode("") == (None, None)
    assert guess_season_episode(None) == (None, None)
