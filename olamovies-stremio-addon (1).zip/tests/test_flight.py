"""crawler/flight.py tests, driven by the real captured fixtures in
tests/fixtures/ (no network access needed).

- space_completed.html / .flight.txt : OM Space /completed board page 1 of 164
  (48 item records pointing at v6.olamovies.mov).
- ola18_item.html / .flight.txt      : sister-site item page with folder/file
  link structures.
"""
import re
from pathlib import Path

import pytest

from crawler.flight import (
    classify_link,
    extract_flight,
    extract_links,
    find_json_objects,
    space_board_meta,
    space_board_records,
    space_size_spans,
)

FIXTURES = Path(__file__).resolve().parent / "fixtures"


@pytest.fixture(scope="module")
def space_html():
    return (FIXTURES / "space_completed.html").read_text(encoding="utf-8")


@pytest.fixture(scope="module")
def space_flight():
    return (FIXTURES / "space_completed.html.flight.txt").read_text(encoding="utf-8")


@pytest.fixture(scope="module")
def ola18_flight():
    return (FIXTURES / "ola18_item.html.flight.txt").read_text(encoding="utf-8")


# ------------------------------------------------------ extract_flight ----

def test_extract_flight_nonempty(space_html):
    stream = extract_flight(space_html)
    assert isinstance(stream, str)
    assert len(stream) > 50000
    # the joined stream must actually contain the page payload
    assert '"key":"tt' in stream
    assert '"page":1,"totalPages":164' in stream
    assert "v6.olamovies.mov" in stream


def test_extract_flight_empty_inputs():
    assert extract_flight("") == ""
    assert extract_flight(None) == ""
    assert extract_flight("<html>no next_f chunks here</html>") == ""


# ------------------------------------------------ space board mining ------

def test_space_board_records(space_flight):
    records = space_board_records(space_flight)
    # a full board page carries 48 cards; spec floor is >= 40
    assert len(records) >= 40
    assert len(records) == 48
    # unique imdb ids, one per card
    assert len({r["imdb_id"] for r in records}) == len(records)

    for r in records:
        assert r["imdb_id"].startswith("tt"), r
        assert r["title"], r
        assert "img.ol-am.top" in (r["poster_url"] or ""), r
        assert "v6.olamovies.mov" in r["url"], r
        assert any(seg in r["url"] for seg in ("/movies/", "/tv-series/", "/tv-shows/")), r
        # slug / site_category / media_type derived from the url
        assert r["slug"], r
        assert r["site_category"] in ("movies", "tv-series", "tv-shows"), r
        assert r["media_type"] == ("movie" if r["site_category"] == "movies" else "series"), r
        assert r["url"].endswith(f"/{r['slug']}")

    # spot-check the first two known records of this capture
    first, second = records[0], records[1]
    assert first["imdb_id"] == "tt37600136"
    assert first["title"] == "Bon Appetit Your Majesty (2025) Season 1 S01"
    assert first["site_category"] == "tv-series"
    assert first["media_type"] == "series"
    assert first["slug"] == "bon-appetit-your-majesty-2025"
    assert first["url"] == "https://v6.olamovies.mov/tv-series/bon-appetit-your-majesty-2025"
    assert second["imdb_id"] == "tt26234108"
    assert second["site_category"] == "movies"
    assert second["media_type"] == "movie"


def test_space_board_records_empty():
    assert space_board_records("") == []


def test_space_board_meta(space_flight):
    meta = space_board_meta(space_flight)
    assert meta == {"page": 1, "totalPages": 164}


def test_space_size_spans(space_flight):
    spans = space_size_spans(space_flight)
    # ~48 (size, rating) tuples on a full page, aligned with the records
    assert 40 <= len(spans) <= 48
    assert len(spans) == len(space_board_records(space_flight))
    for size, rating in spans:
        assert re.fullmatch(r"\d[\d,.]* (?:GB|MB|TB)", size), size
        assert rating is None or re.fullmatch(r"\d+\.\d+", rating), rating
    # regression: the board renders "1,013 GB" with a thousands separator —
    # the span must not start mid-number ("013 GB")
    assert "1,013 GB" in [s for s, _ in spans]
    assert not any(s.startswith("0") for s, _ in spans)
    # at least some spans carry an IMDb rating
    assert any(rating is not None for _, rating in spans)


# ------------------------------------------------- generic link mining -----

def test_extract_links_on_ola18(ola18_flight):
    # the ola18 flight only stores site-relative hrefs ("/f/<id>") and
    # {"name","slug","href"} objects, so base_url is needed for absolute urls
    links = extract_links(ola18_flight, base_url="https://olam18plus.com")
    assert len(links) > 15
    assert all(l["url"].startswith("http") for l in links)
    assert all(isinstance(l.get("text"), str) for l in links)
    assert any("/f/" in l["url"] for l in links)
    # urls are unique
    assert len({l["url"] for l in links}) == len(links)

    # without base_url the same links stay site-relative
    rel = extract_links(ola18_flight)
    assert len(rel) > 15
    assert all(l["url"].startswith("/") for l in rel)


def test_extract_links_empty():
    assert extract_links("") == []
    assert extract_links(None) == []


def test_classify_link():
    assert classify_link("https://drive.google.com/folders/1AbCdEf") == "gdrive"
    assert classify_link("https://docs.google.com/document/d/x/edit") == "gdrive"
    assert classify_link("https://cdn.example.com/movie.x.mp4") == "direct"
    assert classify_link("https://cdn.example.com/show.S01E05.mkv") == "direct"
    assert classify_link("https://v6.olamovies.mov/tv-series/some-show") == "page"
    assert classify_link("https://olam18plus.com/f/QIWKWWPi") == "page"
    # folder: trailing slash on a short path
    assert classify_link("https://example.com/folder/") == "folder"


def test_find_json_objects(ola18_flight):
    # the ola18 flight stores its folder/file entries as {"name","slug","href"}
    # objects; ("name","url")-shaped objects do not occur in this capture
    objs = find_json_objects(ola18_flight, ("name", "slug", "href"))
    assert len(objs) >= 1
    exact = [o for o in objs if set(o) == {"name", "slug", "href"}]
    assert len(exact) >= 1
    for o in exact:
        assert o["name"]
        assert o["slug"]
        assert o["href"].startswith("/f/")

    # basic behaviour on a crafted stream (the ("name","url") shape)
    crafted = 'xx {"name":"a","url":"b"} yy {"name":"c"} zz'
    assert find_json_objects(crafted, ("name", "url")) == [{"name": "a", "url": "b"}]
    assert find_json_objects(crafted, ("nope",)) == []
    assert find_json_objects("", ("name",)) == []
