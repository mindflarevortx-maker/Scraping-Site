"""app/db.py tests against the scratch database (never data/olamovies.db —
see conftest.py)."""
import json
import os

import pytest


# ----------------------------------------------------------- upsert --------

def test_upsert_item_create_then_update(app_modules):
    db = app_modules["db"]

    with db.tx() as cur:
        created = db.upsert_item(
            cur, imdb_id="tt9200001", media_type="movie", site_category="movies",
            title="First Title (2001)", name="First Title", year=2001,
            poster_url="https://img.ol-am.top/posters/tt9200001/a.webp",
            site_url="https://v6.olamovies.mov/movies/first-title",
            slug="first-title", size_label="2 GB", imdb_rating="7.1",
        )
    assert created is True

    row = db.get_item("tt9200001")
    assert row is not None
    assert row["media_type"] == "movie"
    assert row["site_category"] == "movies"
    assert row["title"] == "First Title (2001)"
    assert row["name"] == "First Title"
    assert row["year"] == 2001
    assert row["slug"] == "first-title"
    assert row["size_label"] == "2 GB"
    assert row["imdb_rating"] == "7.1"
    assert row["stream_status"] == "pending"
    assert row["first_seen_at"]
    assert row["updated_at"]

    # second upsert with the same key → update, returns False
    with db.tx() as cur:
        created2 = db.upsert_item(
            cur, imdb_id="tt9200001", media_type="movie", site_category="movies",
            title="Renamed Title (2001)",
            # name/year/etc deliberately None → COALESCE keeps the old values
        )
    assert created2 is False

    row2 = db.get_item("tt9200001")
    assert row2["title"] == "Renamed Title (2001)"   # title is always overwritten
    assert row2["name"] == "First Title"             # NULL arg keeps stored value
    assert row2["year"] == 2001
    assert row2["site_url"] == "https://v6.olamovies.mov/movies/first-title"

    # unknown id → None
    assert db.get_item("tt0000000") is None


# ---------------------------------------------------------- catalog --------

def test_catalog_items_filters(app_modules):
    db = app_modules["db"]
    # this test asserts exact result lists/order — start from a clean table so
    # rows left by earlier tests in this module cannot leak in
    with db.tx() as cur:
        cur.execute("DELETE FROM items")
    rows = [
        # (imdb_id, media_type, site_category, title, name, year)
        ("tt9200101", "movie", "movies", "Zeta Movie (2020)", "Zeta Movie", 2020),
        ("tt9200102", "movie", "movies", "Yeti Movie (2021)", "Yeti Movie", 2021),
        ("tt9200103", "series", "tv-series", "Xena Series (2022)", "Xena Series", 2022),
        ("tt9200104", "series", "tv-shows", "Wanda Show (2023)", "Wanda Show", 2023),
    ]
    with db.tx() as cur:
        for iid, mtype, cat, title, name, year in rows:
            db.upsert_item(cur, imdb_id=iid, media_type=mtype, site_category=cat,
                           title=title, name=name, year=year)

    # deterministic ordering for the skip test: newest updated first
    # (future stamps beat the "now" timestamps of any other rows)
    stamps = {
        "tt9200101": "2099-01-01T00:00:01+00:00",
        "tt9200102": "2099-01-02T00:00:01+00:00",
        "tt9200103": "2099-01-03T00:00:01+00:00",
        "tt9200104": "2099-01-04T00:00:01+00:00",
    }
    with db.tx() as cur:
        for iid, stamp in stamps.items():
            cur.execute("UPDATE items SET updated_at=? WHERE imdb_id=?", (stamp, iid))

    ids = lambda found: [r["imdb_id"] for r in found]

    # media_type filter
    assert ids(db.catalog_items("movie")) == ["tt9200102", "tt9200101"]
    assert ids(db.catalog_items("series")) == ["tt9200104", "tt9200103"]
    assert db.catalog_items("documentary") == []

    # site_category filter
    assert ids(db.catalog_items("series", site_category="tv-series")) == ["tt9200103"]
    assert ids(db.catalog_items("series", site_category="tv-shows")) == ["tt9200104"]
    assert ids(db.catalog_items("movie", site_category="tv-series")) == []

    # search matches the parsed name or the raw title
    assert ids(db.catalog_items("movie", search="Yeti")) == ["tt9200102"]
    assert ids(db.catalog_items("movie", search="(2021)")) == ["tt9200102"]  # title only
    assert ids(db.catalog_items("series", search="wanda")) == ["tt9200104"]  # case-insensitive
    assert ids(db.catalog_items("movie", search="Xena")) == []               # wrong type
    assert ids(db.catalog_items("movie", search="zzz-nothing")) == []

    # skip / limit (ordered by updated_at DESC)
    assert ids(db.catalog_items("movie", skip=1)) == ["tt9200101"]
    assert ids(db.catalog_items("movie", skip=0, limit=1)) == ["tt9200102"]
    assert ids(db.catalog_items("movie", skip=5)) == []
    assert ids(db.catalog_items("series", skip=1, limit=1)) == ["tt9200103"]


def test_count_items(app_modules):
    db = app_modules["db"]
    with db.tx() as cur:
        db.upsert_item(cur, imdb_id="tt9200150", media_type="movie",
                       site_category="movies", title="Count Movie (2020)",
                       name="Count Movie", year=2020)
        db.upsert_item(cur, imdb_id="tt9200151", media_type="series",
                       site_category="tv-shows", title="Count Show (2021)",
                       name="Count Show", year=2021)
    assert db.count_items() >= 2
    assert db.count_items(media_type="movie") >= 1
    assert db.count_items(media_type="series", site_category="tv-shows") >= 1
    assert db.count_items(media_type="series", site_category="movies") == 0


# ---------------------------------------------------------- streams --------

GD = "https://drive.google.com/folders/abc123"
MP4 = "https://cdn.example.com/s01e05.x264.mp4"
PAGE = "https://v6.olamovies.mov/tv-series/stream-show"


@pytest.fixture()
def stream_item(app_modules):
    db = app_modules["db"]
    iid = "tt9200201"
    with db.tx() as cur:
        db.upsert_item(cur, imdb_id=iid, media_type="series",
                       site_category="tv-series", title="Stream Show (2020)",
                       name="Stream Show", year=2020, site_url=PAGE)
    db.set_stream_result(iid, "crawled", {"links": 3, "folders": 2}, [
        # global/movie-style row: NULL season + NULL episode
        {"season": None, "episode": None, "label": "GDrive · whole pack",
         "quality": "1080p", "size": "50 GB", "host": "drive.google.com",
         "url": GD, "kind": "gdrive"},
        {"season": 1, "episode": 5, "label": "S01E05 direct",
         "quality": "720p", "size": "1 GB", "host": "cdn.example.com",
         "url": MP4, "kind": "direct"},
        {"season": 2, "episode": 3, "label": "S02E03 page",
         "quality": None, "size": None, "host": None,
         "url": PAGE, "kind": "page"},
    ])
    return iid


def test_set_stream_result_updates_item(app_modules, stream_item):
    db = app_modules["db"]
    row = db.get_item(stream_item)
    assert row["stream_status"] == "crawled"
    assert row["last_crawled_at"]
    assert json.loads(row["stream_detail"]) == {"links": 3, "folders": 2}


def test_streams_for_roundtrip(app_modules, stream_item):
    db = app_modules["db"]
    urls = lambda rows_: [r["url"] for r in rows_]

    # no filter → all rows, in insertion order
    all_rows = db.streams_for(stream_item)
    assert urls(all_rows) == [GD, MP4, PAGE]
    by_url = {r["url"]: r for r in all_rows}
    assert by_url[GD]["kind"] == "gdrive" and by_url[GD]["label"] == "GDrive · whole pack"
    assert by_url[GD]["season"] is None and by_url[GD]["episode"] is None
    assert by_url[MP4]["season"] == 1 and by_url[MP4]["episode"] == 5

    # season filter — documented semantics of db.py: rows with season IS NULL
    # are treated as global and are returned for EVERY season query (this is
    # how movie-style/whole-pack streams surface for series episode lookups)
    assert urls(db.streams_for(stream_item, season=1)) == [GD, MP4]
    assert urls(db.streams_for(stream_item, season=2)) == [GD, PAGE]

    # season + episode filter (episode only narrows rows that have a season)
    assert urls(db.streams_for(stream_item, season=1, episode=5)) == [GD, MP4]
    assert urls(db.streams_for(stream_item, season=1, episode=9)) == [GD]
    assert urls(db.streams_for(stream_item, season=9, episode=9)) == [GD]

    # episode without season → episode filter ignored (db.py only applies it
    # when season is not None)
    assert urls(db.streams_for(stream_item, episode=5)) == [GD, MP4, PAGE]

    # unknown item → empty
    assert db.streams_for("tt0000000") == []


def test_set_stream_result_replaces_old_rows(app_modules, stream_item):
    db = app_modules["db"]
    db.set_stream_result(stream_item, "empty", {"links": 0}, [
        {"url": "https://only.one/left", "kind": "page"},
    ])
    urls = [r["url"] for r in db.streams_for(stream_item)]
    assert urls == ["https://only.one/left"]
    assert db.get_item(stream_item)["stream_status"] == "empty"


def test_set_stream_result_no_streams_keeps_rows(app_modules, stream_item):
    db = app_modules["db"]
    # streams=None → only the status columns are touched, stream rows survive
    db.set_stream_result(stream_item, "gated", {"reason": "login required"})
    row = db.get_item(stream_item)
    assert row["stream_status"] == "gated"
    assert json.loads(row["stream_detail"]) == {"reason": "login required"}
    assert len(db.streams_for(stream_item)) == 3


# ------------------------------------------------------------ state --------

def test_state_roundtrip(app_modules):
    db = app_modules["db"]
    assert db.get_state("missing-key") is None
    assert db.get_state("missing-key", "fallback") == "fallback"
    db.set_state("k", "v1")
    assert db.get_state("k") == "v1"
    db.set_state("k", "v2")  # upsert
    assert db.get_state("k") == "v2"


# ------------------------------------------------------------ stats --------

def test_stats_counts(app_modules):
    db = app_modules["db"]
    before = db.stats()

    with db.tx() as cur:
        db.upsert_item(cur, imdb_id="tt9200301", media_type="movie",
                       site_category="movies", title="Stat Movie (2020)",
                       name="Stat Movie", year=2020)
        db.upsert_item(cur, imdb_id="tt9200302", media_type="movie",
                       site_category="movies", title="Stat Movie II (2021)",
                       name="Stat Movie II", year=2021)
        db.upsert_item(cur, imdb_id="tt9200303", media_type="series",
                       site_category="tv-series", title="Stat Series (2022)",
                       name="Stat Series", year=2022)
    db.set_stream_result("tt9200301", "crawled", {"ok": True}, [
        {"url": "https://a.example/x.mp4", "kind": "direct",
         "season": None, "episode": None, "label": "A"},
    ])

    after = db.stats()
    assert after["items"] == before["items"] + 3
    assert after["movies"] == before["movies"] + 2
    assert after["series"] == before["series"] + 1
    assert after["streams"] == before["streams"] + 1
    assert after["crawled"] == before["crawled"] + 1
    assert after["pending"] == before["pending"] + 2
    assert after["gated"] == before["gated"]
    # always the scratch database, never the production one
    assert after["db_path"] == os.environ["OLA_DB"]
    assert "data" not in after["db_path"].rsplit("/", 2)[-2]
    assert after["db_size_bytes"] > 0
    assert after["generated_at"]
