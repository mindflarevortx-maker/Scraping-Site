"""Addon HTTP API tests through fastapi's TestClient (httpx-backed).

app.main is imported via the session-scoped ``app_modules`` fixture so that
``OLA_DB`` already points at the scratch database (app.config reads it at
import time — see conftest.py).  The database is seeded through the same
``db.upsert_item`` the crawler uses.
"""
import pytest
from fastapi.testclient import TestClient

MOVIE_1 = "tt9100001"
MOVIE_2 = "tt9100002"
SERIES_1 = "tt9100003"

MOVIE_1_SITE = "https://v6.olamovies.mov/movies/alpha-quest-2024"
MOVIE_2_SITE = "https://v6.olamovies.mov/movies/beta-film-2023"
SERIES_1_SITE = "https://v6.olamovies.mov/tv-series/gamma-show-2025"


@pytest.fixture(scope="module")
def seeded(app_modules, _clean_db):
    """2 movies + 1 series, exactly like crawler-produced rows."""
    db = app_modules["db"]
    with db.tx() as cur:
        db.upsert_item(
            cur, imdb_id=MOVIE_1, media_type="movie", site_category="movies",
            title="Alpha Quest (2024) 1080p WEB-DL", name="Alpha Quest", year=2024,
            poster_url="https://img.ol-am.top/posters/tt9100001/a.webp",
            site_url=MOVIE_1_SITE, slug="alpha-quest-2024",
            size_label="4 GB", imdb_rating="7.5", release_desc="2024 · 1080p WEB-DL",
        )
        db.upsert_item(
            cur, imdb_id=MOVIE_2, media_type="movie", site_category="movies",
            title="Beta Film (2023)", name="Beta Film", year=2023,
            poster_url="https://img.ol-am.top/posters/tt9100002/b.webp",
            site_url=MOVIE_2_SITE, slug="beta-film-2023",
        )
        db.upsert_item(
            cur, imdb_id=SERIES_1, media_type="series", site_category="tv-series",
            title="Gamma Show (2025) Season 1 S01", name="Gamma Show", year=2025,
            poster_url="https://img.ol-am.top/posters/tt9100003/c.webp",
            site_url=SERIES_1_SITE, slug="gamma-show-2025",
        )
    return {"movies": [MOVIE_1, MOVIE_2], "series": [SERIES_1]}


@pytest.fixture(scope="module")
def client(app_modules, seeded):
    main = app_modules["main"]
    with TestClient(main.app) as c:
        yield c


# ------------------------------------------------------------ manifest ----

def test_manifest(client, app_modules):
    r = client.get("/manifest.json")
    assert r.status_code == 200
    m = r.json()
    assert m["id"] == app_modules["config"].ADDON_ID
    assert m["version"]
    assert {"movie", "series"}.issubset(set(m["types"]))
    assert {"catalog", "meta", "stream"}.issubset(set(m["resources"]))
    assert m["idPrefixes"] == ["tt", "ola"]
    assert len(m["catalogs"]) == 3
    assert {(c["type"], c["id"]) for c in m["catalogs"]} == {
        ("movie", "movies"), ("series", "tv-series"), ("series", "tv-shows"),
    }
    # cache header sanity
    assert "max-age" in r.headers.get("cache-control", "")


def test_root_redirects_to_manifest(client):
    r = client.get("/", follow_redirects=False)
    assert r.status_code in (307, 302)
    assert r.headers["location"].endswith("/manifest.json")
    # and following the redirect lands on the manifest
    r2 = client.get("/", follow_redirects=True)
    assert r2.status_code == 200
    assert r2.json()["id"]


# ------------------------------------------------------------ catalog -----

def test_catalog_movies(client, seeded):
    r = client.get("/catalog/movie/movies.json")
    assert r.status_code == 200
    metas = r.json()["metas"]
    assert len(metas) == 2
    assert {m["id"] for m in metas} == set(seeded["movies"])
    for m in metas:
        assert m["name"]
        assert m["poster"].startswith("https://img.ol-am.top/")
        assert m["type"] == "movie"
    by_id = {m["id"]: m for m in metas}
    assert by_id[MOVIE_1]["name"] == "Alpha Quest"
    assert by_id[MOVIE_1]["releaseInfo"] == "2024"


def test_catalog_search(client, seeded):
    r = client.get("/catalog/movie/movies.json", params={"search": "Alpha"})
    assert r.status_code == 200
    metas = r.json()["metas"]
    assert [m["id"] for m in metas] == [MOVIE_1]
    assert metas[0]["name"] == "Alpha Quest"

    # also matches a raw-title fragment
    r2 = client.get("/catalog/movie/movies.json", params={"search": "Film"})
    assert [m["id"] for m in r2.json()["metas"]] == [MOVIE_2]

    # and filters out non-matches
    r3 = client.get("/catalog/movie/movies.json", params={"search": "zzz-nothing"})
    assert r3.json()["metas"] == []


def test_catalog_series(client, seeded):
    r = client.get("/catalog/series/tv-series.json")
    assert r.status_code == 200
    metas = r.json()["metas"]
    assert [m["id"] for m in metas] == [SERIES_1]
    assert metas[0]["name"] == "Gamma Show"
    assert metas[0]["type"] == "series"

    # the movies catalog yields nothing for series and vice versa
    assert client.get("/catalog/series/movies.json").json()["metas"] == []
    # unknown catalog id → empty, not an error
    assert client.get("/catalog/movie/bogus.json").json()["metas"] == []


def test_catalog_skip(client, seeded):
    r = client.get("/catalog/movie/movies.json", params={"skip": 1})
    metas = r.json()["metas"]
    assert len(metas) == 1
    assert metas[0]["id"] in seeded["movies"]
    r2 = client.get("/catalog/movie/movies.json", params={"skip": 10})
    assert r2.json()["metas"] == []


# -------------------------------------------------------------- meta ------

def test_meta_movie(client, seeded):
    r = client.get(f"/meta/movie/{MOVIE_1}.json")
    assert r.status_code == 200
    meta = r.json()["meta"]
    assert meta["id"] == MOVIE_1
    assert meta["name"] == "Alpha Quest"
    assert meta["type"] == "movie"
    assert meta["poster"].startswith("https://img.ol-am.top/")
    assert meta["releaseInfo"] == "2024"
    assert meta["imdbRating"] == 7.5
    assert "1080p" in meta["description"]
    assert meta["background"]  # series/movie meta reuses the poster


def test_meta_series(client, seeded):
    r = client.get(f"/meta/series/{SERIES_1}.json")
    assert r.status_code == 200
    meta = r.json()["meta"]
    assert meta["id"] == SERIES_1
    assert meta["name"] == "Gamma Show"
    assert meta["type"] == "series"
    # no per-episode streams crawled yet → no videos list
    assert "videos" not in meta


def test_meta_unknown_item(client, seeded):
    r = client.get("/meta/movie/tt0000009.json")
    assert r.status_code == 200
    assert r.json()["meta"]["name"] == ""


# ------------------------------------------------------------ streams ----

def test_stream_movie_fallback(client, seeded):
    """No crawled stream rows yet → single 'open on the site' fallback."""
    r = client.get(f"/stream/movie/{MOVIE_1}.json")
    assert r.status_code == 200
    streams = r.json()["streams"]
    assert isinstance(streams, list)
    assert len(streams) == 1
    s = streams[0]
    assert s["externalUrl"] == MOVIE_1_SITE
    assert s["behaviorHints"]["web"] is True
    assert s["name"]
    assert "Alpha Quest" in s["title"]
    assert "url" not in s  # fallback is external, not a playable url


def test_stream_series_episode_routes(client, seeded):
    # canonical Stremio episode form /stream/series/<id>:<season>:<episode>.json
    r = client.get(f"/stream/series/{SERIES_1}:1:1.json")
    assert r.status_code == 200
    streams = r.json()["streams"]
    assert len(streams) == 1
    assert streams[0]["externalUrl"] == SERIES_1_SITE
    assert streams[0]["behaviorHints"]["web"] is True

    # query-parameter form
    r2 = client.get(f"/stream/series/{SERIES_1}.json",
                    params={"season": 1, "episode": 1})
    assert r2.status_code == 200
    assert r2.json()["streams"][0]["externalUrl"] == SERIES_1_SITE

    # plain series form (no episode info)
    r3 = client.get(f"/stream/series/{SERIES_1}.json")
    assert r3.status_code == 200
    assert r3.json()["streams"][0]["externalUrl"] == SERIES_1_SITE


def test_stream_unknown_item(client, seeded):
    assert client.get("/stream/movie/tt0000009.json").json() == {"streams": []}
    assert client.get("/stream/series/tt0000009:1:1.json").json() == {"streams": []}


def test_stream_movie_with_resolved_rows(client, app_modules, seeded):
    """Once the crawler has stored stream rows they take precedence over the
    site fallback, and only 'direct' links are served as playable urls."""
    db = app_modules["db"]
    db.set_stream_result(MOVIE_2, "crawled", {"links": 2}, [
        {"season": None, "episode": None, "label": "GDrive 1080p",
         "quality": "1080p", "size": "3 GB", "host": "drive.google.com",
         "url": "https://drive.google.com/folders/xyz", "kind": "gdrive"},
        {"season": None, "episode": None, "label": "Direct mp4",
         "quality": "720p", "size": "1 GB", "host": "cdn.example.com",
         "url": "https://cdn.example.com/beta.mp4", "kind": "direct"},
    ])
    r = client.get(f"/stream/movie/{MOVIE_2}.json")
    assert r.status_code == 200
    streams = r.json()["streams"]
    assert len(streams) == 2
    gdrive = next(s for s in streams if s.get("behaviorHints"))
    direct = next(s for s in streams if not s.get("behaviorHints"))
    assert gdrive["behaviorHints"]["web"] is True
    assert gdrive["externalUrl"] == "https://drive.google.com/folders/xyz"
    assert direct["url"] == "https://cdn.example.com/beta.mp4"
    assert "externalUrl" not in direct


# ------------------------------------------------------------- health -----

def test_health(client, app_modules, seeded):
    r = client.get("/health")
    assert r.status_code == 200
    st = r.json()
    # stable counts from this module's seed (no items are added elsewhere)
    assert st["items"] == 3
    assert st["movies"] == 2
    assert st["series"] == 1
    # every counter must agree with a direct db.stats() snapshot
    db = app_modules["db"]
    expected = {k: v for k, v in db.stats().items() if k != "generated_at"}
    actual = {k: v for k, v in st.items() if k != "generated_at"}
    assert actual == expected
    # always the scratch database, never the production one
    assert st["db_path"] == str(app_modules["config"].DB_PATH)
    assert "olamovies.db" not in st["db_path"]
    assert r.headers.get("cache-control") == "no-store"
