"""Tests for crawler.resolve — the `python -m crawler url` single-item resolver.

Same conventions as test_addon.py: every app/crawler module is imported
through the session-scoped ``app_modules`` fixture so ``OLA_DB`` already
points at the scratch database (see conftest.py).  Streams are seeded
directly through ``db.set_stream_result`` so NO test touches the network —
the live-fetch path is only exercised through a monkeypatched crawl_item.
"""
import importlib
import json

import pytest

MOVIE = "tt9200001"       # Alpha Quest (2024) — movie
SERIES = "tt9200002"      # Gamma Show (2025) — series
MOVIE2 = "tt9200003"      # Gamma Film (2019) — movie (shared "Gamma" stem)
DELTA = "tt9200004"       # Delta Show (2021) — series (all streams S01)
SYNTH = "ola:synthetic-thing"  # telegram-style synthetic id

MOVIE_SITE = "https://v6.olamovies.mov/movies/alpha-quest-2024"
SERIES_SITE = "https://v6.olamovies.mov/tv-series/gamma-show-2025"
MOVIE2_SITE = "https://v6.olamovies.mov/movies/gamma-film-2019"
DELTA_SITE = "https://v6.olamovies.mov/tv-series/delta-show-2021"


@pytest.fixture(scope="module")
def resolve_mod(app_modules):
    return importlib.import_module("crawler.resolve")


@pytest.fixture(scope="module")
def cli_mod(app_modules):
    return importlib.import_module("crawler.cli")


@pytest.fixture(scope="module")
def seeded(app_modules, _clean_db):
    """4 items, exactly like crawler-produced rows (no streams yet)."""
    db = app_modules["db"]
    with db.tx() as cur:
        db.upsert_item(
            cur, imdb_id=MOVIE, media_type="movie", site_category="movies",
            title="Alpha Quest (2024) 1080p WEB-DL", name="Alpha Quest", year=2024,
            site_url=MOVIE_SITE, slug="alpha-quest-2024",
        )
        db.upsert_item(
            cur, imdb_id=SERIES, media_type="series", site_category="tv-series",
            title="Gamma Show (2025) Season 1 S01", name="Gamma Show", year=2025,
            site_url=SERIES_SITE, slug="gamma-show-2025",
        )
        db.upsert_item(
            cur, imdb_id=MOVIE2, media_type="movie", site_category="movies",
            title="Gamma Film (2019)", name="Gamma Film", year=2019,
            site_url=MOVIE2_SITE, slug="gamma-film-2019",
        )
        db.upsert_item(
            cur, imdb_id=DELTA, media_type="series", site_category="tv-series",
            title="Delta Show (2021) Season 1", name="Delta Show", year=2021,
            site_url=DELTA_SITE, slug="delta-show-2021",
        )
        db.upsert_item(
            cur, imdb_id=SYNTH, media_type="series", site_category=None,
            title="Synthetic Thing (2026)", name="Synthetic Thing", year=2026,
            site_url=None, slug="synthetic-thing",
        )
    return {"movie": MOVIE, "series": SERIES, "movie2": MOVIE2,
            "delta": DELTA, "synth": SYNTH}


# ------------------------------------------------------------ search_items --

def test_search_items_like_matches_name_and_title(resolve_mod, seeded):
    """(a) fragment search over BOTH name and title columns."""
    ids = {r["imdb_id"] for r in resolve_mod.search_items("gamma")}
    assert {SERIES, MOVIE2}.issubset(ids)
    # "quest" only appears in Alpha Quest's name/title
    assert [r["imdb_id"] for r in resolve_mod.search_items("quest")] == [MOVIE]
    # raw-title fragment also matches (title says "Season 1 S01")
    assert SERIES in {r["imdb_id"] for r in resolve_mod.search_items("S01")}
    # no false positives
    assert resolve_mod.search_items("zzz-nothing") == []


def test_search_items_ranks_exact_name_first(resolve_mod, seeded):
    rows = resolve_mod.search_items("Gamma Show")
    assert rows[0]["imdb_id"] == SERIES


def test_search_items_exact_id_passthrough(resolve_mod, seeded):
    """(b) tt-ids and ola: synthetic ids bypass the LIKE search entirely."""
    rows = resolve_mod.search_items(SERIES)
    assert len(rows) == 1
    assert rows[0]["imdb_id"] == SERIES
    rows = resolve_mod.search_items(SYNTH)
    assert len(rows) == 1
    assert rows[0]["imdb_id"] == SYNTH
    # unknown ids never fall back to LIKE
    assert resolve_mod.search_items("tt0000000") == []
    assert resolve_mod.search_items("ola:nope") == []


def test_search_items_limit(resolve_mod, seeded):
    assert len(resolve_mod.search_items("gamma", limit=1)) == 1


# ---------------------------------------------------------------- resolve --

def test_resolve_prints_stored_streams(resolve_mod, seeded, app_modules, capsys):
    """(c) streams seeded via set_stream_result are printed, no network."""
    db = app_modules["db"]
    db.set_stream_result(MOVIE, "crawled", {"links": 2}, [
        {"season": None, "episode": None, "label": "1080p · 3.4 GB · drive.google.com",
         "quality": "1080p", "size": "3.4 GB", "host": "drive.google.com",
         "url": "https://drive.google.com/file/d/abc123/view", "kind": "gdrive"},
        {"season": None, "episode": None, "label": "720p · 1.2 GB · cdn.example.com",
         "quality": "720p", "size": "1.2 GB", "host": "cdn.example.com",
         "url": "https://cdn.example.com/alpha-quest-720p.mkv", "kind": "direct"},
    ])
    rc = resolve_mod.resolve(MOVIE)
    out = capsys.readouterr().out
    assert rc == 0
    # full URLs, never truncated
    assert "https://drive.google.com/file/d/abc123/view" in out
    assert "https://cdn.example.com/alpha-quest-720p.mkv" in out
    # table carries kind / quality / size / label
    assert "gdrive" in out and "direct" in out
    assert "1080p" in out and "720p" in out
    assert "3.4 GB" in out and "1.2 GB" in out
    assert "Alpha Quest" in out
    assert "→ 2 link(s)" in out


def test_resolve_season_episode_filters(resolve_mod, seeded, app_modules, capsys):
    """(d) season/episode filtering incl. NULL-season streams surfacing
    for every season (documented db.streams_for behavior)."""
    db = app_modules["db"]
    db.set_stream_result(SERIES, "crawled", {"links": 3}, [
        {"season": 1, "episode": 5, "label": "S01E05 1080p", "quality": "1080p",
         "size": "1.5 GB", "host": "cdn.example.com",
         "url": "https://cdn.example.com/gamma-s01e05.mkv", "kind": "direct"},
        {"season": 1, "episode": 6, "label": "S01E06 1080p", "quality": "1080p",
         "size": "1.5 GB", "host": "cdn.example.com",
         "url": "https://cdn.example.com/gamma-s01e06.mkv", "kind": "direct"},
        # NULL season/episode = whole-series pack → surfaces for EVERY season
        {"season": None, "episode": None, "label": "Season 1 pack",
         "quality": None, "size": "42 GB", "host": "drive.google.com",
         "url": "https://drive.google.com/folders/gamma-s01-pack", "kind": "gdrive"},
    ])

    # season 1 episode 5: matching episode + the NULL-season pack
    rc = resolve_mod.resolve(SERIES, season=1, episode=5)
    out = capsys.readouterr().out
    assert rc == 0
    assert "gamma-s01e05.mkv" in out
    assert "gamma-s01-pack" in out            # NULL-season surfaces
    assert "gamma-s01e06.mkv" not in out      # other episodes filtered out
    assert "→ 2 link(s)" in out

    # season 2 (not in DB): only the NULL-season pack surfaces
    rc = resolve_mod.resolve(SERIES, season=2)
    out = capsys.readouterr().out
    assert rc == 0
    assert "gamma-s01-pack" in out
    assert "gamma-s01e05.mkv" not in out
    assert "→ 1 link(s)" in out


def test_resolve_no_episode_match_notes_unfiltered_count(
        resolve_mod, seeded, app_modules, capsys):
    """When the season/episode filter yields nothing, the user is told how
    many links exist un-filtered (so they know links exist, just not there)."""
    db = app_modules["db"]
    db.set_stream_result(DELTA, "crawled", {"links": 2}, [
        {"season": 1, "episode": 1, "label": "S01E01", "quality": "720p",
         "size": "800 MB", "host": "cdn.example.com",
         "url": "https://cdn.example.com/delta-s01e01.mkv", "kind": "direct"},
        {"season": 1, "episode": 2, "label": "S01E02", "quality": "720p",
         "size": "800 MB", "host": "cdn.example.com",
         "url": "https://cdn.example.com/delta-s01e02.mkv", "kind": "direct"},
    ])
    rc = resolve_mod.resolve(DELTA, season=2, episode=1)
    out = capsys.readouterr().out
    assert rc == 1
    assert "2 link(s) exist" in out
    assert "none match season 2 episode 1" in out
    assert "→ 0 link(s)" in out


def test_resolve_json_output(resolve_mod, seeded, app_modules, capsys):
    """--json prints exactly one JSON object on stdout (logs go to stderr)."""
    db = app_modules["db"]
    db.set_stream_result(MOVIE, "crawled", {"links": 1}, [
        {"season": None, "episode": None, "label": "1080p · 3.4 GB · drive.google.com",
         "quality": "1080p", "size": "3.4 GB", "host": "drive.google.com",
         "url": "https://drive.google.com/file/d/abc123/view", "kind": "gdrive"},
    ])
    rc = resolve_mod.resolve(MOVIE, json_output=True)
    captured = capsys.readouterr()
    obj = json.loads(captured.out)  # stdout must be pure JSON
    assert rc == 0
    assert obj["imdb_id"] == MOVIE
    assert obj["title"] == "Alpha Quest"
    assert obj["year"] == 2024
    assert obj["media_type"] == "movie"
    assert obj["status"] == "crawled"
    assert obj["season"] is None and obj["episode"] is None
    assert len(obj["streams"]) == 1
    assert obj["streams"][0]["url"] == "https://drive.google.com/file/d/abc123/view"
    assert obj["streams"][0]["kind"] == "gdrive"


def test_resolve_error_status_prints_cf_guidance(
        resolve_mod, seeded, app_modules, monkeypatch, capsys):
    """Live fetch fails (the sandbox CF-block path) → status persisted,
    clear guidance printed, non-zero exit. crawl_item is monkeypatched —
    no network."""
    site = importlib.import_module("crawler.site")
    monkeypatch.setattr(
        site, "crawl_item",
        lambda *a, **k: ("error", {"reason": "fetch failed (Cloudflare?)"}, []),
    )
    rc = resolve_mod.resolve(MOVIE2, refresh=True)
    out = capsys.readouterr().out
    assert rc == 1
    assert "status: error" in out
    assert "Blocked by Cloudflare" in out
    assert "residential" in out
    assert "OLA_ACCOUNT_COOKIE" in out
    assert "→ 0 link(s)" in out
    # the error result is persisted (retried later by `crawler streams`)
    assert app_modules["db"].get_item(MOVIE2)["stream_status"] == "error"


def test_resolve_not_found_returns_2(resolve_mod, capsys):
    """(f) unknown id → friendly hint + exit code 2."""
    rc = resolve_mod.resolve("tt0000000")
    out = capsys.readouterr().out
    assert rc == 2
    assert "not found" in out
    assert "python -m crawler url '<title>'" in out


# ------------------------------------------------------------------- cli ---

def test_cli_multiple_match_lists_and_exits_zero(cli_mod, seeded, app_modules, capsys):
    """(e) ambiguous query → numbered candidate list, no resolve, exit 0."""
    # pin statuses so the assertion is independent of earlier tests in this module
    db = app_modules["db"]
    db.set_stream_result(SERIES, "pending", None, None)
    db.set_stream_result(MOVIE2, "pending", None, None)
    rc = cli_mod.main(["url", "gamma"])
    out = capsys.readouterr().out
    assert rc == 0
    assert "2 item(s) match 'gamma':" in out
    assert SERIES in out and MOVIE2 in out
    assert "[series]" in out and "[movie]" in out
    assert "pending" in out
    assert "python -m crawler url tt9200002" in out  # re-run hint w/ an id
    assert "link(s)" not in out or "match" in out    # no resolve output


def test_cli_single_match_resolves(cli_mod, seeded, app_modules, capsys):
    db = app_modules["db"]
    db.set_stream_result(MOVIE, "crawled", {"links": 1}, [
        {"season": None, "episode": None, "label": "1080p", "quality": "1080p",
         "size": "3.4 GB", "host": "drive.google.com",
         "url": "https://drive.google.com/file/d/abc123/view", "kind": "gdrive"},
    ])
    rc = cli_mod.main(["url", "alpha quest"])
    out = capsys.readouterr().out
    assert rc == 0
    assert "https://drive.google.com/file/d/abc123/view" in out
    assert "→ 1 link(s)" in out


def test_cli_season_flag_resolves_best_match_directly(
        cli_mod, seeded, app_modules, capsys):
    """--season/--episode given → best match resolved without listing."""
    db = app_modules["db"]
    db.set_stream_result(SERIES, "crawled", {"links": 1}, [
        {"season": 1, "episode": 5, "label": "S01E05 1080p", "quality": "1080p",
         "size": "1.5 GB", "host": "cdn.example.com",
         "url": "https://cdn.example.com/gamma-s01e05.mkv", "kind": "direct"},
    ])
    rc = cli_mod.main(["url", "gamma", "--season", "1", "--episode", "5"])
    out = capsys.readouterr().out
    assert rc == 0
    assert "gamma-s01e05.mkv" in out
    assert "2 matches for 'gamma'" in out   # note about the best-match pick
    assert "→ 1 link(s)" in out


def test_cli_no_match_returns_2(cli_mod, seeded, capsys):
    rc = cli_mod.main(["url", "zzz-nothing"])
    out = capsys.readouterr().out
    assert rc == 2
    assert "no items match" in out
