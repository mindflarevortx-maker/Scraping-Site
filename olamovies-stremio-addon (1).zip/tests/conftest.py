"""Shared fixtures for the OlaMovies Stremio addon test suite.

The critical job of this file: point ``OLA_DB`` at a scratch database BEFORE
any ``app.*`` module is imported.  ``app/config.py`` reads OLA_DB at import
time and ``app/db.py`` bakes the resolved path into its thread-local
connections, so the tests must never let those modules see the production
database (``data/olamovies.db`` — a background crawler writes to it while the
suite runs).

pytest imports ``conftest.py`` before any test module in this directory, so
setting the env var at conftest import time (module level, below) protects
even test modules that do ``from app import db`` at top level.  The
session-scoped :func:`app_modules` fixture then imports the app through
importlib and *asserts* the invariant, failing loudly if the app somehow got
imported against the wrong database first.
"""
import importlib
import os
import shutil
import sys
import tempfile
from pathlib import Path

import pytest

PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

# ------------------------------------------------------------ scratch db ---
# Must happen at conftest import time, i.e. before ANY test module (and thus
# before the first `import app...` anywhere in the suite).
_TMP_DIR = Path(tempfile.mkdtemp(prefix="olamovies-pytest-"))
TEST_DB_PATH = _TMP_DIR / "test-db.sqlite3"
os.environ["OLA_DB"] = str(TEST_DB_PATH)
PRODUCTION_DB = PROJECT_ROOT / "data" / "olamovies.db"

FIXTURES_DIR = Path(__file__).resolve().parent / "fixtures"


@pytest.fixture(scope="session")
def app_modules():
    """Import the app/crawler modules AFTER OLA_DB points at the scratch DB.

    Yields a dict: {"config", "titles", "db", "flight", "main", "space"}.
    Tests that need env-sensitive modules (config/db/main/space) must go
    through this fixture instead of importing them at module top level.
    """
    mods = {
        "config": importlib.import_module("app.config"),
        "titles": importlib.import_module("app.titles"),
        "db": importlib.import_module("app.db"),
        "flight": importlib.import_module("crawler.flight"),
        "main": importlib.import_module("app.main"),
        "space": importlib.import_module("crawler.space"),
    }
    # Safety guard: refuse to run if the app resolved to any other database.
    assert mods["config"].DB_PATH == TEST_DB_PATH, (
        "app.config was imported before OLA_DB was set "
        f"(DB_PATH={mods['config'].DB_PATH!s}); refusing to run tests "
        "against it"
    )
    assert mods["config"].DB_PATH.resolve() != PRODUCTION_DB.resolve(), (
        f"tests would run against the production DB {PRODUCTION_DB}"
    )
    yield mods
    shutil.rmtree(_TMP_DIR, ignore_errors=True)


@pytest.fixture(autouse=True, scope="module")
def _clean_db(app_modules):
    """Start every test module with empty items/streams/state tables.

    db connections are thread-local and long-lived, so instead of swapping
    DB files we simply wipe the tables (the schema is created by db.conn()).
    This keeps modules order-independent.
    """
    db = app_modules["db"]
    with db.tx() as cur:
        cur.execute("DELETE FROM streams")
        cur.execute("DELETE FROM items")
        cur.execute("DELETE FROM state")
    yield
