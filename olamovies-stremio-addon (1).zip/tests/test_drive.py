"""Tests for crawler.drive — the OMDrive (drive.olamovies.download) resolver.

Same conventions as test_addon.py / test_resolve.py: every app/crawler module
is imported through the session-scoped ``app_modules`` fixture so ``OLA_DB``
already points at the scratch database (see conftest.py). All network touch
points (crawler.fetcher.get / .post) are monkeypatched — NO test touches the
network, and the stealth-browser path is either monkeypatched or disabled.
"""
import importlib
import time
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

FIXTURES = Path(__file__).resolve().parent / "fixtures"

CRYPT = "0ltzj66qbtbheg74r06m"
FILE_URL = f"https://drive.olamovies.download/file/{CRYPT}"
FILE_NAME = (
    "The End of Oak Street (2026) REPACK 1080p 10bit AMZN WEBRip x265 HEVC "
    "Multi Audio [Org AMZN Hindi-Tamil-Telugu DDP 5.1 ~ 640Kbps + English "
    "HE-AAC 5.1] ESub ~ PSA.mkv"
)
V1 = "https://omd-rb.omd-uf5-e678.workers.dev/serve?t=e2abc123"

MOVIE = "tt9400001"
MOVIE_SITE = "https://v6.olamovies.mov/movies/oak-street-2026"


class FakeResp:
    """Duck-typed stand-in for the Scrapling Response (what fetcher returns)."""

    def __init__(self, status=200, html="", payload=None):
        self.status = status
        self.html_content = html
        self._payload = payload
        self.headers = {}

    def json(self):
        if self._payload is None:
            raise ValueError("no json payload")
        return self._payload


def _fake_get(html_by_url=None, json_by_url=None):
    """URL-keyed fetcher.get fake; records every call in ``calls``."""
    html_by_url = html_by_url or {}
    json_by_url = json_by_url or {}

    def fake_get(url, **kwargs):
        fake_get.calls.append(url)
        if url in json_by_url:
            return FakeResp(200, payload=json_by_url[url])
        if url in html_by_url:
            return FakeResp(200, html=html_by_url[url])
        return None
    fake_get.calls = []
    return fake_get


def _fake_post(json_by_url=None):
    """URL-keyed fetcher.post fake; records (url, body) tuples in ``calls``."""
    json_by_url = json_by_url or {}

    def fake_post(url, json=None, **kwargs):
        fake_post.calls.append((url, json))
        if url in json_by_url:
            return FakeResp(200, payload=json_by_url[url])
        return FakeResp(404, payload={"success": False, "error": "not found"})
    fake_post.calls = []
    return fake_post


@pytest.fixture(scope="module")
def drive_mod(app_modules):
    return importlib.import_module("crawler.drive")


@pytest.fixture(scope="module")
def fetcher_mod(app_modules):
    return importlib.import_module("crawler.fetcher")


@pytest.fixture(scope="module")
def site_mod(app_modules):
    return importlib.import_module("crawler.site")


@pytest.fixture(scope="module")
def cli_mod(app_modules):
    return importlib.import_module("crawler.cli")


@pytest.fixture(scope="module")
def resolve_cli_mod(app_modules):
    return importlib.import_module("crawler.resolve")


@pytest.fixture(scope="module")
def fixture_html():
    return (FIXTURES / "drive_file.html").read_text(encoding="utf-8")


@pytest.fixture(autouse=True)
def clean_drive_cache(drive_mod):
    """drive.py keeps in-process caches — start every test empty."""
    drive_mod._CACHE.clear()
    drive_mod._NEG_CACHE.clear()
    yield
    drive_mod._CACHE.clear()
    drive_mod._NEG_CACHE.clear()


# ------------------------------------------------------------ extraction --

def test_parse_file_page_fixture(drive_mod, app_modules, fixture_html):
    """The captured OMDrive file page: file name from <title> (suffix
    stripped), crypt from the flight stream's urlParts."""
    info = drive_mod.parse_file_page(fixture_html)
    assert info["file_name"] == FILE_NAME
    assert info["crypt"] == CRYPT
    # the flight stream of a file page carries only ad scripts — no drive URLs
    flight = app_modules["flight"].extract_flight(fixture_html)
    assert drive_mod.extract_drive_links(flight) == []
    # degenerate inputs
    assert drive_mod.parse_file_page("") == {"crypt": None, "file_name": None}


def test_extract_drive_links_unique_order_preserving(drive_mod):
    src = (
        '<a href="https://drive.olamovies.download/file/abc123">dl</a> '
        'https://drive.olamovies.download/file/abc123 '
        '{"url":"https://drive.olamovies.download/file/xyz_-789"} '
        'https://omd-rb.omd-uf5-e678.workers.dev/serve?t=e2.not-a-file-page '
        'https://drive.google.com/file/d/x/view'
    )
    assert drive_mod.extract_drive_links(src) == [
        "https://drive.olamovies.download/file/abc123",
        "https://drive.olamovies.download/file/xyz_-789",
    ]
    assert drive_mod.extract_drive_links("") == []
    assert drive_mod.extract_drive_links(None) == []


def test_normalize_crypt(drive_mod):
    assert drive_mod.normalize_crypt(FILE_URL) == CRYPT
    assert drive_mod.normalize_crypt(CRYPT) == CRYPT
    assert drive_mod.normalize_crypt("  " + CRYPT + " ") == CRYPT
    assert drive_mod.normalize_crypt("https://example.com/nope") is None
    assert drive_mod.normalize_crypt("") is None


def test_classify_link_omd_drive(app_modules):
    fl = app_modules["flight"]
    assert fl.classify_link("https://drive.olamovies.download/file/abc123") == "omd-drive"
    # existing kinds unchanged
    assert fl.classify_link("https://drive.google.com/folders/1AbCdEf") == "gdrive"
    assert fl.classify_link("https://cdn.example.com/movie.x.mp4") == "direct"
    assert fl.classify_link("https://example.com/folder/") == "folder"
    assert fl.classify_link("https://v6.olamovies.mov/tv-series/some-show") == "page"
    assert fl.classify_link("https://olam18plus.com/f/QIWKWWPi") == "page"


# ------------------------------------------------------- resolve (fast) ----

def test_resolve_not_authenticated_guidance(drive_mod, fetcher_mod, fixture_html,
                                            monkeypatch):
    """Anonymous POST → 'Not authenticated' → guidance mentioning
    OLA_DRIVE_COOKIE; resolve_cached then short-circuits (negative cache)."""
    fake_get = _fake_get(
        html_by_url={FILE_URL: fixture_html},
        json_by_url={f"https://drive.olamovies.download/api/turnstile?crypt={CRYPT}":
                     {"verified": False}},
    )
    fake_post = _fake_post({
        "https://drive.olamovies.download/api/cloud/download-links":
            {"success": False, "error": "Not authenticated"},
    })
    monkeypatch.setattr(fetcher_mod, "get", fake_get)
    monkeypatch.setattr(fetcher_mod, "post", fake_post)

    res = drive_mod.resolve(CRYPT, use_browser=False)
    assert res["crypt"] == CRYPT
    assert res["file_name"] == FILE_NAME
    assert res["v1"] is None
    assert res["status"] == "auth_required"
    assert "OLA_DRIVE_COOKIE" in res["detail"]
    # the file page + turnstile endpoints were actually queried
    assert FILE_URL in fake_get.calls

    # cache-first variant returns None and does not re-attempt immediately
    calls_before = len(fake_get.calls)
    assert drive_mod.resolve_cached(FILE_URL) is None
    assert len(fake_get.calls) == calls_before


def test_resolve_verification_required_guidance(drive_mod, fetcher_mod,
                                                fixture_html, monkeypatch):
    monkeypatch.setattr(fetcher_mod, "get", _fake_get(
        html_by_url={FILE_URL: fixture_html},
        json_by_url={f"https://drive.olamovies.download/api/turnstile?crypt={CRYPT}":
                     {"verified": False}},
    ))
    monkeypatch.setattr(fetcher_mod, "post", _fake_post({
        "https://drive.olamovies.download/api/cloud/download-links":
            {"success": False, "error": "verification_required"},
    }))

    res = drive_mod.resolve(CRYPT, use_browser=False)
    assert res["status"] == "verification_required"
    assert res["v1"] is None
    detail = res["detail"].lower()
    assert "turnstile" in detail and "browser" in detail


def test_resolve_verification_required_uses_browser(drive_mod, fetcher_mod,
                                                    fixture_html, monkeypatch):
    """With use_browser=True the browser path is attempted and its result
    is cached like a fast-path success."""
    monkeypatch.setattr(fetcher_mod, "get", _fake_get(
        html_by_url={FILE_URL: fixture_html},
        json_by_url={f"https://drive.olamovies.download/api/turnstile?crypt={CRYPT}":
                     {"verified": False}},
    ))
    fake_post = _fake_post({
        "https://drive.olamovies.download/api/cloud/download-links":
            {"success": False, "error": "verification_required"},
    })
    monkeypatch.setattr(fetcher_mod, "post", fake_post)
    monkeypatch.setattr(drive_mod, "_browser_solve",
                        lambda *a, **k: {"success": True, "v1": V1})

    res = drive_mod.resolve(CRYPT, use_browser=True)
    assert res["status"] == "resolved"
    assert res["v1"] == V1
    assert "browser" in res["detail"].lower()
    # the resolved v1 is cached — a second resolve never POSTs again
    again = drive_mod.resolve(CRYPT)
    assert again["status"] == "cached" and again["v1"] == V1
    assert len([c for c in fake_post.calls
                if c[0].endswith("/api/cloud/download-links")]) == 1


def test_resolve_success_and_cache(drive_mod, fetcher_mod, fixture_html,
                                   monkeypatch):
    fake_get = _fake_get(
        html_by_url={FILE_URL: fixture_html},
        json_by_url={f"https://drive.olamovies.download/api/turnstile?crypt={CRYPT}":
                     {"verified": True}},
    )
    fake_post = _fake_post({
        "https://drive.olamovies.download/api/cloud/download-links":
            {"success": True, "v1": V1},
    })
    monkeypatch.setattr(fetcher_mod, "get", fake_get)
    monkeypatch.setattr(fetcher_mod, "post", fake_post)

    r1 = drive_mod.resolve(CRYPT, use_browser=False)
    assert r1["status"] == "resolved"
    assert r1["v1"] == V1
    assert r1["file_name"] == FILE_NAME
    assert r1["expires_at"] > time.time()

    # the POST body carries fileId + the parsed fileName
    dl_calls = [c for c in fake_post.calls
                if c[0].endswith("/api/cloud/download-links")]
    (url, body), = dl_calls
    assert url.endswith("/api/cloud/download-links")
    assert body == {"fileId": CRYPT, "fileName": FILE_NAME}

    # resolve_cached serves from the cache; a second resolve() too — exactly
    # one download-links POST in total
    r2 = drive_mod.resolve_cached(FILE_URL)
    assert r2 is not None and r2["v1"] == V1
    r3 = drive_mod.resolve(CRYPT)
    assert r3["status"] == "cached" and r3["v1"] == V1
    assert len(dl_calls) == 1


def test_resolve_cache_ttl_expiry(drive_mod, fetcher_mod, fixture_html,
                                  monkeypatch):
    monkeypatch.setattr(fetcher_mod, "get", _fake_get(
        html_by_url={FILE_URL: fixture_html},
        json_by_url={f"https://drive.olamovies.download/api/turnstile?crypt={CRYPT}":
                     {"verified": True}},
    ))
    fake_post = _fake_post({
        "https://drive.olamovies.download/api/cloud/download-links":
            {"success": True, "v1": V1},
    })
    monkeypatch.setattr(fetcher_mod, "post", fake_post)

    assert drive_mod.resolve(CRYPT, use_browser=False)["v1"] == V1
    assert len([c for c in fake_post.calls
                if c[0].endswith("/api/cloud/download-links")]) == 1

    # expire the cache entry → the next resolve refetches
    drive_mod._CACHE[CRYPT]["expires_at"] = time.time() - 1
    res = drive_mod.resolve(CRYPT, use_browser=False)
    assert res["status"] == "resolved" and res["v1"] == V1
    assert len([c for c in fake_post.calls
                if c[0].endswith("/api/cloud/download-links")]) == 2


def test_resolve_file_page_fetch_fails(drive_mod, fetcher_mod, monkeypatch):
    monkeypatch.setattr(fetcher_mod, "get", _fake_get())  # nothing resolves
    monkeypatch.setattr(fetcher_mod, "post", _fake_post())

    res = drive_mod.resolve(CRYPT, use_browser=False)
    assert res["status"] == "error"
    assert res["v1"] is None
    assert res["detail"]


def test_resolve_rejects_garbage_target(drive_mod):
    res = drive_mod.resolve("https://example.com/not-a-drive-url")
    assert res["status"] == "error"
    assert res["crypt"] is None


# ------------------------------------------------------ site.py integration --

def _flight_html(payload: str) -> str:
    """Wrap a JSON payload in a Next.js __next_f flight chunk."""
    escaped = payload.replace("\\", "\\\\").replace('"', '\\"')
    return ('<html><head><title>Oak Street</title></head><body>'
            f'<script>self.__next_f.push([1,"{escaped}"])</script>'
            '</body></html>')


ITEM_URL = "https://v6.olamovies.mov/movies/oak-street-2026"
F_URL = "https://v6.olamovies.mov/f/QIWKWWPi"
DRIVE_URL = FILE_URL  # the /f/ page points at our fixture crypt

ITEM_PAYLOAD = ('{"downloads":[{"name":"Oak Street (2026) 1080p 2.9GB",'
                '"slug":"QIWKWWPi","href":"/f/QIWKWWPi"}]}')
F_PAYLOAD = '{"fileLink":"' + DRIVE_URL + '"}'


def _seed_item(app_modules):
    db = app_modules["db"]
    with db.tx() as cur:
        db.upsert_item(
            cur, imdb_id=MOVIE, media_type="movie", site_category="movies",
            title="Oak Street (2026) 1080p WEB-DL", name="Oak Street", year=2026,
            site_url=MOVIE_SITE, slug="oak-street-2026",
        )
    db.set_stream_result(MOVIE, "crawled", {"links": 1}, [
        {"season": None, "episode": None,
         "label": "1080p · 2.9 GB · drive.olamovies.download",
         "quality": "1080p", "size": "2.9 GB", "host": "drive.olamovies.download",
         "url": DRIVE_URL, "kind": "omd-drive"},
    ])


def test_crawl_item_follows_f_link_to_drive(app_modules, site_mod, fetcher_mod,
                                            monkeypatch):
    """Item page with an /f/ link; the /f/ page contains a drive URL →
    streams gain kind='omd-drive' (inherited label), and the intermediate
    /f/ page link is dropped."""
    monkeypatch.setattr(app_modules["config"], "FOLLOW_F_LINKS", True)
    fake_get = _fake_get(html_by_url={
        ITEM_URL: _flight_html(ITEM_PAYLOAD),
        F_URL: ('<html><body><a href="' + DRIVE_URL + '">download</a>'
                + _flight_html(F_PAYLOAD) + '</body></html>'),
    })
    monkeypatch.setattr(fetcher_mod, "get", fake_get)

    status, detail, links = site_mod.crawl_item(ITEM_URL, "tt9500001", "movie")
    assert status == "crawled"
    omd = [l for l in links if l["kind"] == "omd-drive"]
    assert len(omd) == 1
    assert omd[0]["url"] == DRIVE_URL
    # label inherited from the /f/ link's parsed values (quality/size/host)
    assert "1080p" in omd[0]["label"]
    assert "2.9 GB" in omd[0]["label"]
    assert "drive.olamovies.download" in omd[0]["label"]
    # the intermediate /f/ page link is gone
    assert not any(l["url"] == F_URL for l in links)
    # the /f/ page was actually fetched
    assert F_URL in fake_get.calls


def test_crawl_item_keeps_f_link_when_fetch_fails(app_modules, site_mod,
                                                  fetcher_mod, monkeypatch):
    """/f/ page unreachable (sandbox: Cloudflare) → keep the /f/ link, no crash."""
    monkeypatch.setattr(app_modules["config"], "FOLLOW_F_LINKS", True)
    fake_get = _fake_get(html_by_url={ITEM_URL: _flight_html(ITEM_PAYLOAD)})
    monkeypatch.setattr(fetcher_mod, "get", fake_get)

    status, detail, links = site_mod.crawl_item(ITEM_URL, "tt9500001", "movie")
    assert status == "crawled"
    assert any(l["url"] == F_URL and l["kind"] == "page" for l in links)
    assert not any(l["kind"] == "omd-drive" for l in links)


def test_crawl_item_direct_drive_link_in_item_payload(app_modules, site_mod,
                                                       fetcher_mod, monkeypatch):
    """Drive file URLs found directly on the item page become omd-drive links
    even without any /f/ hop."""
    monkeypatch.setattr(app_modules["config"], "FOLLOW_F_LINKS", True)
    html = ('<html><body>'
            '<a href="' + DRIVE_URL + '">Oak Street 1080p</a>'
            '</body></html>')
    monkeypatch.setattr(fetcher_mod, "get",
                        _fake_get(html_by_url={ITEM_URL: html}))

    status, detail, links = site_mod.crawl_item(ITEM_URL, "tt9500001", "movie")
    assert status == "crawled"
    omd = [l for l in links if l["kind"] == "omd-drive"]
    assert len(omd) == 1 and omd[0]["url"] == DRIVE_URL


def test_crawl_item_f_link_following_disabled(app_modules, site_mod,
                                              fetcher_mod, monkeypatch):
    """OLA_FOLLOW_F_LINKS=0 keeps the raw /f/ page links (old behavior)."""
    monkeypatch.setattr(app_modules["config"], "FOLLOW_F_LINKS", False)
    fake_get = _fake_get(html_by_url={ITEM_URL: _flight_html(ITEM_PAYLOAD)})
    monkeypatch.setattr(fetcher_mod, "get", fake_get)

    status, detail, links = site_mod.crawl_item(ITEM_URL, "tt9500001", "movie")
    assert status == "crawled"
    assert any(l["url"] == F_URL for l in links)
    assert F_URL not in fake_get.calls  # no /f/ fetch happened at all


# ------------------------------------------------------------ addon (main) --

@pytest.fixture(scope="module")
def client(app_modules, _clean_db):
    _seed_item(app_modules)
    main = app_modules["main"]
    with TestClient(main.app) as c:
        yield c


def test_addon_omd_drive_resolved_to_direct_url(client, app_modules, drive_mod,
                                                monkeypatch):
    """resolve_cached returns a v1 → playable stream with the direct URL."""
    monkeypatch.setattr(app_modules["config"], "DRIVE_RESOLVE", False)
    monkeypatch.setattr(drive_mod, "resolve_cached",
                        lambda url: {"v1": V1, "file_name": FILE_NAME,
                                     "expires_at": time.time() + 3600})

    r = client.get(f"/stream/movie/{MOVIE}.json")
    assert r.status_code == 200
    streams = r.json()["streams"]
    assert len(streams) == 1
    s = streams[0]
    assert s["url"] == V1
    assert "externalUrl" not in s
    assert "OMDrive direct" in s["title"]
    assert "behaviorHints" not in s or not s.get("behaviorHints", {}).get("web")


def test_addon_omd_drive_fallback_when_unresolved(client, app_modules, drive_mod,
                                                  monkeypatch):
    """resolve_cached returns None → externalUrl fallback + guidance title."""
    monkeypatch.setattr(app_modules["config"], "DRIVE_RESOLVE", False)
    monkeypatch.setattr(drive_mod, "resolve_cached", lambda url: None)

    r = client.get(f"/stream/movie/{MOVIE}.json")
    assert r.status_code == 200
    streams = r.json()["streams"]
    assert len(streams) == 1
    s = streams[0]
    assert s["externalUrl"] == DRIVE_URL
    assert s["behaviorHints"]["web"] is True
    assert s["title"].startswith("Open on OMDrive")
    assert "OLA_DRIVE_COOKIE" in s["title"]


# ------------------------------------------------------------------ cli ----

def test_cli_drive_success(cli_mod, drive_mod, monkeypatch, capsys):
    monkeypatch.setattr(drive_mod, "resolve", lambda target, refresh=False,
                        use_browser=True: {
                            "crypt": CRYPT, "file_name": FILE_NAME, "v1": V1,
                            "expires_at": time.time() + 21600,
                            "status": "resolved", "detail": "direct link resolved",
                        })
    rc = cli_mod.main(["drive", CRYPT, "--no-browser"])
    out = capsys.readouterr().out
    assert rc == 0
    assert V1 in out
    assert FILE_NAME in out


def test_cli_drive_failure(cli_mod, drive_mod, monkeypatch, capsys):
    monkeypatch.setattr(drive_mod, "resolve", lambda target, refresh=False,
                        use_browser=True: {
                            "crypt": CRYPT, "file_name": FILE_NAME, "v1": None,
                            "expires_at": None, "status": "auth_required",
                            "detail": "set OLA_DRIVE_COOKIE …",
                        })
    rc = cli_mod.main(["drive", FILE_URL, "--no-browser"])
    out = capsys.readouterr().out
    assert rc == 1
    assert "auth_required" in out
    assert "OLA_DRIVE_COOKIE" in out


def test_cli_drive_json(cli_mod, drive_mod, monkeypatch, capsys):
    import json as json_mod
    monkeypatch.setattr(drive_mod, "resolve", lambda target, refresh=False,
                        use_browser=True: {
                            "crypt": CRYPT, "file_name": FILE_NAME, "v1": V1,
                            "expires_at": 4102444800.0,
                            "status": "resolved", "detail": "ok",
                        })
    rc = cli_mod.main(["drive", CRYPT, "--json"])
    out = capsys.readouterr().out
    assert rc == 0
    obj = json_mod.loads(out)  # stdout must be pure JSON
    assert obj["v1"] == V1


# ------------------------------------------------------- resolve.py output --

def test_url_command_prints_resolved_direct_links(app_modules, resolve_cli_mod,
                                                  drive_mod, monkeypatch, capsys):
    """`crawler url` gains a RESOLVED DIRECT LINKS section for omd-drive
    streams (fast path only); a guidance line when none resolve."""
    _seed_item(app_modules)
    monkeypatch.setattr(drive_mod, "resolve_cached",
                        lambda url: {"v1": V1, "file_name": FILE_NAME,
                                     "expires_at": time.time() + 3600})
    rc = resolve_cli_mod.resolve(MOVIE)
    out = capsys.readouterr().out
    assert rc == 0
    assert "RESOLVED DIRECT LINKS (OMDrive):" in out
    assert V1 in out
    assert "→ 1 link(s)" in out

    # nothing resolves → one guidance line
    monkeypatch.setattr(drive_mod, "resolve_cached", lambda url: None)
    rc = resolve_cli_mod.resolve(MOVIE)
    out = capsys.readouterr().out
    assert rc == 0
    assert "no OMDrive direct links resolved yet" in out
    assert "python -m crawler drive <url>" in out


# ------------------------------------------------------- mediainfo (6-a) --

MEDIAINFO_OK = {
    "success": True,
    "data": {"json": {"media": {"track": [
        {"@type": "General", "CompleteName": FILE_NAME,
         "FileSize": "3154122660", "Duration": 5984.723},
        {"@type": "Video", "Format": "HEVC"},
    ]}}},
}
MEDIAINFO_URL = "https://drive.olamovies.download/api/mediainfo/get"


def test_fetch_mediainfo_parses_general_track(drive_mod, fetcher_mod,
                                              monkeypatch):
    fake_post = _fake_post({MEDIAINFO_URL: MEDIAINFO_OK})
    monkeypatch.setattr(fetcher_mod, "post", fake_post)
    info = drive_mod.fetch_mediainfo(CRYPT)
    assert info["file_name"] == FILE_NAME
    assert info["size_bytes"] == 3154122660
    assert info["duration_s"] == 5984.723
    # body carries the crypt as fileId
    (url, body), = fake_post.calls
    assert body == {"fileId": CRYPT}


def test_fetch_mediainfo_tolerates_odd_shapes(drive_mod, fetcher_mod,
                                              monkeypatch):
    for payload in ({"success": True, "v1": V1},            # wrong shape
                    {"success": False, "error": "x"},        # error body
                    None):                                   # json() raises
        class _R(FakeResp):
            def json(self):
                if self._payload is None:
                    raise ValueError("no json")
                return self._payload
        monkeypatch.setattr(fetcher_mod, "post",
                            lambda url, json=None, **kw: _R(200, payload=_R and payload))
    assert drive_mod.fetch_mediainfo(CRYPT) == {}


def test_resolve_prefers_mediainfo_name_over_title(drive_mod, fetcher_mod,
                                                   fixture_html, monkeypatch):
    """When mediainfo answers, the file page is never fetched and the exact
    CompleteName is used for the download-links POST."""
    mi_name = "Oak Street (2026) EXACTmediainfo.mkv"
    fake_get = _fake_get(html_by_url={FILE_URL: fixture_html})
    fake_post = _fake_post({
        MEDIAINFO_URL: {"success": True, "data": {"json": {"media": {"track": [
            {"@type": "General", "CompleteName": mi_name,
             "FileSize": "123", "Duration": 1.0}]}}}},
        "https://drive.olamovies.download/api/cloud/download-links":
            {"success": True, "v1": V1},
    })
    monkeypatch.setattr(fetcher_mod, "get", fake_get)
    monkeypatch.setattr(fetcher_mod, "post", fake_post)

    res = drive_mod.resolve(CRYPT, use_browser=False)
    assert res["status"] == "resolved"
    assert res["file_name"] == mi_name
    assert res["file_size"] == 123
    # file page never fetched — mediainfo was enough
    assert FILE_URL not in fake_get.calls
    dl = [c for c in fake_post.calls if c[0].endswith("/api/cloud/download-links")]
    assert dl[0][1] == {"fileId": CRYPT, "fileName": mi_name}


# ------------------------------------------------------- drive proxy (6-c) --

class _FakeUpstream:
    def __init__(self, chunks=(b"abc", b"def")):
        self.chunks = list(chunks)
        self.closed = False

    def iter_raw(self):
        while self.chunks:
            yield self.chunks.pop(0)

    def close(self):
        self.closed = True


def _proxy_enabled(app_modules, monkeypatch, enabled=True):
    monkeypatch.setattr(app_modules["config"], "DRIVE_PROXY", enabled)
    monkeypatch.setattr(app_modules["config"], "DRIVE_RESOLVE", False)


def test_drive_proxy_streams_and_passes_headers(app_modules, drive_mod,
                                                 monkeypatch):
    _seed_item(app_modules)
    monkeypatch.setattr(drive_mod, "resolve_cached",
                        lambda c: {"v1": V1, "file_name": FILE_NAME})
    up = _FakeUpstream()

    def fake_fetch(v1, headers):
        assert v1 == V1
        assert headers == {"range": "bytes=0-2"}
        return 206, {"content-type": "video/x-matroska",
                     "content-range": "bytes 0-2/3154122660",
                     "accept-ranges": "bytes",
                     "content-disposition": 'attachment; filename="oak.mkv"'}, up

    main = app_modules["main"]
    monkeypatch.setattr(main, "_proxy_fetch", fake_fetch)
    client = TestClient(main.app)
    r = client.get(f"/drive/{CRYPT}", headers={"range": "bytes=0-2"})
    assert r.status_code == 206
    assert r.content == b"abcdef"
    assert r.headers["content-type"] == "video/x-matroska"
    assert r.headers["accept-ranges"] == "bytes"
    assert "filename" in r.headers.get("content-disposition", "")
    assert up.closed  # the generator closed the upstream on completion


def test_drive_proxy_unresolved_returns_502(app_modules, drive_mod, monkeypatch):
    _seed_item(app_modules)
    monkeypatch.setattr(drive_mod, "resolve_cached", lambda c: None)
    main = app_modules["main"]
    client = TestClient(main.app)
    r = client.get(f"/drive/{CRYPT}")
    assert r.status_code == 502
    assert "OLA_DRIVE_COOKIE" in r.json()["detail"] or "crawler drive" in r.json()["detail"]


def test_stream_payload_uses_proxy_url_when_enabled(app_modules, drive_mod,
                                                     monkeypatch):
    _seed_item(app_modules)
    _proxy_enabled(app_modules, monkeypatch, enabled=True)
    monkeypatch.setattr(drive_mod, "resolve_cached",
                        lambda url: {"v1": V1, "file_name": FILE_NAME})
    main = app_modules["main"]
    client = TestClient(main.app)
    r = client.get(f"/stream/movie/{MOVIE}.json")
    assert r.status_code == 200
    streams = r.json()["streams"]
    assert streams and streams[0]["url"].startswith("http://testserver/drive/")
    assert streams[0]["url"].endswith(CRYPT)
    assert "proxied" in streams[0]["title"]
    assert "externalUrl" not in streams[0]


def test_stream_payload_direct_url_when_proxy_disabled(app_modules, drive_mod,
                                                        monkeypatch):
    _seed_item(app_modules)
    _proxy_enabled(app_modules, monkeypatch, enabled=False)
    monkeypatch.setattr(drive_mod, "resolve_cached",
                        lambda url: {"v1": V1, "file_name": FILE_NAME})
    main = app_modules["main"]
    client = TestClient(main.app)
    r = client.get(f"/stream/movie/{MOVIE}.json")
    streams = r.json()["streams"]
    assert streams and streams[0]["url"] == V1
