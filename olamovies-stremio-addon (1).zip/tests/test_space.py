"""crawler/space.py integration test — runs crawl_board() against the real
captured board page, with the HTTP fetch monkeypatched out (no network, and
the production data/olamovies.db is never touched — OLA_DB points at the
scratch database set up in conftest.py)."""
from pathlib import Path

FIXTURES = Path(__file__).resolve().parent / "fixtures"

# first record of the captured /completed page 1
FIRST_ID = "tt37600136"


class FakeResponse:
    def __init__(self, status, html):
        self.status = status
        self.html_content = html


def test_crawl_board_one_page(app_modules, monkeypatch):
    db, space = app_modules["db"], app_modules["space"]
    board_html = (FIXTURES / "space_completed.html").read_text(encoding="utf-8")

    fetched = []

    def fake_fetch(url):
        fetched.append(url)
        return FakeResponse(200, board_html)

    monkeypatch.setattr(space, "_fetch", fake_fetch)

    # start from page 1 regardless of what earlier tests left in the state
    # table (the DB is module-shared)
    db.set_state("space:completed:all:next_page", "1")

    result = space.crawl_board("completed", max_pages=1, delay=0)

    assert result["board"] == "completed"
    assert result["category"] is None
    assert result["pages_done"] == 1
    assert result["total_pages"] == 164
    assert result["new_items"] == 48
    assert result["updated_items"] == 0

    # one request, page 1 of the right board
    assert len(fetched) == 1
    assert fetched[0].startswith("https://space.olamovies.dad/completed")
    assert "page=1" in fetched[0]

    # all 48 records landed in the DB
    assert db.count_items() == 48
    assert db.count_items(media_type="series") >= 1
    assert db.count_items(media_type="movie") >= 1

    row = db.get_item(FIRST_ID)
    assert row is not None
    assert row["media_type"] == "series"
    assert row["site_category"] == "tv-series"
    assert row["title"] == "Bon Appetit Your Majesty (2025) Season 1 S01"
    assert row["name"] == "Bon Appetit Your Majesty"   # parsed by app.titles
    assert row["year"] == 2025
    assert row["slug"] == "bon-appetit-your-majesty-2025"
    assert row["site_url"] == "https://v6.olamovies.mov/tv-series/bon-appetit-your-majesty-2025"
    assert row["poster_url"].startswith("https://img.ol-am.top/")
    assert row["stream_status"] == "pending"

    # size spans are attached to the items (positionally aligned)
    assert any(r["size_label"] for r in db.catalog_items("series"))

    # resumable: the pagination cursor advanced to page 2
    assert db.get_state("space:completed:all:next_page") == "2"


def test_crawl_board_resumes_and_refreshes(app_modules, monkeypatch):
    db, space = app_modules["db"], app_modules["space"]
    board_html = (FIXTURES / "space_completed.html").read_text(encoding="utf-8")

    fetched = []

    def fake_fetch(url):
        fetched.append(url)
        return FakeResponse(200, board_html)

    monkeypatch.setattr(space, "_fetch", fake_fetch)

    # first pass creates everything; second pass (cursor now on page 2, fake
    # serves the same page) refreshes the same 48 items without duplicating —
    # start from an empty DB (the module's tables are shared between tests)
    with db.tx() as cur:
        cur.execute("DELETE FROM streams")
        cur.execute("DELETE FROM items")
        cur.execute("DELETE FROM state")
    first = space.crawl_board("completed", max_pages=1, delay=0)
    assert first["new_items"] == 48
    assert first["updated_items"] == 0

    second = space.crawl_board("completed", max_pages=1, delay=0)
    assert second["new_items"] == 0
    assert second["updated_items"] == 48
    assert db.count_items() == 48

    # the second run resumed from the stored cursor
    assert len(fetched) == 2
    assert "page=2" in fetched[1]
    assert db.get_state("space:completed:all:next_page") == "3"


def test_crawl_board_stops_on_http_error(app_modules, monkeypatch):
    db, space = app_modules["db"], app_modules["space"]
    monkeypatch.setattr(space, "_fetch", lambda url: FakeResponse(403, ""))
    db.set_state("space:completed:all:next_page", "5")

    result = space.crawl_board("completed", max_pages=3, delay=0)
    assert result["pages_done"] == 0
    assert result["new_items"] == 0
    # cursor untouched so the next run resumes from the same page
    assert db.get_state("space:completed:all:next_page") == "5"
