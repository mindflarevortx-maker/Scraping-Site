"""Command-line interface for the OlaMovies crawler.

Usage (from the project root):

    python -m crawler catalog [--pages N] [--per-category]   # build/refresh catalog from OM Space
    python -m crawler streams [--limit N] [--movie|--series] # resolve download links from the site
    python -m crawler domain                                  # show current domain resolution
    python -m crawler probe <url>                             # debug: fetch + dump what we can parse
    python -m crawler stats                                   # database statistics
    python -m crawler telegram [--pages N]                    # backfill titles from the t.me channel preview
"""
import argparse
import json
import sys


def main(argv=None):
    p = argparse.ArgumentParser(prog="crawler", description="OlaMovies crawler toolkit")
    sub = p.add_subparsers(dest="cmd", required=True)

    sp = sub.add_parser("catalog", help="crawl the OM Space completed board into the DB")
    sp.add_argument("--pages", type=int, default=None, help="max pages this run (resumable)")
    sp.add_argument("--per-category", action="store_true",
                    help="crawl movies/tv-series/tv-shows separately")
    sp.add_argument("--delay", type=float, default=None)

    ss = sub.add_parser("streams", help="resolve download links for pending items")
    ss.add_argument("--limit", type=int, default=50)
    ss.add_argument("--movie", action="store_true", help="only movies")
    ss.add_argument("--series", action="store_true", help="only series")
    ss.add_argument("--delay", type=float, default=None)

    sub.add_parser("domain", help="resolve + show the current OlaMovies domain")

    pr = sub.add_parser("probe", help="fetch a URL and dump parsed info (debug)")
    pr.add_argument("url")

    sub.add_parser("stats", help="print DB statistics")

    st = sub.add_parser("telegram",
                        help="backfill release titles from the public Telegram channel preview")
    st.add_argument("--pages", type=int, default=10,
                    help="max t.me pages to walk (~20 posts each, newest first)")
    st.add_argument("--channel", default=None,
                    help="channel username (default: OLA_TELEGRAM_CHANNEL env or olamovies_officialv8)")

    args = p.parse_args(argv)

    if args.cmd == "catalog":
        from crawler import space
        result = space.crawl_catalog(max_pages=args.pages,
                                     per_category=args.per_category)
        print(json.dumps(result, indent=2, default=str))
        return 0

    if args.cmd == "streams":
        from crawler import site
        media_type = "movie" if args.movie else ("series" if args.series else None)
        result = site.crawl_streams(limit=args.limit, delay=args.delay,
                                    media_type=media_type)
        print(json.dumps(result, indent=2))
        return 0

    if args.cmd == "domain":
        from crawler import fetcher
        print(fetcher.resolve_current_domain(force=True))
        return 0

    if args.cmd == "probe":
        from crawler import flight as fl
        from crawler import fetcher
        resp = fetcher.get(args.url)
        if resp is None:
            print("FETCH FAILED (all tiers blocked) — run on a residential connection")
            return 1
        html = resp.html_content or ""
        stream = fl.extract_flight(html)
        print(f"status={resp.status} len(html)={len(html)} len(flight)={len(stream)}")
        print("title:", (resp.css("title::text").get() if hasattr(resp, 'css') else "?"))
        links = fl.extract_links(html, args.url)
        print(f"links: {len(links)}")
        for l in links[:40]:
            print("  ", l["url"], "|", l["text"][:60])
        if stream:
            for obj in fl.find_json_objects(stream, ("name", "url"))[:20]:
                print("  obj:", json.dumps(obj, ensure_ascii=False)[:200])
        with open("probe_dump.html", "w", encoding="utf-8") as f:
            f.write(html)
        with open("probe_dump.flight.txt", "w", encoding="utf-8") as f:
            f.write(stream)
        print("saved probe_dump.html + probe_dump.flight.txt")
        return 0

    if args.cmd == "stats":
        from app import db
        print(json.dumps(db.stats(), indent=2))
        return 0

    if args.cmd == "telegram":
        from crawler import telegram as tg
        result = tg.backfill(pages=args.pages, channel=args.channel)
        print(json.dumps(result, indent=2))
        return 0

    return 0


if __name__ == "__main__":
    sys.exit(main())
