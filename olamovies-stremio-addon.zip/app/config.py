"""Central configuration for the OlaMovies addon + crawler.

Everything is overridable through environment variables so the same code runs
locally, in Docker, or on a server without edits.
"""
import os
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = Path(os.environ.get("OLA_DATA_DIR", PROJECT_ROOT / "data"))
DATA_DIR.mkdir(parents=True, exist_ok=True)

# ---------------------------------------------------------------- addon ----
PORT = int(os.environ.get("PORT", "8787"))
HOST = os.environ.get("HOST", "0.0.0.0")
ADDON_ID = os.environ.get("OLA_ADDON_ID", "olamovies.community.addon")
ADDON_NAME = os.environ.get("OLA_ADDON_NAME", "OlaMovies")
ADDON_DESCRIPTION = os.environ.get(
    "OLA_ADDON_DESCRIPTION",
    "OlaMovies catalog and direct download links (movies, TV series, TV shows). "
    "Catalog is served from a local database built by the included Scrapling crawler.",
)
ADDON_VERSION = os.environ.get("OLA_ADDON_VERSION", "1.0.0")
ADDON_LOGO = os.environ.get(
    "OLA_ADDON_LOGO",
    "https://img.ol-am.top/posters/tt37600136/ad1a28bd05f4-154.webp",
)
DB_PATH = Path(os.environ.get("OLA_DB", DATA_DIR / "olamovies.db"))

# -------------------------------------------------------------- crawler ----
# Permanent entry domain — always resolves to the current working domain.
ENTRY_DOMAIN = os.environ.get("OLA_ENTRY_DOMAIN", "https://olamovies.dad")
REDIRECT_URL = f"{ENTRY_DOMAIN}/current.php?redirect=1"

# Known fallback domains, tried in order if the redirect endpoint fails.
FALLBACK_DOMAINS = [
    d.strip()
    for d in os.environ.get(
        "OLA_FALLBACK_DOMAINS", "https://v6.olamovies.mov,https://v5.olamovies.mov"
    ).split(",")
    if d.strip()
]

# Accessible metadata/board endpoints (no Cloudflare walls, work from any IP).
SPACE_BASE = os.environ.get("OLA_SPACE_BASE", "https://space.olamovies.dad")

# HTTP politeness
CRAWL_DELAY = float(os.environ.get("OLA_CRAWL_DELAY", "0.5"))     # seconds between requests
CRAWL_TIMEOUT = int(os.environ.get("OLA_CRAWL_TIMEOUT", "30"))    # seconds
CRAWL_RETRIES = int(os.environ.get("OLA_CRAWL_RETRIES", "3"))
USER_AGENT = os.environ.get(
    "OLA_USER_AGENT",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
)

# Stealth browser fallback (used when the fast HTTP path hits Cloudflare).
STEALTH_HEADLESS = os.environ.get("OLA_STEALTH_HEADLESS", "auto")  # auto|true|false
STEALTH_PROFILE = Path(os.environ.get("OLA_STEALTH_PROFILE", DATA_DIR / "browser-profile"))
STEALTH_CHROME_PATH = os.environ.get("OLA_STEALTH_CHROME_PATH", "")  # optional explicit chrome binary

# Session jar (cf_clearance + UA) shared between the stealth browser and fast path.
SESSION_FILE = DATA_DIR / "session.json"

# Optional: cookie string exported from your logged-in browser session
# (enables resolving login-gated download links). Format: "k1=v1; k2=v2"
ACCOUNT_COOKIE = os.environ.get("OLA_ACCOUNT_COOKIE", "")

DOMAIN_TTL = int(os.environ.get("OLA_DOMAIN_TTL", "600"))  # seconds to cache resolved domain
