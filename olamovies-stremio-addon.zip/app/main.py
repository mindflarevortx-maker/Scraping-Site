"""OlaMovies Stremio addon — FastAPI server.

Run locally:
    uvicorn app.main:app --host 0.0.0.0 --port 8787
Then in Stremio (desktop/mobile): Addons → Install from URL →
    http://127.0.0.1:8787/manifest.json
(the root path / also redirects to the manifest, so pasting
http://127.0.0.1:8787/ works in most Stremio versions).

On a server: put it behind HTTPS (Caddy/nginx) and install with
    https://your-domain/manifest.json

Catalog data comes from the local SQLite database built by the crawler
(see README.md). IMDb ids are used as Stremio ids, so Cinemeta metadata,
posters and descriptions keep working for every item.
"""
import json
import time
from typing import Optional

from fastapi import FastAPI, Query, Request
from fastapi.responses import JSONResponse, RedirectResponse

from app import config, db, titles

app = FastAPI(title=config.ADDON_NAME, docs_url=None, redoc_url=None)

# ------------------------------------------------------------------ misc --

CATALOGS = [
    {"type": "movie", "id": "movies", "name": "Movies",
     "extraSupported": [{"name": "skip"}, {"name": "search"},
                        {"name": "genre", "options": []}]},
    {"type": "series", "id": "tv-series", "name": "TV Series",
     "extraSupported": [{"name": "skip"}, {"name": "search"}]},
    {"type": "series", "id": "tv-shows", "name": "TV Shows",
     "extraSupported": [{"name": "skip"}, {"name": "search"}]},
]

GENRES = [
    "Drama", "Action", "Comedy", "Thriller", "Romance", "Horror", "Crime",
    "Sci-Fi", "Adventure", "Animation", "Fantasy", "Mystery", "Biography",
    "Musical", "Documentary", "Family", "History", "Sports", "War", "Reality",
    "Survival", "Political", "Western", "Anthology",
]

CACHE_SHORT = {"Cache-Control": "public, max-age=300"}
CACHE_LONG = {"Cache-Control": "public, max-age=3600"}


def _row_to_meta(row) -> dict:
    meta = {
        "id": row["imdb_id"],
        "name": row["name"] or row["title"],
        "type": row["media_type"],
        "poster": row["poster_url"] or "",
        "releaseInfo": str(row["year"]) if row["year"] else "",
        "description": row["release_desc"] or "",
    }
    if row["imdb_rating"]:
        try:
            meta["imdbRating"] = float(row["imdb_rating"])
        except (TypeError, ValueError):
            pass
    if row["size_label"]:
        meta["description"] = (meta["description"] + f"\nTotal size: {row['size_label']}").strip()
    return meta


def _json(payload: dict, cache: dict = CACHE_SHORT) -> JSONResponse:
    return JSONResponse(payload, headers=cache)


# -------------------------------------------------------------- manifest --

@app.get("/manifest.json")
def manifest():
    return _json({
        "id": config.ADDON_ID,
        "version": config.ADDON_VERSION,
        "name": config.ADDON_NAME,
        "description": config.ADDON_DESCRIPTION,
        "logo": config.ADDON_LOGO,
        "types": ["movie", "series"],
        "resources": ["catalog", "meta", "stream"],
        "catalogs": CATALOGS,
        "idPrefixes": ["tt", "ola"],
        "behaviorHints": {"configurable": False},
    }, CACHE_LONG)


@app.get("/", include_in_schema=False)
def root():
    return RedirectResponse("/manifest.json")


@app.get("/health")
def health():
    return _json(db.stats(), {"Cache-Control": "no-store"})


# -------------------------------------------------------------- catalog ---

@app.get("/catalog/{media_type}/{catalog_id}.json")
def catalog(media_type: str, catalog_id: str,
            skip: int = Query(0, ge=0),
            search: Optional[str] = Query(None),
            genre: Optional[str] = Query(None)):
    if media_type not in ("movie", "series") or catalog_id not in (
            "movies", "tv-series", "tv-shows", "last-added", "search"):
        return _json({"metas": []}, {"Cache-Control": "no-store"})

    if catalog_id == "last-added":
        site_category = None
        mtype = media_type
    else:
        site_category = catalog_id
        mtype = media_type

    rows = db.catalog_items(mtype, site_category=site_category, search=search,
                            skip=skip, limit=100)
    metas = [_row_to_meta(r) for r in rows]
    return _json({"metas": metas})


# ----------------------------------------------------------------- meta ---

@app.get("/meta/{media_type}/{imdb_id}.json")
def meta(media_type: str, imdb_id: str):
    if media_type not in ("movie", "series"):
        return _json({"meta": {}}, {"Cache-Control": "no-store"})
    row = db.get_item(imdb_id)
    if row is None:
        return _json({"meta": {"id": imdb_id, "type": media_type, "name": ""}},
                     {"Cache-Control": "no-store"})
    m = _row_to_meta(row)
    m["background"] = row["poster_url"] or ""
    # videos list for series (populated once streams are crawled)
    if media_type == "series":
        vids = []
        for s in db.streams_for(imdb_id):
            if s["season"] and s["episode"]:
                vids.append({
                    "id": f"{s['season']}:{s['episode']}",
                    "title": s["label"] or f"S{s['season']:02d}E{s['episode']:02d}",
                    "season": s["season"], "episode": s["episode"],
                })
        if vids:
            m["videos"] = vids
    return _json({"meta": m}, CACHE_LONG)


# --------------------------------------------------------------- streams --

def _streams_payload(imdb_id: str, season: Optional[int], episode: Optional[int],
                     media_type: str) -> dict:
    row = db.get_item(imdb_id)
    if row is None:
        return {"streams": []}

    streams = []
    for s in db.streams_for(imdb_id, season, episode):
        entry = {
            "name": config.ADDON_NAME,
            "title": s["label"] or s["url"],
            "url": s["url"],
        }
        if s["kind"] == "direct":
            pass  # playable directly
        else:
            # hoster/Google Drive pages open through Stremio's browser flow
            entry["externalUrl"] = s["url"]
            entry["behaviorHints"] = {"web": True, "proxyHeaders": None}
        streams.append(entry)

    if not streams:
        # nothing resolved yet — offer to open the item on the site
        if row["site_url"]:
            streams.append({
                "name": config.ADDON_NAME,
                "title": f"Open on OlaMovies\n{row['name'] or row['title']}"
                         + (f" ({row['year']})" if row["year"] else ""),
                "externalUrl": row["site_url"],
                "behaviorHints": {"web": True},
            })
    return {"streams": streams}


@app.get("/stream/movie/{imdb_id}.json")
def stream_movie(imdb_id: str):
    return _json(_streams_payload(imdb_id, None, None, "movie"))


# NOTE: the ":" episode route MUST be registered before the plain series route.
# Starlette matches routes in registration order and "{imdb_id}" matches any
# non-slash chars, so "/stream/series/tt123:1:1.json" would otherwise be
# captured by the plain route with imdb_id="tt123:1:1" and return no streams.
@app.get("/stream/series/{imdb_id}:{season}:{episode}.json")
def stream_series_se(imdb_id: str, season: int, episode: int):
    return _json(_streams_payload(imdb_id, season, episode, "series"))


@app.get("/stream/series/{imdb_id}.json")
def stream_series(imdb_id: str, season: Optional[int] = Query(None),
                  episode: Optional[int] = Query(None)):
    return _json(_streams_payload(imdb_id, season, episode, "series"))


# ------------------------------------------------------------- utilities --

@app.get("/genres.json")
def genres():
    return _json({"genres": GENRES}, CACHE_LONG)


@app.on_event("startup")
def _startup():
    st = db.stats()
    print(f"[addon] {config.ADDON_NAME} v{config.ADDON_VERSION} — "
          f"{st['items']} items ({st['movies']} movies / {st['series']} series), "
          f"{st['streams']} streams, db={st['db_path']}", flush=True)


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host=config.HOST, port=config.PORT)
